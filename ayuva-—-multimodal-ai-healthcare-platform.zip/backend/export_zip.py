import os
import zipfile
import sys

def create_project_zip(output_path="/tmp/ayuva-healthcare-platform.zip"):
    root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    
    # Exclude directories that shouldn't be in the clean source package
    exclude_dirs = {
        'node_modules', '.git', 'dist', '.cache', '__pycache__', '.pytest_cache',
        '.vscode', '.idea'
    }
    
    # Exclude files
    exclude_files = {
        '.DS_Store', 'package-lock.json.bak'
    }

    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(root_dir):
            # Modify dirs in-place to skip excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs and not d.startswith('.')]
            
            for file in files:
                if file in exclude_files or file.endswith(('.pyc', '.pyo', '.tmp')):
                    continue
                file_path = os.path.join(root, file)
                if os.path.abspath(file_path) == os.path.abspath(output_path):
                    continue
                rel_path = os.path.relpath(file_path, root_dir)
                zipf.write(file_path, rel_path)

    size = os.path.getsize(output_path)
    print(f"Created {output_path} ({size} bytes)")
    return output_path

if __name__ == '__main__':
    create_project_zip()
