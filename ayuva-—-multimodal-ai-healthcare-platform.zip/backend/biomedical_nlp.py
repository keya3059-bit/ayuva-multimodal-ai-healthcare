#!/usr/bin/env python3
"""
Ayuva Python Backend - Biomedical NLP & Clinical Entity Engine
Extracts clinical tokens, medications, dosages, anatomical locations,
symptoms, negation scopes, and ICD-10 suggested classifications from clinical prose.
"""

import re
import json
import sys

ICD_10_MAPPINGS = {
    "angina": {"code": "I20.9", "description": "Angina pectoris, unspecified"},
    "hypertension": {"code": "I10", "description": "Essential (primary) hypertension"},
    "diabetes": {"code": "E11.9", "description": "Type 2 diabetes mellitus without complications"},
    "stemi": {"code": "I21.3", "description": "ST elevation myocardial infarction of unspecified site"},
    "copd": {"code": "J44.9", "description": "Chronic obstructive pulmonary disease, unspecified"},
    "asthma": {"code": "J45.909", "description": "Unspecified asthma, uncomplicated"},
    "headache": {"code": "R51.9", "description": "Headache, unspecified"},
    "tachycardia": {"code": "R00.0", "description": "Tachycardia, unspecified"},
    "dyspnea": {"code": "R06.02", "description": "Shortness of breath / dyspnea"},
    "fever": {"code": "R50.9", "description": "Fever, unspecified"},
    "chest pain": {"code": "R07.9", "description": "Chest pain, unspecified"},
    "cholecystectomy": {"code": "Z98.870", "description": "History of cholecystectomy"}
}

NEGATION_CUES = [
    "no", "denies", "denied", "without", "negative for", "ruled out",
    "rules out", "not experiencing", "did not report", "no signs of", "free of"
]

DRUG_PATTERNS = [
    r'\b(metformin|atorvastatin|telmisartan|aspirin|lisinopril|amlodipine|losartan|omeprazole|furosemide|metoprolol|carvedilol|glimepiride|insulin|pantoprazole|clopidogrel|paracetamol|ibuprofen|amoxicillin|azithromycin)\b'
]

DOSAGE_PATTERN = r'\b(\d+(?:\.\d+)?\s*(?:mg|mcg|g|ml|tablets?|capsules?|units?|iu|bid|tid|qid|qd|hs|daily|twice daily))\b'

def detect_negations(text):
    """
    Identifies phrases negated by standard clinical negation triggers.
    """
    negated_ranges = []
    text_lower = text.lower()
    for cue in NEGATION_CUES:
        for match in re.finditer(r'\b' + re.escape(cue) + r'\b', text_lower):
            start = match.end()
            # Negation scope extends until comma, period, or conjunction
            end = len(text)
            for stop_char in [".", ";", "but", "however", "although"]:
                idx = text_lower.find(stop_char, start)
                if idx != -1 and idx < end:
                    end = idx
            negated_ranges.append((start, end))
    return negated_ranges

def is_negated(start_pos, negated_ranges):
    return any(start <= start_pos <= end for start, end in negated_ranges)

def analyze_clinical_text(text):
    text_lower = text.lower()
    negated_ranges = detect_negations(text)
    
    entities = []
    
    # 1. Medications
    for pat in DRUG_PATTERNS:
        for m in re.finditer(pat, text_lower):
            neg = is_negated(m.start(), negated_ranges)
            entities.append({
                "category": "MEDICATION",
                "text": text[m.start():m.end()],
                "start": m.start(),
                "end": m.end(),
                "negated": neg,
                "confidence": 0.98
            })
            
    # 2. Dosages & Frequencies
    for m in re.finditer(DOSAGE_PATTERN, text_lower):
        entities.append({
            "category": "DOSAGE",
            "text": text[m.start():m.end()],
            "start": m.start(),
            "end": m.end(),
            "negated": False,
            "confidence": 0.95
        })
        
    # 3. Symptoms & Conditions with ICD-10 mapping
    icd_suggestions = []
    for cond, meta in ICD_10_MAPPINGS.items():
        for m in re.finditer(r'\b' + re.escape(cond) + r'\b', text_lower):
            neg = is_negated(m.start(), negated_ranges)
            entities.append({
                "category": "CONDITION" if not neg else "NEGATED_CONDITION",
                "text": text[m.start():m.end()],
                "start": m.start(),
                "end": m.end(),
                "negated": neg,
                "icd10": meta["code"],
                "confidence": 0.94
            })
            if not neg and meta["code"] not in [x["code"] for x in icd_suggestions]:
                icd_suggestions.append(meta)
                
    # 4. Vital Signs in Text
    vitals_pat = r'\b(?:bp\s*(?::\s*)?(\d{2,3}/\d{2,3})|spo2\s*(?::\s*)?(\d{2,3}%?)|pulse\s*(?::\s*)?(\d{2,3})|hr\s*(?::\s*)?(\d{2,3})|glucose\s*(?::\s*)?(\d{2,3}))\b'
    for m in re.finditer(vitals_pat, text_lower):
        entities.append({
            "category": "VITAL_SIGN",
            "text": text[m.start():m.end()],
            "start": m.start(),
            "end": m.end(),
            "negated": False,
            "confidence": 0.97
        })

    # Sort entities by character position
    entities.sort(key=lambda x: x["start"])
    
    # Readability / Complexity metrics
    words = [w for w in re.findall(r'\b\w+\b', text)]
    word_count = len(words)
    medical_term_count = len([e for e in entities if e["category"] in ["MEDICATION", "CONDITION"]])
    clinical_density = round((medical_term_count / max(word_count, 1)) * 100, 1)

    return {
        "text": text,
        "word_count": word_count,
        "entities": entities,
        "total_entities": len(entities),
        "icd_suggestions": icd_suggestions,
        "clinical_density_percent": clinical_density,
        "negations_detected": len(negated_ranges),
        "engine": "Python Biomedical NER & Negation Engine (Bio-NLP-v2)"
    }

if __name__ == "__main__":
    if len(sys.argv) > 1:
        raw_args = sys.argv[1]
        try:
            p = json.loads(raw_args)
            input_str = p.get("text", "")
            print(json.dumps(analyze_clinical_text(input_str)))
        except Exception as e:
            print(json.dumps({"error": str(e)}))
    else:
        sample = "Patient denies chest pain and fever. Prescribed Metformin 500mg BID and Atorvastatin 10mg HS for diabetes and hypertension. BP 122/80."
        print(json.dumps(analyze_clinical_text(sample), indent=2))
