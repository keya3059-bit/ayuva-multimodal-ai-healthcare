#!/usr/bin/env python3
"""
Ayuva Python Backend - Safe Interactive Code Execution Sandbox
Allows clinicians, researchers, and administrators to execute Python scripts,
test ML algorithms, query Hugging Face models, and run data analyses live.
"""

import sys
import io
import time
import traceback
import json
import math
import random
import re
import datetime
import statistics

# Import local Python backend modules so they can be readily used in scripts
import huggingface_service
import clinical_random_forest
import biomedical_nlp
import drug_interactions
import vitals_analytics

def execute_user_script(code_string):
    start_time = time.time()
    
    # Capture standard outputs
    stdout_buffer = io.StringIO()
    stderr_buffer = io.StringIO()
    
    orig_stdout = sys.stdout
    orig_stderr = sys.stderr
    sys.stdout = stdout_buffer
    sys.stderr = stderr_buffer
    
    # Sandbox environment with rich clinical and mathematical packages
    safe_globals = {
        "__builtins__": __builtins__,
        "math": math,
        "random": random,
        "re": re,
        "datetime": datetime,
        "statistics": statistics,
        "json": json,
        # Local Ayuva modules
        "huggingface": huggingface_service,
        "random_forest": clinical_random_forest,
        "bio_nlp": biomedical_nlp,
        "pharmacology": drug_interactions,
        "vitals_calc": vitals_analytics,
    }
    
    exec_success = True
    error_message = None
    
    try:
        # Execute the script
        exec(code_string, safe_globals)
    except Exception as e:
        exec_success = False
        error_message = traceback.format_exc()
        sys.stderr.write(f"\nExecution Error: {str(e)}\n")
    finally:
        sys.stdout = orig_stdout
        sys.stderr = orig_stderr
        
    duration_ms = round((time.time() - start_time) * 1000, 2)
    
    stdout_val = stdout_buffer.getvalue()
    stderr_val = stderr_buffer.getvalue()
    
    return {
        "success": exec_success,
        "stdout": stdout_val,
        "stderr": stderr_val,
        "error": error_message,
        "execution_time_ms": duration_ms,
        "python_version": sys.version.split()[0],
        "available_namespaces": [
            "math", "random", "re", "statistics", "datetime", "json",
            "huggingface", "random_forest", "bio_nlp", "pharmacology", "vitals_calc"
        ]
    }

if __name__ == "__main__":
    if len(sys.argv) > 1:
        try:
            p = json.loads(sys.argv[1])
            code = p.get("code", "print('Python 3.10 Backend Ready')")
            print(json.dumps(execute_user_script(code)))
        except Exception as e:
            print(json.dumps({"success": False, "error": str(e)}))
    else:
        sample_code = """
import statistics
print("=== Ayuva Python Diagnostics ===")
vitals = [72, 74, 75, 71, 73, 76]
print(f"Mean Heart Rate: {statistics.mean(vitals)} BPM")
print(f"Standard Deviation: {statistics.stdev(vitals):.2f}")

# Call local Hugging Face service
res = huggingface.run_hf_inference({
    'model': 'Clinical-Urgency-SST2',
    'input': 'Patient reports severe chest tightness radiating to left jaw'
})
print("Urgency Score:", res['result'])
"""
        print(json.dumps(execute_user_script(sample_code), indent=2))
