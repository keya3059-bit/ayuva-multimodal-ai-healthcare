#!/usr/bin/env python3
"""
Ayuva Python Backend - Unified Dispatcher & CLI Gateway
Coordinates actions called by the Node.js Express server via JSON IPC.
"""

import sys
import os
import json
import platform

# Ensure backend directory is on sys.path
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if SCRIPT_DIR not in sys.path:
    sys.path.insert(0, SCRIPT_DIR)

import huggingface_service
import clinical_random_forest
import biomedical_nlp
import drug_interactions
import vitals_analytics
import interpreter
import xgboost_lightgbm_engine
import shap_explainer
import monai_opencv_engine
import ocr_pymupdf_engine
import langgraph_agent
import vector_db_service
import fhir_crypto
import mlflow_onnx_registry
import docker_architecture

MODULES_METADATA = [
    {
        "name": "xgboost_lightgbm_engine",
        "title": "XGBoost & LightGBM Ensembles",
        "version": "2.4.0",
        "description": "Gradient boosted trees, split criteria, learning rate shrinkage, and Pydantic clinical input models.",
        "status": "Active / Loaded"
    },
    {
        "name": "shap_explainer",
        "title": "SHAP (Shapley Additive Explanations)",
        "version": "1.3.0",
        "description": "TreeSHAP feature attributions, base value expectations, waterfall plot generation for clinical explainability.",
        "status": "Active / Loaded"
    },
    {
        "name": "monai_opencv_engine",
        "title": "MONAI & OpenCV Medical Vision",
        "version": "3.1.0",
        "description": "DICOM HU window leveling, Sobel/Canny edge filtering, contour detection, and MONAI UNet neural segmentation masks.",
        "status": "Active / Loaded"
    },
    {
        "name": "ocr_pymupdf_engine",
        "title": "OCR & PyMuPDF (fitz) Document Ingestion",
        "version": "2.0.0",
        "description": "PDF text extraction, bounding-box geometry, laboratory entity extraction, and structured EHR classification.",
        "status": "Active / Loaded"
    },
    {
        "name": "langgraph_agent",
        "title": "LangChain & LangGraph Orchestrator",
        "version": "1.5.0",
        "description": "Multi-agent cyclical state graph with Triage Router, Guideline RAG, Reasoner, Safety Critic, and FHIR Serializer.",
        "status": "Active / Loaded"
    },
    {
        "name": "vector_db_service",
        "title": "pgvector & Qdrant Knowledge Base",
        "version": "1.2.0",
        "description": "Dense clinical vector embeddings and HNSW cosine distance search for ACC/AHA, ADA, and KDIGO guidelines.",
        "status": "Active / Loaded"
    },
    {
        "name": "fhir_crypto",
        "title": "HL7 FHIR R4 & Cryptography Enclave",
        "version": "2.2.0",
        "description": "HL7 FHIR R4 resource generators with AES-256-GCM encryption, RSA-4096 digital signatures, and HIPAA audit trails.",
        "status": "Active / Loaded"
    },
    {
        "name": "mlflow_onnx_registry",
        "title": "MLflow & ONNX Runtime HealthOps",
        "version": "2.1.0",
        "description": "Experiment tracking, model registry, and INT8/FP16 quantized graph execution latency benchmarks.",
        "status": "Active / Loaded"
    },
    {
        "name": "docker_architecture",
        "title": "Docker & Django/DRF Production Blueprint",
        "version": "3.0.0",
        "description": "Full-stack microservices configuration with Django REST Framework, FastAPI, PostgreSQL+pgvector, Celery, and Redis.",
        "status": "Active / Loaded"
    },
    {
        "name": "huggingface_service",
        "title": "Hugging Face Inference Hub",
        "version": "1.4.0",
        "description": "Bridges Hugging Face Inference API and local clinical BERT pipelines for BioBERT, PubMedBERT, BART zero-shot, and Llama.",
        "status": "Active / Loaded"
    },
    {
        "name": "clinical_random_forest",
        "title": "Ensemble Random Forest Engine",
        "version": "2.1.0",
        "description": "Pure Python Breiman Gini-split multi-tree ensemble for cardiometabolic triage, feature importances, and tree graph exports.",
        "status": "Active / Loaded"
    },
    {
        "name": "biomedical_nlp",
        "title": "Biomedical NER & Negation Engine",
        "version": "1.8.2",
        "description": "Clinical entity extraction, RxNorm and ICD-10 suggestions, and scope negation parser for physician dictations.",
        "status": "Active / Loaded"
    },
    {
        "name": "drug_interactions",
        "title": "Pharmacology & CYP450 Matrix",
        "version": "2.0.1",
        "description": "Cytochrome P450 pathway competition analyzer, cross-reactivity warning engine, and contraindicated pairing validator.",
        "status": "Active / Loaded"
    },
    {
        "name": "vitals_analytics",
        "title": "Hemodynamics & MEWS Calculator",
        "version": "1.2.0",
        "description": "Computes Mean Arterial Pressure (MAP), Shock Index, qSOFA, and Modified Early Warning Score (MEWS) from live sensor streams.",
        "status": "Active / Loaded"
    },
    {
        "name": "interpreter",
        "title": "Interactive Python Code Sandbox",
        "version": "3.10-Exec",
        "description": "Sandboxed script execution environment supporting live Python commands, data science transformations, and ML testing.",
        "status": "Active / Loaded"
    }
]

def get_system_status():
    return {
        "status": "online",
        "language": "Python",
        "version": platform.python_version(),
        "compiler": platform.python_compiler(),
        "platform": platform.platform(),
        "pid": os.getpid(),
        "active_modules": MODULES_METADATA,
        "huggingface_models": list(huggingface_service.SUPPORTED_MODELS.keys()),
        "has_hf_token": bool(os.environ.get("HUGGINGFACE_API_TOKEN") or os.environ.get("HF_TOKEN")),
        "uptime": "Active"
    }

def handle_request(action, payload):
    if action == "status":
        return get_system_status()
        
    elif action == "modules":
        return {
            "modules": MODULES_METADATA,
            "python_version": platform.python_version()
        }
        
    elif action == "huggingface":
        return huggingface_service.run_hf_inference(payload)
        
    elif action == "random_forest":
        return clinical_random_forest.run_rf_prediction(payload)
        
    elif action == "biomedical_nlp":
        text = payload.get("text", "")
        return biomedical_nlp.analyze_clinical_text(text)
        
    elif action == "drug_interactions":
        meds = payload.get("medications", [])
        return drug_interactions.check_drug_interactions(meds)
        
    elif action == "vitals_analytics":
        hr = float(payload.get("hr", payload.get("heartRate", 74)))
        sys_bp = float(payload.get("sysBP", payload.get("bpSystolic", 122)))
        dia_bp = float(payload.get("diaBP", payload.get("bpDiastolic", 80)))
        spo2 = float(payload.get("spo2", 98))
        temp = float(payload.get("temp", payload.get("temperature", 36.8)))
        return vitals_analytics.calculate_hemodynamics(hr, sys_bp, dia_bp, spo2, temp)
        
    elif action == "execute":
        code = payload.get("code", "")
        return interpreter.execute_user_script(code)

    elif action == "xgboost_lightgbm":
        return xgboost_lightgbm_engine.run_xgboost_lightgbm(payload)

    elif action == "shap_explainer":
        return shap_explainer.calculate_shap_values(payload)

    elif action == "monai_opencv":
        return monai_opencv_engine.analyze_medical_image(payload)

    elif action == "ocr_pymupdf":
        return ocr_pymupdf_engine.parse_clinical_document(payload)

    elif action == "langgraph_agent":
        return langgraph_agent.run_langgraph_clinical_workflow(payload)

    elif action == "vector_db":
        return vector_db_service.search_vector_database(payload)

    elif action == "fhir_crypto":
        return fhir_crypto.handle_fhir_crypto_request(payload)

    elif action == "mlflow_onnx":
        return mlflow_onnx_registry.get_mlflow_and_onnx_metrics(payload)

    elif action == "docker_architecture":
        return docker_architecture.get_architecture_spec()
        
    else:
        return {"error": f"Unknown action: {action}"}

if __name__ == "__main__":
    if len(sys.argv) < 2:
        # Default: print status
        print(json.dumps(get_system_status(), indent=2))
        sys.exit(0)
        
    action_name = sys.argv[1]
    payload_data = {}
    
    if len(sys.argv) >= 3:
        try:
            payload_data = json.loads(sys.argv[2])
        except Exception:
            payload_data = {"raw": sys.argv[2]}
                
    response = handle_request(action_name, payload_data)
    print(json.dumps(response))
