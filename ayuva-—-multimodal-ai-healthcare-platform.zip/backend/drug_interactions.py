#!/usr/bin/env python3
"""
Ayuva Python Backend - Pharmacology & Drug-Drug Interaction Engine
Evaluates multi-medication lists for cytochrome P450 pathway competition,
pharmacokinetic interactions, additive toxicities, and contraindicated pairings.
"""

import json
import sys

DRUG_DATABASE = {
    "metformin": {
        "class": "Biguanide / Antidiabetic",
        "cyp_pathway": "Renal elimination (OCT2/MATE)",
        "contraindications": ["severe renal impairment (eGFR < 30)", "acute metabolic acidosis"],
        "max_daily_dose": "2550 mg"
    },
    "atorvastatin": {
        "class": "HMG-CoA Reductase Inhibitor (Statin)",
        "cyp_pathway": "Substrate of CYP3A4",
        "contraindications": ["active liver disease", "unexplained persistent transaminase elevations"],
        "max_daily_dose": "80 mg"
    },
    "telmisartan": {
        "class": "Angiotensin II Receptor Blocker (ARB)",
        "cyp_pathway": "Glucuronidation (UGT1A3)",
        "contraindications": ["concomitant aliskiren in diabetes", "bilateral renal artery stenosis"],
        "max_daily_dose": "80 mg"
    },
    "aspirin": {
        "class": "Antiplatelet / Salicylate",
        "cyp_pathway": "Esterase hydrolysis / Glucuronidation",
        "contraindications": ["active peptic ulcer", "severe bleeding diathesis"],
        "max_daily_dose": "325 mg (antiplatelet: 75-100 mg)"
    },
    "clopidogrel": {
        "class": "P2Y12 Antiplatelet",
        "cyp_pathway": "Prodrug activated by CYP2C19",
        "contraindications": ["active bleeding", "severe hepatic impairment"],
        "max_daily_dose": "75 mg"
    },
    "omeprazole": {
        "class": "Proton Pump Inhibitor (PPI)",
        "cyp_pathway": "Inhibitor of CYP2C19",
        "contraindications": ["hypersensitivity"],
        "max_daily_dose": "40 mg"
    },
    "warfarin": {
        "class": "Vitamin K Antagonist",
        "cyp_pathway": "Substrate of CYP2C9 and CYP3A4",
        "contraindications": ["hemorrhagic tendencies", "pregnancy"],
        "max_daily_dose": "Titrated to INR (typically 2-10 mg)"
    },
    "amiodarone": {
        "class": "Class III Antiarrhythmic",
        "cyp_pathway": "Inhibitor of CYP2C9, CYP2D6, CYP3A4, and P-glycoprotein",
        "contraindications": ["severe sinus node dysfunction", "second/third-degree AV block"],
        "max_daily_dose": "400 mg"
    },
    "digoxin": {
        "class": "Cardiac Glycoside",
        "cyp_pathway": "Substrate of P-glycoprotein",
        "contraindications": ["ventricular fibrillation", "myocarditis"],
        "max_daily_dose": "0.25 mg"
    },
    "ibuprofen": {
        "class": "NSAID",
        "cyp_pathway": "Substrate of CYP2C9",
        "contraindications": ["active GI bleeding", "severe heart failure", "CABG perioperative"],
        "max_daily_dose": "2400 mg"
    },
    "lisinopril": {
        "class": "ACE Inhibitor",
        "cyp_pathway": "Renal excretion unchanged",
        "contraindications": ["history of angioedema", "co-administration with ARBs"],
        "max_daily_dose": "40 mg"
    },
    "spironolactone": {
        "class": "Potassium-Sparing Diuretic / Aldosterone Antagonist",
        "cyp_pathway": "Hepatic sulfur conversion",
        "contraindications": ["hyperkalemia", "Addison's disease"],
        "max_daily_dose": "100 mg"
    }
}

INTERACTION_RULES = [
    {
        "pair": ["clopidogrel", "omeprazole"],
        "severity": "Major",
        "mechanism": "CYP2C19 Inhibition",
        "detail": "Omeprazole inhibits CYP2C19, reducing the bioactivation of clopidogrel into its active antiplatelet form by up to 45%.",
        "recommendation": "Switch omeprazole to pantoprazole or famotidine."
    },
    {
        "pair": ["warfarin", "amiodarone"],
        "severity": "Critical",
        "mechanism": "CYP2C9 & P-gp Inhibition",
        "detail": "Amiodarone potently inhibits warfarin metabolism, causing profound INR elevation and acute hemorrhage risk.",
        "recommendation": "Reduce warfarin dosage by 33-50% upon starting amiodarone and monitor INR daily."
    },
    {
        "pair": ["digoxin", "amiodarone"],
        "severity": "Major",
        "mechanism": "P-glycoprotein Efflux Inhibition",
        "detail": "Amiodarone increases serum digoxin concentrations by ~70%, risking digitalis toxicity (arrhythmias, nausea, visual changes).",
        "recommendation": "Reduce digoxin dosage by 50% and obtain serum digoxin levels within 7 days."
    },
    {
        "pair": ["aspirin", "ibuprofen"],
        "severity": "Moderate",
        "mechanism": "COX-1 Receptor Competition",
        "detail": "Ibuprofen competitively binds platelet COX-1, obstructing aspirin's irreversible cardioprotective acetylation.",
        "recommendation": "Take immediate-release aspirin at least 30 minutes before or 8 hours after ibuprofen."
    },
    {
        "pair": ["lisinopril", "spironolactone"],
        "severity": "Moderate",
        "mechanism": "Additive Potassium Retention",
        "detail": "Concomitant ACE inhibitor and potassium-sparing diuretic can precipitate severe hyperkalemia (> 5.5 mEq/L).",
        "recommendation": "Check serum potassium and creatinine within 1-2 weeks of concurrent therapy."
    },
    {
        "pair": ["lisinopril", "telmisartan"],
        "severity": "Major",
        "mechanism": "Dual Renin-Angiotensin-Aldosterone System (RAAS) Blockade",
        "detail": "Combining ACE inhibitors and ARBs increases risk of hypotension, syncope, hyperkalemia, and acute renal impairment without clinical benefit.",
        "recommendation": "Avoid dual RAAS blockade. Maintain single agent therapy."
    },
    {
        "pair": ["atorvastatin", "amiodarone"],
        "severity": "Moderate",
        "mechanism": "CYP3A4 Inhibition",
        "detail": "Amiodarone inhibits CYP3A4, elevating atorvastatin plasma levels and augmenting risk of myopathy or rhabdomyolysis.",
        "recommendation": "Limit atorvastatin dose to 20mg daily or switch to rosuvastatin/pravastatin."
    },
    {
        "pair": ["metformin", "ibuprofen"],
        "severity": "Minor",
        "mechanism": "Renal Hemodynamic Alteration",
        "detail": "NSAIDs can reduce renal blood flow, potentially diminishing metformin clearance in dehydrated patients.",
        "recommendation": "Ensure adequate hydration and monitor renal function periodically."
    }
]

def check_drug_interactions(drug_names):
    normalized = [d.strip().lower() for d in drug_names if d.strip()]
    
    matched_drugs = []
    for d in normalized:
        base_name = None
        for db_key in DRUG_DATABASE.keys():
            if db_key in d or d in db_key:
                base_name = db_key
                break
        if base_name:
            matched_drugs.append(base_name)
            
    # Find pairwise interactions
    found_interactions = []
    n = len(matched_drugs)
    for i in range(n):
        for j in range(i + 1, n):
            d1, d2 = matched_drugs[i], matched_drugs[j]
            for rule in INTERACTION_RULES:
                if (rule["pair"][0] == d1 and rule["pair"][1] == d2) or (rule["pair"][0] == d2 and rule["pair"][1] == d1):
                    found_interactions.append({
                        "drugs": [d1.capitalize(), d2.capitalize()],
                        "severity": rule["severity"],
                        "mechanism": rule["mechanism"],
                        "clinical_detail": rule["detail"],
                        "recommendation": rule["recommendation"]
                    })
                    
    # Generate CYP450 breakdown
    pathways = {}
    for d in matched_drugs:
        info = DRUG_DATABASE.get(d)
        if info:
            pathways[d.capitalize()] = {
                "class": info["class"],
                "pathway": info["cyp_pathway"],
                "contraindications": info["contraindications"],
                "max_dose": info["max_daily_dose"]
            }
            
    severity_order = {"Critical": 3, "Major": 2, "Moderate": 1, "Minor": 0}
    max_severity = "None"
    if found_interactions:
        max_severity = max(found_interactions, key=lambda x: severity_order.get(x["severity"], 0))["severity"]
        
    return {
        "analyzed_medications": [d.capitalize() for d in matched_drugs],
        "interaction_count": len(found_interactions),
        "maximum_severity": max_severity,
        "interactions": found_interactions,
        "pharmacokinetics": pathways,
        "is_safe": len(found_interactions) == 0,
        "engine": "Python Cytochrome P450 Pharmacology Engine (Pharm-Py-2030)"
    }

if __name__ == "__main__":
    if len(sys.argv) > 1:
        try:
            p = json.loads(sys.argv[1])
            drugs = p.get("medications", [])
            print(json.dumps(check_drug_interactions(drugs)))
        except Exception as e:
            print(json.dumps({"error": str(e)}))
    else:
        sample_drugs = ["Metformin 500mg", "Atorvastatin 10mg", "Telmisartan 40mg", "Ibuprofen 400mg"]
        print(json.dumps(check_drug_interactions(sample_drugs), indent=2))
