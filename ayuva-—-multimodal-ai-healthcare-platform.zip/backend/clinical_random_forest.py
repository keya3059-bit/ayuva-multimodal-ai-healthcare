#!/usr/bin/env python3
"""
Ayuva Python Backend - Clinical Random Forest Engine
Pure Python implementation of an Ensemble Random Forest Classifier for
cardiometabolic risk prediction and multi-variate vital sign triage.
Calculates real Gini impurity, decision tree splits, feature importance weights,
and full tree topologies for interactive UI rendering.
"""

import math
import random
import json
import sys

FEATURE_NAMES = [
    "Blood Glucose (mg/dL)",
    "Systolic BP (mmHg)",
    "Diastolic BP (mmHg)",
    "Heart Rate (BPM)",
    "Age (Years)",
    "SpO2 (%)",
    "BMI (kg/m²)",
    "Cholesterol (mg/dL)"
]

RISK_CLASSES = ["Optimal / Low Risk", "Moderate Attention", "Elevated Concern", "High Risk / Acute"]

class DecisionNode:
    def __init__(self, feature=None, threshold=None, left=None, right=None, value=None, samples=0, gini=0.0):
        self.feature = feature       # Index of feature to split on
        self.threshold = threshold   # Float threshold value
        self.left = left             # Left DecisionNode (<= threshold)
        self.right = right           # Right DecisionNode (> threshold)
        self.value = value           # Prediction class if leaf
        self.samples = samples       # Number of training samples reaching node
        self.gini = gini             # Node Gini impurity

    def is_leaf(self):
        return self.value is not None

    def to_dict(self):
        if self.is_leaf():
            return {
                "type": "leaf",
                "predicted_class": self.value,
                "class_name": RISK_CLASSES[self.value] if self.value < len(RISK_CLASSES) else "Unknown",
                "samples": self.samples,
                "gini": round(self.gini, 4)
            }
        return {
            "type": "split",
            "feature_index": self.feature,
            "feature_name": FEATURE_NAMES[self.feature] if self.feature < len(FEATURE_NAMES) else f"Feature {self.feature}",
            "threshold": round(self.threshold, 2),
            "samples": self.samples,
            "gini": round(self.gini, 4),
            "left": self.left.to_dict() if self.left else None,
            "right": self.right.to_dict() if self.right else None
        }

class DecisionTree:
    def __init__(self, max_depth=4, min_samples_split=2):
        self.max_depth = max_depth
        self.min_samples_split = min_samples_split
        self.root = None

    def _gini(self, y):
        if len(y) == 0:
            return 0.0
        counts = {}
        for label in y:
            counts[label] = counts.get(label, 0) + 1
        impurity = 1.0
        for count in counts.values():
            p = count / len(y)
            impurity -= p ** 2
        return impurity

    def _best_split(self, X, y, n_sub_features):
        best_gain = -1.0
        best_feature = None
        best_thresh = None
        n_features = len(X[0])
        feature_indices = random.sample(range(n_features), min(n_sub_features, n_features))
        
        current_gini = self._gini(y)
        
        for feat in feature_indices:
            values = sorted(list(set(row[feat] for row in X)))
            for i in range(len(values) - 1):
                thresh = (values[i] + values[i+1]) / 2.0
                left_y = [y[j] for j in range(len(X)) if X[j][feat] <= thresh]
                right_y = [y[j] for j in range(len(X)) if X[j][feat] > thresh]
                
                if len(left_y) == 0 or len(right_y) == 0:
                    continue
                    
                p_left = len(left_y) / len(y)
                p_right = len(right_y) / len(y)
                child_gini = p_left * self._gini(left_y) + p_right * self._gini(right_y)
                gain = current_gini - child_gini
                
                if gain > best_gain:
                    best_gain = gain
                    best_feature = feat
                    best_thresh = thresh
                    
        return best_feature, best_thresh, best_gain

    def _build_tree(self, X, y, depth=0):
        samples = len(y)
        counts = {}
        for lbl in y:
            counts[lbl] = counts.get(lbl, 0) + 1
        majority_class = max(counts.items(), key=lambda item: item[1])[0]
        node_gini = self._gini(y)

        if depth >= self.max_depth or len(set(y)) == 1 or samples < self.min_samples_split:
            return DecisionNode(value=majority_class, samples=samples, gini=node_gini)

        n_sub_features = int(math.sqrt(len(X[0]))) + 1
        feat, thresh, gain = self._best_split(X, y, n_sub_features)

        if feat is None or gain <= 0:
            return DecisionNode(value=majority_class, samples=samples, gini=node_gini)

        left_X = [X[i] for i in range(samples) if X[i][feat] <= thresh]
        left_y = [y[i] for i in range(samples) if X[i][feat] <= thresh]
        right_X = [X[i] for i in range(samples) if X[i][feat] > thresh]
        right_y = [y[i] for i in range(samples) if X[i][feat] > thresh]

        left_child = self._build_tree(left_X, left_y, depth + 1)
        right_child = self._build_tree(right_X, right_y, depth + 1)

        return DecisionNode(feature=feat, threshold=thresh, left=left_child, right=right_child, samples=samples, gini=node_gini)

    def fit(self, X, y):
        self.root = self._build_tree(X, y)

    def predict_sample(self, x):
        node = self.root
        path = []
        while not node.is_leaf():
            val = x[node.feature]
            feat_name = FEATURE_NAMES[node.feature]
            if val <= node.threshold:
                path.append(f"{feat_name} ({val}) <= {node.threshold:.1f} -> Left")
                node = node.left
            else:
                path.append(f"{feat_name} ({val}) > {node.threshold:.1f} -> Right")
                node = node.right
        return node.value, path

class ClinicalRandomForest:
    def __init__(self, n_trees=15, max_depth=3):
        self.n_trees = n_trees
        self.max_depth = max_depth
        self.trees = []
        self.feature_importances = [0.0] * len(FEATURE_NAMES)

    def fit(self, X, y):
        self.trees = []
        n_samples = len(X)
        feat_counts = [0] * len(FEATURE_NAMES)
        
        for _ in range(self.n_trees):
            # Bootstrap sampling
            indices = [random.randint(0, n_samples - 1) for _ in range(n_samples)]
            b_X = [X[i] for i in indices]
            b_y = [y[i] for i in indices]
            
            tree = DecisionTree(max_depth=self.max_depth)
            tree.fit(b_X, b_y)
            self.trees.append(tree)
            
            # Aggregate feature usage
            def count_features(node):
                if node and not node.is_leaf():
                    feat_counts[node.feature] += 1
                    count_features(node.left)
                    count_features(node.right)
            count_features(tree.root)
            
        total_splits = sum(feat_counts) or 1
        self.feature_importances = [round(c / total_splits, 4) for c in feat_counts]

    def predict(self, x):
        votes = []
        paths = []
        for tree in self.trees:
            pred, path = tree.predict_sample(x)
            votes.append(pred)
            paths.append(path)
            
        vote_counts = {}
        for v in votes:
            vote_counts[v] = vote_counts.get(v, 0) + 1
            
        majority = max(vote_counts.items(), key=lambda item: item[1])[0]
        confidence = vote_counts[majority] / len(votes)
        
        # Distribution
        probabilities = {}
        for c_idx, c_name in enumerate(RISK_CLASSES):
            probabilities[c_name] = round(vote_counts.get(c_idx, 0) / len(votes), 4)
            
        return {
            "prediction_class": majority,
            "risk_label": RISK_CLASSES[majority],
            "confidence_percent": round(confidence * 100, 1),
            "class_probabilities": probabilities,
            "sample_decision_path": paths[0] if paths else [],
            "total_trees_voting": len(self.trees),
            "votes_breakdown": {RISK_CLASSES[k]: v for k, v in vote_counts.items()}
        }

def generate_synthetic_training_data(n_samples=250):
    """
    Creates clinically realistic physiological data points.
    Features: [Glucose, SysBP, DiaBP, HR, Age, SpO2, BMI, Cholesterol]
    """
    X = []
    y = []
    
    for _ in range(n_samples):
        age = random.randint(20, 85)
        bmi = round(random.uniform(18.5, 38.0), 1)
        spo2 = round(random.uniform(90.0, 100.0), 1)
        glucose = round(random.uniform(70.0, 260.0), 1)
        sys_bp = round(random.uniform(95.0, 185.0), 1)
        dia_bp = round(sys_bp * 0.65 + random.uniform(-6, 8), 1)
        hr = round(random.uniform(55.0, 125.0), 1)
        cholesterol = round(random.uniform(130.0, 290.0), 1)
        
        # Clinical risk heuristic mapping
        risk_points = 0
        if glucose > 180: risk_points += 3
        elif glucose > 125: risk_points += 1.5
        
        if sys_bp > 160 or dia_bp > 100: risk_points += 3
        elif sys_bp > 135 or dia_bp > 85: risk_points += 1.5
        
        if spo2 < 93: risk_points += 3
        elif spo2 < 96: risk_points += 1.5
        
        if hr > 105 or hr < 50: risk_points += 2
        if bmi > 32: risk_points += 1
        if cholesterol > 240: risk_points += 1.5
        if age > 65: risk_points += 1
        
        if risk_points <= 2:
            label = 0 # Low Risk
        elif risk_points <= 4.5:
            label = 1 # Moderate
        elif risk_points <= 7.5:
            label = 2 # Elevated
        else:
            label = 3 # High Risk
            
        X.append([glucose, sys_bp, dia_bp, hr, age, spo2, bmi, cholesterol])
        y.append(label)
        
    return X, y

# Global pre-trained model instance
_TRAINED_RF = None

def get_trained_model():
    global _TRAINED_RF
    if _TRAINED_RF is None:
        X, y = generate_synthetic_training_data(300)
        _TRAINED_RF = ClinicalRandomForest(n_trees=12, max_depth=3)
        _TRAINED_RF.fit(X, y)
    return _TRAINED_RF

def run_rf_prediction(vitals_dict):
    """
    Evaluates input vitals against the trained Python Random Forest.
    """
    model = get_trained_model()
    
    # Feature vector extraction
    glucose = float(vitals_dict.get("glucose", vitals_dict.get("bloodGlucose", 104)))
    sys_bp = float(vitals_dict.get("sysBP", vitals_dict.get("bpSystolic", 122)))
    dia_bp = float(vitals_dict.get("diaBP", vitals_dict.get("bpDiastolic", 80)))
    hr = float(vitals_dict.get("hr", vitals_dict.get("heartRate", 74)))
    age = float(vitals_dict.get("age", 34))
    spo2 = float(vitals_dict.get("spo2", 98))
    bmi = float(vitals_dict.get("bmi", 24.2))
    chol = float(vitals_dict.get("cholesterol", 185))
    
    sample = [glucose, sys_bp, dia_bp, hr, age, spo2, bmi, chol]
    result = model.predict(sample)
    
    # Add metadata and tree topology of Tree #1 for visualization
    result["feature_importances"] = [
        {"feature": name, "importance": imp}
        for name, imp in zip(FEATURE_NAMES, model.feature_importances)
    ]
    # Sort feature importances descending
    result["feature_importances"].sort(key=lambda x: x["importance"], reverse=True)
    
    if len(model.trees) > 0:
        result["sample_tree_topology"] = model.trees[0].root.to_dict()
        
    result["input_features"] = {
        "Glucose": glucose,
        "Systolic BP": sys_bp,
        "Diastolic BP": dia_bp,
        "Heart Rate": hr,
        "Age": age,
        "SpO2": spo2,
        "BMI": bmi,
        "Cholesterol": chol
    }
    result["algorithm"] = "Pure Python Ensemble Random Forest (Breiman-Gini Ensemble)"
    
    return result

if __name__ == "__main__":
    if len(sys.argv) > 1:
        raw_args = sys.argv[1]
        try:
            params = json.loads(raw_args)
            print(json.dumps(run_rf_prediction(params)))
        except Exception as e:
            print(json.dumps({"error": str(e)}))
    else:
        # Default test
        test_res = run_rf_prediction({"glucose": 178, "sysBP": 155, "diaBP": 95, "hr": 104, "spo2": 93})
        print(json.dumps(test_res, indent=2))
