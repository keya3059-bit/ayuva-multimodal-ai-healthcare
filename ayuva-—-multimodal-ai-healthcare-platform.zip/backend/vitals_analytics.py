#!/usr/bin/env python3
"""
Ayuva Python Backend - Physiological Vitals & Hemodynamics Analytics
Calculates Mean Arterial Pressure (MAP), Shock Index (SI), Modified Early Warning
Score (MEWS), quick Sepsis-related Organ Failure Assessment (qSOFA),
and provides real-time cardiac risk indices.
"""

import json
import math
import sys

def calculate_hemodynamics(hr, sys_bp, dia_bp, spo2, temp, resp_rate=16):
    """
    Computes key critical care and telemetry metrics.
    """
    # 1. Mean Arterial Pressure (MAP) = (2 * DBP + SBP) / 3
    map_val = round((2 * dia_bp + sys_bp) / 3.0, 1)
    
    # 2. Shock Index = HR / SBP (Normal: 0.5 - 0.7; > 0.9 suggests occult shock)
    shock_index = round(hr / max(sys_bp, 1), 2)
    shock_status = "Normal"
    if shock_index >= 0.9:
        shock_status = "Elevated (Impending Shock Risk)"
    elif shock_index > 0.7:
        shock_status = "Borderline / Watchlist"
        
    # 3. Pulse Pressure = SBP - DBP
    pulse_pressure = round(sys_bp - dia_bp, 1)
    
    # 4. qSOFA Score (0 to 3)
    # - Respiratory rate >= 22 breaths/min (+1)
    # - Altered mentation (+0 baseline for ambulatory)
    # - Systolic BP <= 100 mmHg (+1)
    qsofa = 0
    if resp_rate >= 22: qsofa += 1
    if sys_bp <= 100: qsofa += 1
    
    # 5. MEWS Score (Modified Early Warning Score)
    mews = 0
    # SBP component
    if sys_bp <= 70: mews += 3
    elif sys_bp <= 80: mews += 2
    elif sys_bp <= 100: mews += 1
    elif sys_bp >= 200: mews += 2
    
    # HR component
    if hr <= 40: mews += 2
    elif hr <= 50: mews += 1
    elif hr >= 130: mews += 3
    elif hr >= 110: mews += 2
    elif hr >= 100: mews += 1
    
    # Temp component
    if temp < 35.0: mews += 2
    elif temp >= 38.5: mews += 2
    
    # SpO2
    if spo2 < 92: mews += 3
    elif spo2 < 95: mews += 1
    
    triage_color = "EMERALD"
    if mews >= 4 or qsofa >= 2:
        triage_color = "RED"
    elif mews >= 2 or shock_index >= 0.8:
        triage_color = "AMBER"
        
    return {
        "mean_arterial_pressure_mmhg": map_val,
        "map_status": "Optimal (70-100)" if 70 <= map_val <= 105 else ("Hypotensive" if map_val < 70 else "Hypertensive"),
        "shock_index": shock_index,
        "shock_status": shock_status,
        "pulse_pressure_mmhg": pulse_pressure,
        "mews_score": mews,
        "mews_risk": "Low" if mews < 2 else ("Moderate" if mews < 4 else "Critical / Immediate Review"),
        "qsofa_score": qsofa,
        "triage_color": triage_color,
        "perfusion_index": round(spo2 / 100.0 * (map_val / 90.0), 2),
        "engine": "Python Hemodynamic Calculations Kernel (Physio-Py)"
    }

if __name__ == "__main__":
    if len(sys.argv) > 1:
        try:
            p = json.loads(sys.argv[1])
            hr = float(p.get("hr", p.get("heartRate", 74)))
            sys_bp = float(p.get("sysBP", p.get("bpSystolic", 122)))
            dia_bp = float(p.get("diaBP", p.get("bpDiastolic", 80)))
            spo2 = float(p.get("spo2", 98))
            temp = float(p.get("temp", p.get("temperature", 36.8)))
            print(json.dumps(calculate_hemodynamics(hr, sys_bp, dia_bp, spo2, temp)))
        except Exception as e:
            print(json.dumps({"error": str(e)}))
    else:
        print(json.dumps(calculate_hemodynamics(74, 122, 80, 98, 36.8), indent=2))
