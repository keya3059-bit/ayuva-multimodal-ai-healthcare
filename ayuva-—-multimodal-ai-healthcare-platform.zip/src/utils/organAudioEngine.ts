// ============================================================================
// AYUVA CLINICAL INTELLIGENCE: REAL-TIME ORGAN BIOACOUSTIC & AUSCULTATION ENGINE
// Synthesizes physiological heart, brain, lung, kidney, liver, and spine sounds
// using the Web Audio API with zero external audio dependencies.
// ============================================================================

export type OrganSoundType = 'heart' | 'brain' | 'lungs' | 'kidneys' | 'liver' | 'spine';

export type HeartPreset = 'normal-sinus' | 'mitral-murmur' | 'tachycardia-gallop';
export type LungsPreset = 'vesicular-normal' | 'bronchial' | 'wheeze';
export type BrainPreset = 'alpha-relaxed' | 'beta-focused' | 'gamma-cognitive' | 'theta-deep';
export type KidneysPreset = 'renal-arterial' | 'glomerular-filtration';
export type LiverPreset = 'portal-venous-hum' | 'sinusoidal-flow';
export type SpinePreset = 'axial-resonance' | 'vertebral-articulation';

export type OrganAudioPreset = HeartPreset | LungsPreset | BrainPreset | KidneysPreset | LiverPreset | SpinePreset;

export interface OrganAudioState {
  isPlaying: boolean;
  activeOrgan: OrganSoundType;
  volume: number; // 0.0 to 1.0
  activePreset: OrganAudioPreset;
  bpm: number;
  respirationRate: number;
  brainwave: 'alpha' | 'beta' | 'gamma' | 'theta';
  gfr: number;
  portalFlow: number;
  axialLoad: number;
}

class OrganAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private analyser: AnalyserNode | null = null;
  
  private isRunning: boolean = false;
  private currentOrgan: OrganSoundType = 'heart';
  private currentVolume: number = 0.65;
  private currentPreset: OrganAudioPreset = 'normal-sinus';

  // Biometric variables
  private bpm: number = 72;
  private respirationRate: number = 16;
  private brainwave: 'alpha' | 'beta' | 'gamma' | 'theta' = 'beta';
  private gfr: number = 104;
  private portalFlow: number = 1100;
  private axialLoad: number = 950;

  // Active loop timers / nodes
  private loopTimerId: number | null = null;
  private continuousNodes: { [key: string]: AudioNode } = {};
  private noiseBuffer: AudioBuffer | null = null;

  // Listeners for UI state updates
  private stateChangeListeners: ((state: OrganAudioState) => void)[] = [];

  constructor() {
    // Lazy initialize on user interaction
  }

  private initContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtxClass();
      
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 128;
      this.analyser.smoothingTimeConstant = 0.8;

      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(this.currentVolume, this.ctx.currentTime);

      this.masterGain.connect(this.analyser);
      this.analyser.connect(this.ctx.destination);

      // Pre-generate 3 seconds of calibrated white/pink noise
      this.createNoiseBuffer();
    }

    if (this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }

    return this.ctx;
  }

  private createNoiseBuffer() {
    if (!this.ctx) return;
    const bufferSize = this.ctx.sampleRate * 3;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let lastOut = 0.0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      // Pink noise filtering approximation
      data[i] = (lastOut + 0.02 * white) / 1.02;
      lastOut = data[i];
      data[i] *= 3.5;
    }
    this.noiseBuffer = buffer;
  }

  // --------------------------------------------------------------------------
  // STATE & LISTENER MANAGEMENT
  // --------------------------------------------------------------------------
  public subscribe(callback: (state: OrganAudioState) => void): () => void {
    this.stateChangeListeners.push(callback);
    callback(this.getState());
    return () => {
      this.stateChangeListeners = this.stateChangeListeners.filter((cb) => cb !== callback);
    };
  }

  private notify() {
    const state = this.getState();
    this.stateChangeListeners.forEach((cb) => cb(state));
  }

  public getState(): OrganAudioState {
    return {
      isPlaying: this.isRunning,
      activeOrgan: this.currentOrgan,
      volume: this.currentVolume,
      activePreset: this.currentPreset,
      bpm: this.bpm,
      respirationRate: this.respirationRate,
      brainwave: this.brainwave,
      gfr: this.gfr,
      portalFlow: this.portalFlow,
      axialLoad: this.axialLoad
    };
  }

  // --------------------------------------------------------------------------
  // VOLUME & PARAMETER CONTROLS
  // --------------------------------------------------------------------------
  public setVolume(vol: number) {
    this.currentVolume = Math.max(0, Math.min(1, vol));
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.currentVolume, this.ctx.currentTime);
    }
    this.notify();
  }

  public updateParameters(params: {
    bpm?: number;
    respirationRate?: number;
    brainwave?: 'alpha' | 'beta' | 'gamma' | 'theta';
    gfr?: number;
    portalFlow?: number;
    axialLoad?: number;
  }) {
    let changed = false;
    if (params.bpm !== undefined && params.bpm !== this.bpm) {
      this.bpm = params.bpm;
      changed = true;
    }
    if (params.respirationRate !== undefined && params.respirationRate !== this.respirationRate) {
      this.respirationRate = params.respirationRate;
      changed = true;
    }
    if (params.brainwave !== undefined && params.brainwave !== this.brainwave) {
      this.brainwave = params.brainwave;
      changed = true;
    }
    if (params.gfr !== undefined && params.gfr !== this.gfr) {
      this.gfr = params.gfr;
      changed = true;
    }
    if (params.portalFlow !== undefined && params.portalFlow !== this.portalFlow) {
      this.portalFlow = params.portalFlow;
      changed = true;
    }
    if (params.axialLoad !== undefined && params.axialLoad !== this.axialLoad) {
      this.axialLoad = params.axialLoad;
      changed = true;
    }

    if (changed) {
      this.notify();
      // If currently playing, restart loop with updated parameters seamlessly
      if (this.isRunning) {
        this.restartCurrentOrganLoop();
      }
    }
  }

  public setPreset(preset: OrganAudioPreset) {
    this.currentPreset = preset;
    this.notify();
    if (this.isRunning) {
      this.restartCurrentOrganLoop();
    }
  }

  // --------------------------------------------------------------------------
  // START & STOP SOUND
  // --------------------------------------------------------------------------
  public async startSound(organ?: OrganSoundType, preset?: OrganAudioPreset) {
    const ctx = this.initContext();
    if (ctx.state === 'suspended') {
      await ctx.resume();
    }

    if (organ) {
      this.currentOrgan = organ;
      // Default preset for organ if not specified
      if (!preset) {
        this.currentPreset = this.getDefaultPresetForOrgan(organ);
      } else {
        this.currentPreset = preset;
      }
    }

    this.stopCurrentNodes();
    this.isRunning = true;
    this.notify();

    this.playOrganAcoustics(this.currentOrgan);
  }

  public stopSound() {
    this.stopCurrentNodes();
    this.isRunning = false;
    this.notify();
  }

  public toggleSound(organ?: OrganSoundType) {
    if (this.isRunning && (!organ || organ === this.currentOrgan)) {
      this.stopSound();
    } else {
      this.startSound(organ || this.currentOrgan);
    }
  }

  private getDefaultPresetForOrgan(organ: OrganSoundType): OrganAudioPreset {
    switch (organ) {
      case 'heart': return 'normal-sinus';
      case 'brain': return 'beta-focused';
      case 'lungs': return 'vesicular-normal';
      case 'kidneys': return 'renal-arterial';
      case 'liver': return 'portal-venous-hum';
      case 'spine': return 'axial-resonance';
    }
  }

  private stopCurrentNodes() {
    if (this.loopTimerId !== null) {
      window.clearTimeout(this.loopTimerId);
      this.loopTimerId = null;
    }

    Object.keys(this.continuousNodes).forEach((key) => {
      const node = this.continuousNodes[key];
      try {
        if ('stop' in node && typeof (node as any).stop === 'function') {
          (node as any).stop();
        }
        node.disconnect();
      } catch (e) {
        // Safe disconnect
      }
    });
    this.continuousNodes = {};
  }

  private restartCurrentOrganLoop() {
    this.stopCurrentNodes();
    if (this.isRunning) {
      this.playOrganAcoustics(this.currentOrgan);
    }
  }

  // --------------------------------------------------------------------------
  // 1. CARDIAC AUSCULTATION (HEART)
  // --------------------------------------------------------------------------
  private playCardiacBeat() {
    if (!this.isRunning || !this.ctx || !this.masterGain) return;

    const ctx = this.ctx;
    const now = ctx.currentTime;
    const beatInterval = 60 / this.bpm; // in seconds, e.g. 72 BPM = 0.833s

    // Physiological systole interval: approx 35% of cardiac cycle
    const systoleDelay = Math.min(0.28, beatInterval * 0.35);

    // --- S1 Heart Sound ("Lub" - Mitral and Tricuspid Closure) ---
    const s1Gain = ctx.createGain();
    const s1Filter = ctx.createBiquadFilter();
    s1Filter.type = 'lowpass';
    s1Filter.frequency.setValueAtTime(140, now);

    const s1Osc = ctx.createOscillator();
    s1Osc.type = 'sine';
    // Frequency drops slightly from 90Hz to 55Hz (deep resonant thud)
    s1Osc.frequency.setValueAtTime(88, now);
    s1Osc.frequency.exponentialRampToValueAtTime(52, now + 0.12);

    s1Gain.gain.setValueAtTime(0.001, now);
    s1Gain.gain.linearRampToValueAtTime(0.85, now + 0.02);
    s1Gain.gain.exponentialRampToValueAtTime(0.001, now + 0.14);

    s1Osc.connect(s1Filter);
    s1Filter.connect(s1Gain);
    s1Gain.connect(this.masterGain);

    s1Osc.start(now);
    s1Osc.stop(now + 0.16);

    // --- S2 Heart Sound ("Dub" - Aortic and Pulmonic Closure) ---
    const s2Time = now + systoleDelay;
    const s2Gain = ctx.createGain();
    const s2Filter = ctx.createBiquadFilter();
    s2Filter.type = 'lowpass';
    s2Filter.frequency.setValueAtTime(200, s2Time);

    const s2Osc = ctx.createOscillator();
    s2Osc.type = 'sine';
    // Crisp, slightly higher pitch 115Hz to 75Hz
    s2Osc.frequency.setValueAtTime(120, s2Time);
    s2Osc.frequency.exponentialRampToValueAtTime(70, s2Time + 0.09);

    s2Gain.gain.setValueAtTime(0.001, s2Time);
    s2Gain.gain.linearRampToValueAtTime(0.70, s2Time + 0.015);
    s2Gain.gain.exponentialRampToValueAtTime(0.001, s2Time + 0.11);

    s2Osc.connect(s2Filter);
    s2Filter.connect(s2Gain);
    s2Gain.connect(this.masterGain);

    s2Osc.start(s2Time);
    s2Osc.stop(s2Time + 0.13);

    // --- Optional Preset Features (Murmur / Gallop) ---
    if (this.currentPreset === 'mitral-murmur' && this.noiseBuffer) {
      // Systolic whoosh between S1 and S2
      const murmurSource = ctx.createBufferSource();
      murmurSource.buffer = this.noiseBuffer;
      const murmurFilter = ctx.createBiquadFilter();
      murmurFilter.type = 'bandpass';
      murmurFilter.frequency.setValueAtTime(320, now + 0.04);
      murmurFilter.Q.setValueAtTime(2.0, now + 0.04);

      const murmurGain = ctx.createGain();
      murmurGain.gain.setValueAtTime(0.001, now + 0.04);
      murmurGain.gain.linearRampToValueAtTime(0.35, now + 0.08);
      murmurGain.gain.exponentialRampToValueAtTime(0.001, s2Time - 0.02);

      murmurSource.connect(murmurFilter);
      murmurFilter.connect(murmurGain);
      murmurGain.connect(this.masterGain);

      murmurSource.start(now + 0.04);
      murmurSource.stop(s2Time);
    } else if (this.currentPreset === 'tachycardia-gallop') {
      // Third heart sound (S3 gallop during rapid ventricular filling)
      const s3Time = s2Time + 0.14;
      if (s3Time < now + beatInterval) {
        const s3Osc = ctx.createOscillator();
        const s3Gain = ctx.createGain();
        s3Osc.type = 'sine';
        s3Osc.frequency.setValueAtTime(50, s3Time);
        s3Gain.gain.setValueAtTime(0.001, s3Time);
        s3Gain.gain.linearRampToValueAtTime(0.3, s3Time + 0.02);
        s3Gain.gain.exponentialRampToValueAtTime(0.001, s3Time + 0.08);

        s3Osc.connect(s3Gain);
        s3Gain.connect(this.masterGain);
        s3Osc.start(s3Time);
        s3Osc.stop(s3Time + 0.1);
      }
    }

    // Schedule next beat
    this.loopTimerId = window.setTimeout(() => {
      this.playCardiacBeat();
    }, beatInterval * 1000);
  }

  // --------------------------------------------------------------------------
  // 2. NEURO-ACOUSTIC EEG OSCILLATION (BRAIN)
  // --------------------------------------------------------------------------
  private playBrainNeuroAcoustics() {
    if (!this.isRunning || !this.ctx || !this.masterGain) return;
    const ctx = this.ctx;
    const now = ctx.currentTime;

    // Frequencies depending on selected brainwave band
    let carrierFreq = 220; // Carrier tone in Hz
    let modRate = 18;      // Modulation rate in Hz
    let qFactor = 4;

    switch (this.brainwave) {
      case 'alpha':
        carrierFreq = 180;
        modRate = 10; // 10 Hz alpha wave
        break;
      case 'beta':
        carrierFreq = 240;
        modRate = 20; // 20 Hz beta alertness
        break;
      case 'gamma':
        carrierFreq = 380;
        modRate = 42; // 42 Hz high cognitive gamma
        break;
      case 'theta':
        carrierFreq = 136;
        modRate = 6;  // 6 Hz deep theta resonance
        break;
    }

    // Carrier Oscillator (Warm Triangle)
    const carrierOsc = ctx.createOscillator();
    carrierOsc.type = 'triangle';
    carrierOsc.frequency.setValueAtTime(carrierFreq, now);

    // Modulation Oscillator (creates neural oscillation envelope)
    const modOsc = ctx.createOscillator();
    modOsc.type = 'sine';
    modOsc.frequency.setValueAtTime(modRate, now);

    const modGain = ctx.createGain();
    modGain.gain.setValueAtTime(0.25, now);

    // Carrier Gain
    const carrierGain = ctx.createGain();
    carrierGain.gain.setValueAtTime(0.3, now);

    // Soft Synaptic Noise Background
    if (this.noiseBuffer) {
      const noiseSource = ctx.createBufferSource();
      noiseSource.buffer = this.noiseBuffer;
      noiseSource.loop = true;

      const noiseFilter = ctx.createBiquadFilter();
      noiseFilter.type = 'bandpass';
      noiseFilter.frequency.setValueAtTime(carrierFreq * 2.5, now);
      noiseFilter.Q.setValueAtTime(qFactor, now);

      const noiseGain = ctx.createGain();
      noiseGain.gain.setValueAtTime(0.08, now);

      noiseSource.connect(noiseFilter);
      noiseFilter.connect(noiseGain);
      noiseGain.connect(this.masterGain);
      noiseSource.start(now);

      this.continuousNodes['brainNoise'] = noiseSource;
    }

    // Modulate carrier amplitude
    modOsc.connect(carrierGain.gain);
    carrierOsc.connect(carrierGain);
    carrierGain.connect(this.masterGain);

    carrierOsc.start(now);
    modOsc.start(now);

    this.continuousNodes['carrierOsc'] = carrierOsc;
    this.continuousNodes['modOsc'] = modOsc;
    this.continuousNodes['carrierGain'] = carrierGain;
  }

  // --------------------------------------------------------------------------
  // 3. PULMONARY VESICULAR RESPIRATION (LUNGS)
  // --------------------------------------------------------------------------
  private playPulmonaryRespiration() {
    if (!this.isRunning || !this.ctx || !this.masterGain || !this.noiseBuffer) return;

    const ctx = this.ctx;
    const now = ctx.currentTime;
    const breathDuration = 60 / this.respirationRate; // e.g. 16 breaths/min = 3.75s

    // Inhalation: ~55% of duration, Exhalation: ~40%, Pause: ~5%
    const inhaleDuration = breathDuration * 0.52;
    const exhaleDuration = breathDuration * 0.38;

    // --- Inhalation Cycle (Rising vesicular murmur) ---
    const inhaleSource = ctx.createBufferSource();
    inhaleSource.buffer = this.noiseBuffer;

    const inhaleFilter = ctx.createBiquadFilter();
    inhaleFilter.type = 'bandpass';
    inhaleFilter.frequency.setValueAtTime(320, now);
    inhaleFilter.frequency.linearRampToValueAtTime(650, now + inhaleDuration);
    inhaleFilter.Q.setValueAtTime(1.8, now);

    const inhaleGain = ctx.createGain();
    inhaleGain.gain.setValueAtTime(0.001, now);
    inhaleGain.gain.linearRampToValueAtTime(0.55, now + inhaleDuration * 0.7);
    inhaleGain.gain.exponentialRampToValueAtTime(0.001, now + inhaleDuration);

    inhaleSource.connect(inhaleFilter);
    inhaleFilter.connect(inhaleGain);
    inhaleGain.connect(this.masterGain);

    inhaleSource.start(now);
    inhaleSource.stop(now + inhaleDuration + 0.1);

    // --- Exhalation Cycle (Gentler, lower-frequency outflow) ---
    const exhaleStart = now + inhaleDuration + 0.05;
    const exhaleSource = ctx.createBufferSource();
    exhaleSource.buffer = this.noiseBuffer;

    const exhaleFilter = ctx.createBiquadFilter();
    exhaleFilter.type = 'bandpass';
    exhaleFilter.frequency.setValueAtTime(450, exhaleStart);
    exhaleFilter.frequency.linearRampToValueAtTime(260, exhaleStart + exhaleDuration);
    exhaleFilter.Q.setValueAtTime(1.5, exhaleStart);

    const exhaleGain = ctx.createGain();
    exhaleGain.gain.setValueAtTime(0.001, exhaleStart);
    exhaleGain.gain.linearRampToValueAtTime(0.40, exhaleStart + exhaleDuration * 0.4);
    exhaleGain.gain.exponentialRampToValueAtTime(0.001, exhaleStart + exhaleDuration);

    exhaleSource.connect(exhaleFilter);
    exhaleFilter.connect(exhaleGain);
    exhaleGain.connect(this.masterGain);

    exhaleSource.start(exhaleStart);
    exhaleSource.stop(exhaleStart + exhaleDuration + 0.1);

    // Optional wheeze harmonic preset
    if (this.currentPreset === 'wheeze') {
      const wheezeOsc = ctx.createOscillator();
      wheezeOsc.type = 'sine';
      wheezeOsc.frequency.setValueAtTime(580, exhaleStart);
      const wheezeGain = ctx.createGain();
      wheezeGain.gain.setValueAtTime(0.001, exhaleStart);
      wheezeGain.gain.linearRampToValueAtTime(0.2, exhaleStart + exhaleDuration * 0.3);
      wheezeGain.gain.exponentialRampToValueAtTime(0.001, exhaleStart + exhaleDuration);

      wheezeOsc.connect(wheezeGain);
      wheezeGain.connect(this.masterGain);
      wheezeOsc.start(exhaleStart);
      wheezeOsc.stop(exhaleStart + exhaleDuration + 0.1);
    }

    // Schedule next breath
    this.loopTimerId = window.setTimeout(() => {
      this.playPulmonaryRespiration();
    }, breathDuration * 1000);
  }

  // --------------------------------------------------------------------------
  // 4. RENAL HEMODYNAMICS & GLOMERULAR FILTRATION (KIDNEYS)
  // --------------------------------------------------------------------------
  private playRenalHemodynamics() {
    if (!this.isRunning || !this.ctx || !this.masterGain || !this.noiseBuffer) return;

    const ctx = this.ctx;
    const now = ctx.currentTime;
    const pulseInterval = 60 / this.bpm;

    // Rhythmic renal artery systolic surge
    const pulseSource = ctx.createBufferSource();
    pulseSource.buffer = this.noiseBuffer;

    const pulseFilter = ctx.createBiquadFilter();
    pulseFilter.type = 'lowpass';
    pulseFilter.frequency.setValueAtTime(240, now);
    pulseFilter.Q.setValueAtTime(3.0, now);

    const pulseGain = ctx.createGain();
    pulseGain.gain.setValueAtTime(0.001, now);
    pulseGain.gain.linearRampToValueAtTime(0.45, now + 0.08);
    pulseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

    pulseSource.connect(pulseFilter);
    pulseFilter.connect(pulseGain);
    pulseGain.connect(this.masterGain);

    pulseSource.start(now);
    pulseSource.stop(now + 0.4);

    // Continuous glomerular capillary filtration hiss
    if (!this.continuousNodes['filtrationHiss']) {
      const hissSource = ctx.createBufferSource();
      hissSource.buffer = this.noiseBuffer;
      hissSource.loop = true;

      const hissFilter = ctx.createBiquadFilter();
      hissFilter.type = 'bandpass';
      // Scaled by GFR: higher GFR = slightly higher frequency microvascular hiss
      const gfrFreq = 1200 + (this.gfr - 60) * 8;
      hissFilter.frequency.setValueAtTime(gfrFreq, now);
      hissFilter.Q.setValueAtTime(3.5, now);

      const hissGain = ctx.createGain();
      hissGain.gain.setValueAtTime(0.12, now);

      hissSource.connect(hissFilter);
      hissFilter.connect(hissGain);
      hissGain.connect(this.masterGain);

      hissSource.start(now);
      this.continuousNodes['filtrationHiss'] = hissSource;
    }

    this.loopTimerId = window.setTimeout(() => {
      this.playRenalHemodynamics();
    }, pulseInterval * 1000);
  }

  // --------------------------------------------------------------------------
  // 5. PORTAL VENOUS HUM & LIVER SINUSOIDAL FLOW (LIVER)
  // --------------------------------------------------------------------------
  private playLiverVenousHum() {
    if (!this.isRunning || !this.ctx || !this.masterGain || !this.noiseBuffer) return;

    const ctx = this.ctx;
    const now = ctx.currentTime;

    // Low laminar hum (continuous sinusoidal circulation)
    const humOsc = ctx.createOscillator();
    humOsc.type = 'sine';
    const flowFreq = 95 + (this.portalFlow - 700) * 0.04; // 95 - 130 Hz
    humOsc.frequency.setValueAtTime(flowFreq, now);

    const humGain = ctx.createGain();
    humGain.gain.setValueAtTime(0.28, now);

    // Soft fluid turbulent swoosh
    const swooshSource = ctx.createBufferSource();
    swooshSource.buffer = this.noiseBuffer;
    swooshSource.loop = true;

    const swooshFilter = ctx.createBiquadFilter();
    swooshFilter.type = 'lowpass';
    swooshFilter.frequency.setValueAtTime(260, now);
    swooshFilter.Q.setValueAtTime(2.0, now);

    const swooshGain = ctx.createGain();
    swooshGain.gain.setValueAtTime(0.16, now);

    // Fluid turbulence modulation (representing periodic respiratory diaphragmatic compression)
    const lfo = ctx.createOscillator();
    lfo.frequency.setValueAtTime(0.28, now); // ~17 cycles/min
    const lfoGain = ctx.createGain();
    lfoGain.gain.setValueAtTime(0.08, now);

    lfo.connect(lfoGain);
    lfoGain.connect(swooshGain.gain);

    humOsc.connect(humGain);
    humGain.connect(this.masterGain);

    swooshSource.connect(swooshFilter);
    swooshFilter.connect(swooshGain);
    swooshGain.connect(this.masterGain);

    humOsc.start(now);
    swooshSource.start(now);
    lfo.start(now);

    this.continuousNodes['liverHum'] = humOsc;
    this.continuousNodes['liverSwoosh'] = swooshSource;
    this.continuousNodes['liverLFO'] = lfo;
  }

  // --------------------------------------------------------------------------
  // 6. AXIAL BIOMECHANICAL RESONANCE & VERTEBRAL SHOCK ABSORPTION (SPINE)
  // --------------------------------------------------------------------------
  private playSpineResonance() {
    if (!this.isRunning || !this.ctx || !this.masterGain) return;

    const ctx = this.ctx;
    const now = ctx.currentTime;

    // Harmonic deep acoustic tone representing spine load-bearing column
    const spineOsc = ctx.createOscillator();
    spineOsc.type = 'triangle';
    // Frequency scaled by axial load (85 Hz to 160 Hz)
    const axialFreq = 85 + (this.axialLoad - 400) * 0.035;
    spineOsc.frequency.setValueAtTime(axialFreq, now);

    // Secondary sub-harmonic
    const subOsc = ctx.createOscillator();
    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(axialFreq * 0.5, now);

    const spineGain = ctx.createGain();
    spineGain.gain.setValueAtTime(0.24, now);

    const subGain = ctx.createGain();
    subGain.gain.setValueAtTime(0.18, now);

    spineOsc.connect(spineGain);
    subOsc.connect(subGain);
    spineGain.connect(this.masterGain);
    subGain.connect(this.masterGain);

    spineOsc.start(now);
    subOsc.start(now);

    this.continuousNodes['spineOsc'] = spineOsc;
    this.continuousNodes['spineSub'] = subOsc;
  }

  // --------------------------------------------------------------------------
  // MASTER DISPATCHER
  // --------------------------------------------------------------------------
  private playOrganAcoustics(organ: OrganSoundType) {
    switch (organ) {
      case 'heart':
        this.playCardiacBeat();
        break;
      case 'brain':
        this.playBrainNeuroAcoustics();
        break;
      case 'lungs':
        this.playPulmonaryRespiration();
        break;
      case 'kidneys':
        this.playRenalHemodynamics();
        break;
      case 'liver':
        this.playLiverVenousHum();
        break;
      case 'spine':
        this.playSpineResonance();
        break;
    }
  }

  // --------------------------------------------------------------------------
  // INTERACTIVE HOTSPOT BIOACOUSTIC PROBE SOUND
  // Plays an immediate specialized acoustic chirp when clicking any structure
  // --------------------------------------------------------------------------
  public playStructureProbeSound(organ: OrganSoundType, structureName?: string) {
    const ctx = this.initContext();
    if (ctx.state === 'suspended') {
      ctx.resume().catch(() => {});
    }

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const filter = ctx.createBiquadFilter();

    let startFreq = 440;
    let endFreq = 880;

    switch (organ) {
      case 'heart':
        // Deep acoustic cardiac focal tap
        osc.type = 'sine';
        startFreq = 160;
        endFreq = 80;
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(250, now);
        break;
      case 'brain':
        // High synaptic neural chime
        osc.type = 'triangle';
        startFreq = 660;
        endFreq = 990;
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(800, now);
        break;
      case 'lungs':
        // Pulmonary airflow breath chirp
        osc.type = 'sine';
        startFreq = 340;
        endFreq = 520;
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(450, now);
        break;
      case 'kidneys':
        // Glomerular micro-droplet ping
        osc.type = 'sine';
        startFreq = 580;
        endFreq = 420;
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(700, now);
        break;
      case 'liver':
        // Sinusoidal warm resonance
        osc.type = 'triangle';
        startFreq = 260;
        endFreq = 390;
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(400, now);
        break;
      case 'spine':
        // Articular vertebral micro-click
        osc.type = 'sine';
        startFreq = 320;
        endFreq = 140;
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(300, now);
        break;
    }

    osc.frequency.setValueAtTime(startFreq, now);
    osc.frequency.exponentialRampToValueAtTime(endFreq, now + 0.12);

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.linearRampToValueAtTime(0.45 * this.currentVolume, now + 0.02);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

    osc.connect(filter);
    filter.connect(gain);
    if (this.masterGain) {
      gain.connect(this.masterGain);
    } else {
      gain.connect(ctx.destination);
    }

    osc.start(now);
    osc.stop(now + 0.2);
  }

  // --------------------------------------------------------------------------
  // AUDIO VISUALIZER ACCESS
  // --------------------------------------------------------------------------
  public getByteFrequencyData(dataArray: Uint8Array): void {
    if (this.analyser && this.isRunning) {
      this.analyser.getByteFrequencyData(dataArray);
    } else {
      dataArray.fill(0);
    }
  }

  public getByteTimeDomainData(dataArray: Uint8Array): void {
    if (this.analyser && this.isRunning) {
      this.analyser.getByteTimeDomainData(dataArray);
    } else {
      dataArray.fill(128);
    }
  }
}

// Global Singleton Instance
export const organAudioEngine = new OrganAudioEngine();
