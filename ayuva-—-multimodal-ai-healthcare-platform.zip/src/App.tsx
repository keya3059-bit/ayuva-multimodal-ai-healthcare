import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Navbar } from './components/layout/Navbar';
import { Sidebar } from './components/layout/Sidebar';
import { LandingPage } from './components/LandingPage';
import { AuthModal } from './components/AuthModal';

// Patient Components
import { PatientDashboard } from './components/patient/PatientDashboard';
import { SymptomChecker } from './components/patient/SymptomChecker';
import { RandomForestPredictor } from './components/patient/RandomForestPredictor';
import { MultimodalHub } from './components/patient/MultimodalHub';
import { AIChat } from './components/patient/AIChat';
import { MedicineDelivery } from './components/patient/MedicineDelivery';
import { HealthRecords } from './components/patient/HealthRecords';
import { LabAnalyzer } from './components/patient/LabAnalyzer';
import { HealthTrends } from './components/patient/HealthTrends';
import { AppointmentsView } from './components/patient/AppointmentsView';
import { MedicationReminders } from './components/patient/MedicationReminders';
import { DigitalTwin } from './components/patient/DigitalTwin';
import { FamilyCareCircle } from './components/patient/FamilyCareCircle';
import { EmergencySOS } from './components/patient/EmergencySOS';
import { MentalHealth } from './components/patient/MentalHealth';
import { HospitalsNearMe } from './components/patient/HospitalsNearMe';
import { WearablesManager } from './components/patient/WearablesManager';

// Doctor Components
import { DoctorDashboard } from './components/doctor/DoctorDashboard';
import { PatientList } from './components/doctor/PatientList';
import { ClinicalSOAPGenerator } from './components/doctor/ClinicalSOAPGenerator';
import { EHRViewer } from './components/doctor/EHRViewer';
import { TeleconsultationRoom } from './components/doctor/TeleconsultationRoom';

// Admin Components
import { AdminDashboard } from './components/admin/AdminDashboard';
import { FleetControl } from './components/admin/FleetControl';
import { HospitalCapacity } from './components/admin/HospitalCapacity';
import { AIModelMetrics } from './components/admin/AIModelMetrics';

// Python & Hugging Face Hub
import { PythonHub } from './components/python/PythonHub';

// Anatomical Heart & Brain 3D Viewer
import { Anatomical3DViewer } from './components/anatomy/Anatomical3DViewer';

// AYUVA Core Intelligence Stack (XGBoost, SHAP, MONAI, LangGraph, FHIR, Docker/Django)
import { AyuvaIntelligenceStackHub } from './components/intelligence/AyuvaIntelligenceStackHub';

import { INITIAL_VITALS, PATIENTS, INITIAL_USER_PROFILE } from './data/mockData';
import { UserRole, AppSection, VitalsState, Patient, Hospital, UserProfile } from './types';

export default function App() {
  const [currentRole, setCurrentRole] = useState<UserRole>('patient');
  const [currentSection, setCurrentSection] = useState<AppSection>('patient-dashboard');
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true);
  const [showAuthModal, setShowAuthModal] = useState<boolean>(false);
  const [user, setUser] = useState<UserProfile>(INITIAL_USER_PROFILE);
  const [vitals, setVitals] = useState<VitalsState>(INITIAL_VITALS);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [selectedPatient, setSelectedPatient] = useState<Patient>(PATIENTS[0]);

  // Subtle real-time heart rate variation
  useEffect(() => {
    const timer = setInterval(() => {
      setVitals((prev) => ({
        ...prev,
        heartRate: 72 + Math.floor(Math.sin(Date.now() / 3000) * 4),
      }));
    }, 2000);
    return () => clearInterval(timer);
  }, []);

  const handleRoleChange = (role: UserRole) => {
    setCurrentRole(role);
    if (role === 'patient') setCurrentSection('patient-dashboard');
    else if (role === 'doctor') setCurrentSection('doctor-dashboard');
    else if (role === 'admin') setCurrentSection('admin-dashboard');
  };

  const handleBookAtHospital = (hosp: Hospital) => {
    setCurrentSection('appointments');
  };

  const handleSelectPatient = (patient: Patient) => {
    setSelectedPatient(patient);
    setCurrentSection('ehr-viewer');
  };

  return (
    <div className="min-h-screen bg-[#040813] text-slate-100 flex flex-col font-sans selection:bg-[#00d4b4] selection:text-black">
      {/* Top Navigation */}
      <Navbar
        currentRole={currentRole}
        currentSection={currentSection}
        onSelectRole={handleRoleChange}
        onNavigate={setCurrentSection}
        onOpenAuth={() => setShowAuthModal(true)}
        isLoggedIn={isLoggedIn}
        onLogout={() => {
          setIsLoggedIn(false);
          setCurrentSection('landing');
        }}
        mobileMenuOpen={mobileMenuOpen}
        setMobileMenuOpen={setMobileMenuOpen}
      />

      {/* Main Body */}
      {currentSection === 'landing' ? (
        <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
          <LandingPage
            onSelectRole={handleRoleChange}
            onNavigate={setCurrentSection}
            onOpenAuth={() => setShowAuthModal(true)}
          />
        </main>
      ) : (
        <div className="flex-1 flex">
          {/* Sidebar */}
          <Sidebar
            currentRole={currentRole}
            currentSection={currentSection}
            onNavigate={setCurrentSection}
            mobileMenuOpen={mobileMenuOpen}
            setMobileMenuOpen={setMobileMenuOpen}
          />

          {/* Dynamic Content View Container with Smooth Route/Section Animations */}
          <main className="flex-1 md:pl-64 min-w-0">
            <div className="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
              <AnimatePresence mode="wait">
                <motion.div
                  key={currentSection}
                  initial={{ opacity: 0, y: 14 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.22, ease: "easeOut" }}
                >
                  {/* PATIENT VIEWS */}
                  {currentSection === 'patient-dashboard' && (
                    <PatientDashboard
                      user={user}
                      vitals={vitals}
                      onNavigate={setCurrentSection}
                      onSyncVitals={() => {
                        setVitals((prev) => ({
                          ...prev,
                          heartRate: 72 + Math.floor(Math.random() * 6),
                          bloodGlucose: 108 + Math.floor(Math.random() * 8),
                          spo2: 98,
                          temperature: 98.6,
                        }));
                      }}
                      onTriggerSOS={() => setCurrentSection('emergency-sos')}
                    />
                  )}
                  {currentSection === 'symptom-checker' && <SymptomChecker />}
                  {currentSection === 'random-forest' && <RandomForestPredictor />}
                  {currentSection === 'multimodal-hub' && <MultimodalHub vitals={vitals} />}
                  {currentSection === 'ai-chat' && <AIChat user={user} vitals={vitals} />}
                  {currentSection === 'medicine-delivery' && <MedicineDelivery />}
                  {currentSection === 'health-records' && <HealthRecords />}
                  {currentSection === 'lab-analyzer' && <LabAnalyzer />}
                  {currentSection === 'health-trends' && <HealthTrends />}
                  {currentSection === 'appointments' && <AppointmentsView />}
                  {currentSection === 'medication-reminders' && <MedicationReminders />}
                  {currentSection === 'digital-twin' && (
                    <DigitalTwin vitals={vitals} onNavigate={setCurrentSection} />
                  )}
                  {currentSection === 'family-care' && <FamilyCareCircle />}
                  {currentSection === 'emergency-sos' && <EmergencySOS />}
                  {currentSection === 'mental-health' && <MentalHealth />}
                  {currentSection === 'hospitals-near-me' && (
                    <HospitalsNearMe onBookAtHospital={handleBookAtHospital} />
                  )}
                  {currentSection === 'wearables' && <WearablesManager />}

                  {/* DOCTOR VIEWS */}
                  {currentSection === 'doctor-dashboard' && (
                    <DoctorDashboard
                      onNavigate={setCurrentSection}
                      onSelectPatient={handleSelectPatient}
                    />
                  )}
                  {currentSection === 'doctor-patients' && (
                    <PatientList onSelectPatient={handleSelectPatient} />
                  )}
                  {currentSection === 'soap-generator' && <ClinicalSOAPGenerator />}
                  {currentSection === 'ehr-viewer' && (
                    <EHRViewer
                      patient={selectedPatient}
                      onBack={() => setCurrentSection('doctor-patients')}
                      onOpenSOAP={() => setCurrentSection('soap-generator')}
                    />
                  )}
                  {currentSection === 'teleconsultation' && (
                    <TeleconsultationRoom
                      patient={selectedPatient}
                      onEndCall={() => setCurrentSection('doctor-dashboard')}
                    />
                  )}

                  {/* ADMIN VIEWS */}
                  {currentSection === 'admin-dashboard' && (
                    <AdminDashboard onNavigate={setCurrentSection} />
                  )}
                  {currentSection === 'admin-fleet' && <FleetControl />}
                  {currentSection === 'admin-capacity' && <HospitalCapacity />}
                  {currentSection === 'admin-models' && <AIModelMetrics />}

                  {/* PYTHON & HUGGING FACE BACKEND HUB */}
                  {currentSection === 'python-hub' && <PythonHub />}

                  {/* ANATOMICAL HEART & BRAIN 3D VIEWER */}
                  {currentSection === 'anatomical-models' && <Anatomical3DViewer />}

                  {/* AYUVA CORE INTELLIGENCE STACK (XGBoost, SHAP, MONAI, LangGraph, FHIR, Docker) */}
                  {currentSection === 'ai-intelligence-stack' && <AyuvaIntelligenceStackHub />}
                </motion.div>
              </AnimatePresence>
            </div>
          </main>
        </div>
      )}

      {/* Authentication Modal */}
      {showAuthModal && (
        <AuthModal
          onClose={() => setShowAuthModal(false)}
          onSuccess={(role) => {
            setIsLoggedIn(true);
            setShowAuthModal(false);
            handleRoleChange(role);
          }}
        />
      )}
    </div>
  );
}
