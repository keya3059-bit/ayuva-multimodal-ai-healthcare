export type UserRole = 'patient' | 'doctor' | 'admin';
export type PortalType = UserRole;

export type AppSection =
  | 'landing'
  // Patient Sections
  | 'patient-dashboard'
  | 'symptom-checker'
  | 'random-forest'
  | 'multimodal-hub'
  | 'ai-chat'
  | 'medicine-delivery'
  | 'health-records'
  | 'lab-analyzer'
  | 'health-trends'
  | 'appointments'
  | 'medication-reminders'
  | 'digital-twin'
  | 'family-care'
  | 'emergency-sos'
  | 'mental-health'
  | 'hospitals-near-me'
  | 'wearables'
  // Doctor Sections
  | 'doctor-dashboard'
  | 'doctor-patients'
  | 'soap-generator'
  | 'ehr-viewer'
  | 'teleconsultation'
  // Admin Sections
  | 'admin-dashboard'
  | 'admin-fleet'
  | 'admin-capacity'
  | 'admin-models'
  // Python & Hugging Face Hub
  | 'python-hub'
  // Anatomical Heart & Brain 3D Detailing Models
  | 'anatomical-models'
  // Complete AI, Vision, NLP, FHIR & Microservices Stack
  | 'ai-intelligence-stack';

export interface UserProfile {
  id: string;
  name: string;
  role: string;
  avatar: string;
  portal: UserRole;
  age?: number;
  email?: string;
  phone?: string;
}

export interface VitalsState {
  heartRate: number;
  spo2: number;
  temperature: number;
  bloodGlucose: number;
  bpSystolic: number;
  bpDiastolic: number;
}

export interface Appointment {
  id: string;
  doctorName: string;
  specialty: string;
  date: string;
  time: string;
  type: 'In-Person' | 'Telemedicine' | 'AI-Assisted';
  status: 'Confirmed' | 'Pending' | 'Completed' | 'Cancelled';
  symptoms?: string;
  hospital?: string;
}

export interface Medication {
  id: string | number;
  name: string;
  dosage?: string;
  dose?: string;
  frequency?: string;
  freq?: string;
  time?: string;
  times?: string[];
  notes?: string;
  icon?: string;
  taken: boolean | boolean[];
  remaining?: number;
}

export interface LabTestItem {
  name: string;
  val: string;
  range: string;
  status: 'ok' | 'warn' | 'danger';
  label: string;
}

export interface LabReport {
  id: string;
  title: string;
  date: string;
  facility: string;
  tests: LabTestItem[];
  prompt: string;
  summary?: string;
}

export interface Hospital {
  id: string;
  name: string;
  subtitle?: string;
  specialties: string[];
  distance?: string;
  distanceKm?: number;
  address: string;
  totalBeds: number;
  availableBeds: number;
  availPercent: number;
  status: 'OPEN' | 'MODERATE' | 'HIGH LOAD';
  waitTime: string;
  phone: string;
}

export interface NotificationItem {
  id: string;
  title: string;
  subtitle: string;
  time: string;
  type: 'urgent' | 'info' | 'ok';
  read?: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

export interface HealthGoal {
  id: string;
  title: string;
  category: string;
  icon: string;
  progress: number;
  deadline: string;
  color: string;
}

export interface TimelineEvent {
  id: string;
  date: string;
  type: 'lab' | 'procedure' | 'diagnosis' | 'medication';
  icon: string;
  title: string;
  desc: string;
  tag: string;
}

export interface FleetUnit {
  id: string;
  name: string;
  type: 'ALS' | 'BLS' | 'Neonatal' | 'Drone' | 'AMBULANCE' | 'DELIVERY';
  equipment: string;
  status: 'AVAILABLE' | 'DEPLOYED' | 'EN ROUTE';
  eta?: string;
  lat: number;
  lng: number;
}

export interface Department {
  name: string;
  icon: string;
  head: string;
  doctorsCount: number;
  beds: number;
  occupancyPct: number;
  opdToday: number;
  status: 'Normal' | 'Busy' | 'Critical';
}

export interface Patient {
  id: string;
  name: string;
  age: number;
  gender: string;
  condition: string;
  status: 'Stable' | 'Under Review' | 'Critical';
  room: string;
  doctor: string;
  avatar: string;
  vitals: {
    heartRate: number;
    spo2: number;
    bloodGlucose: number;
    temperature: number;
  };
}

export interface FamilyMember {
  id: string;
  name: string;
  relation: string;
  avatar: string;
  vitals: {
    hr: number;
    bp: string;
    sugar: number;
  };
  status: 'Normal' | 'Elevated' | 'Attention Required';
  lastUpdate: string;
}

export interface HealthRecord {
  id: string;
  title: string;
  date: string;
  category?: string;
  type: string;
  facility?: string;
  doctor: string;
  summary: string;
  fileSize: string;
  size?: string;
}

export interface DeliveryOrder {
  id: string;
  medicationName: string;
  pharmacy: string;
  deliveryType: 'Autonomous Electric Van' | 'Drone Rapid Dispatch';
  status: 'PREPARING' | 'IN_TRANSIT' | 'DELIVERED';
  eta: string;
  trackingId: string;
  lat: number;
  lng: number;
}
