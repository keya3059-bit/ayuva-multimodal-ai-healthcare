import React, { useState, useEffect } from 'react';
import {
  Cpu,
  Terminal,
  Play,
  CheckCircle2,
  AlertTriangle,
  Flame,
  Activity,
  Sparkles,
  Layers,
  FileCode,
  ShieldCheck,
  RefreshCw,
  Zap,
  BookOpen,
  Pill,
  GitBranch,
  Stethoscope,
  Info
} from 'lucide-react';
import {
  getPythonStatus,
  getPythonModules,
  runHuggingFaceInference,
  runPythonRandomForest,
  runPythonBiomedicalNLP,
  checkPythonDrugInteractions,
  runPythonVitalsAnalytics,
  executePythonCode
} from '../../services/api';

type TabType = 'huggingface' | 'random-forest' | 'bio-nlp' | 'drug-checker' | 'code-studio' | 'architecture';

const HF_PRESETS = [
  {
    model: 'Bio_ClinicalBERT',
    label: 'Bio_ClinicalBERT (Biomedical NER)',
    task: 'Token Classification & NER',
    defaultInput: 'Patient prescribed Metformin 500mg BID and Atorvastatin 10mg HS. Reports mild angina and dyspnea. BP recorded at 138/88 mmHg.',
    description: 'Pre-trained on MIMIC-III EHR clinical notes for extracting clinical tokens, anatomy, conditions, and pharmacological entities.'
  },
  {
    model: 'BART-Medical-Triage',
    label: 'BART Zero-Shot Medical Triage',
    task: 'Zero-Shot Clinical Classification',
    defaultInput: 'Sudden onset crushing retrosternal chest pain radiating to left shoulder with diaphoresis and shortness of breath starting 20 minutes ago.',
    candidateLabels: ['Acute Cardiology', 'Endocrine & Diabetes', 'Respiratory / Pulmonology', 'Emergency & Trauma', 'General Medicine'],
    description: 'Classifies urgent patient symptoms into specialized hospital departments and triage pathways with confidence scores.'
  },
  {
    model: 'Clinical-Urgency-SST2',
    label: 'Clinical Urgency & Distress Model',
    task: 'Text Classification & Urgency',
    defaultInput: 'I feel excruciating pain in my upper abdomen and cannot keep liquids down. Pain score is 9/10.',
    description: 'DistilBERT model tuned for detecting subjective patient distress, acute pain intensity, and triage criticality.'
  },
  {
    model: 'Medical-Summarizer',
    label: 'BART Clinical Note Summarizer',
    task: 'Abstractive Clinical Summarization',
    defaultInput: 'A 58-year-old male with long-standing Type 2 Diabetes and stage 2 hypertension presents for routine six-month evaluation. Patient reports adherence to Metformin 1000mg BID and Telmisartan 40mg daily. Denies chest pain, palpitations, or visual changes. Fasting blood glucose was 134 mg/dL and HbA1c is 7.2%. Blood pressure today is 132/84 mmHg. Recommended continuing current pharmacotherapy and scheduled follow-up in 3 months.',
    description: 'Condenses verbose doctor-patient encounter transcripts into high-yield structured electronic health record summaries.'
  },
  {
    model: 'PubMedBERT',
    label: 'PubMedBERT (Research & Guidelines)',
    task: 'Clinical Feature Extraction',
    defaultInput: 'Evaluation of GLP-1 receptor agonists versus SGLT2 inhibitors for cardiovascular outcome reduction in diabetic kidney disease.',
    description: 'State-of-the-art transformer pre-trained on biomedical literature from PubMed abstracts and PMC full text.'
  },
  {
    model: 'Llama-3-Med',
    label: 'Meta Llama-3 8B Clinical Reasoning',
    task: 'Differential Diagnostic Reasoning',
    defaultInput: 'Patient with microalbuminuria, HbA1c 8.1%, and mild peripheral neuropathy. What secondary organ screenings are indicated?',
    description: 'High-parameter generative clinical reasoning model providing comprehensive guideline-aligned treatment suggestions.'
  }
];

const CODE_PRESETS = [
  {
    title: 'Train Random Forest on Vitals',
    code: `# Python Clinical Random Forest Simulation
import clinical_random_forest
import json

# Input patient telemetry
patient_vitals = {
    "glucose": 182,
    "sysBP": 158,
    "diaBP": 96,
    "hr": 102,
    "age": 58,
    "spo2": 94,
    "bmi": 29.4,
    "cholesterol": 245
}

# Run multi-tree ensemble inference
result = clinical_random_forest.run_rf_prediction(patient_vitals)

print("=== AYUVA ENSEMBLE RANDOM FOREST PREDICTION ===")
print(f"Risk Assessment: {result['risk_label']}")
print(f"Confidence: {result['confidence_percent']}%")
print(f"Trees Polled: {result['total_trees_voting']}")
print("\\nClass Probabilities:")
for label, prob in result['class_probabilities'].items():
    print(f"  - {label}: {prob * 100:.1f}%")

print("\\nSample Decision Path:")
for step in result['sample_decision_path']:
    print(f"  -> {step}")
`
  },
  {
    title: 'Hugging Face BioBERT Clinical Extraction',
    code: `# Hugging Face Clinical Pipeline Execution
import huggingface_service

clinical_note = """
Patient presents with bilateral lower extremity edema, persistent dyspnea,
and intermittent angina. Currently taking Metformin 500mg, Atorvastatin 20mg,
and Furosemide 40mg. Resting pulse 92 bpm, blood pressure 144/92 mmHg.
"""

result = huggingface_service.run_hf_inference({
    "model": "Bio_ClinicalBERT",
    "input": clinical_note
})

print("=== HUGGING FACE INFERENCE PIPELINE ===")
print(f"Model ID: {result['model_id']}")
print(f"Engine: {result.get('note', 'Cloud Inference')}")
print(f"Total Entities Extracted: {result['result'].get('total_entities', 0)}")
print("\\nExtracted Entities:")
for ent in result['result'].get('entities', []):
    print(f"  [{ent['entity_group']}] '{ent['word']}' (Confidence: {ent['score'] * 100:.1f}%)")
`
  },
  {
    title: 'Pharmacology CYP450 Interaction Matrix',
    code: `# Cytochrome P450 Drug-Drug Conflict Checker
import drug_interactions

regimen = ["Warfarin", "Amiodarone", "Metformin", "Omeprazole", "Clopidogrel"]

analysis = drug_interactions.check_drug_interactions(regimen)

print("=== CLINICAL PHARMACOKINETICS REPORT ===")
print(f"Analyzed Medications: {', '.join(analysis['analyzed_medications'])}")
print(f"Total Interactions Detected: {analysis['interaction_count']}")
print(f"Maximum Severity Level: {analysis['maximum_severity']}")

for item in analysis['interactions']:
    print(f"\\n⚠️ [{item['severity'].upper()}] {' + '.join(item['drugs'])}")
    print(f"   Mechanism: {item['mechanism']}")
    print(f"   Clinical Detail: {item['clinical_detail']}")
    print(f"   Action: {item['recommendation']}")
`
  },
  {
    title: 'Hemodynamics, Shock Index & MEWS',
    code: `# Hemodynamic Telemetry & Early Warning Scoring
import vitals_analytics

# Vitals parameters
hr = 114
sys_bp = 88
dia_bp = 56
spo2 = 91
temp = 38.6

hemo = vitals_analytics.calculate_hemodynamics(hr, sys_bp, dia_bp, spo2, temp)

print("=== HEMODYNAMIC & SEPSIS RISK CALCULATIONS ===")
print(f"Mean Arterial Pressure (MAP): {hemo['mean_arterial_pressure_mmhg']} mmHg ({hemo['map_status']})")
print(f"Shock Index (HR/SBP): {hemo['shock_index']} ({hemo['shock_status']})")
print(f"Modified Early Warning Score (MEWS): {hemo['mews_score']} -> {hemo['mews_risk']}")
print(f"qSOFA Score: {hemo['qsofa_score']}/3")
print(f"Triage Alert Code: {hemo['triage_color']}")
`
  }
];

export const PythonHub: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('huggingface');
  const [systemStatus, setSystemStatus] = useState<any>(null);
  const [modulesList, setModulesList] = useState<any[]>([]);
  const [loadingStatus, setLoadingStatus] = useState<boolean>(true);

  // Hugging Face State
  const [selectedHfIndex, setSelectedHfIndex] = useState<number>(0);
  const [hfInput, setHfInput] = useState<string>(HF_PRESETS[0].defaultInput);
  const [hfToken, setHfToken] = useState<string>('');
  const [hfLoading, setHfLoading] = useState<boolean>(false);
  const [hfResponse, setHfResponse] = useState<any>(null);

  // Random Forest State
  const [rfVitals, setRfVitals] = useState({
    glucose: 148,
    sysBP: 138,
    diaBP: 88,
    hr: 78,
    age: 48,
    spo2: 97,
    bmi: 26.5,
    cholesterol: 210
  });
  const [rfLoading, setRfLoading] = useState<boolean>(false);
  const [rfResponse, setRfResponse] = useState<any>(null);

  // Bio-NLP State
  const [nlpText, setNlpText] = useState<string>(
    'Patient denies chest pain and palpitations. Advised Metformin 500mg BID and Atorvastatin 10mg daily for pre-diabetes and mild hypertension. BP 128/82 mmHg.'
  );
  const [nlpLoading, setNlpLoading] = useState<boolean>(false);
  const [nlpResponse, setNlpResponse] = useState<any>(null);

  // Drug Interaction State
  const [drugList, setDrugList] = useState<string[]>([
    'Metformin 500mg',
    'Atorvastatin 10mg',
    'Telmisartan 40mg'
  ]);
  const [newDrugInput, setNewDrugInput] = useState<string>('');
  const [drugLoading, setDrugLoading] = useState<boolean>(false);
  const [drugResponse, setDrugResponse] = useState<any>(null);

  // Code Studio State
  const [selectedCodePreset, setSelectedCodePreset] = useState<number>(0);
  const [pythonCode, setPythonCode] = useState<string>(CODE_PRESETS[0].code);
  const [codeRunning, setCodeRunning] = useState<boolean>(false);
  const [codeOutput, setCodeOutput] = useState<any>(null);

  // Fetch Python backend system status on mount
  useEffect(() => {
    async function loadStatus() {
      try {
        setLoadingStatus(true);
        const status = await getPythonStatus();
        setSystemStatus(status);
        const modRes = await getPythonModules();
        if (modRes?.modules) {
          setModulesList(modRes.modules);
        }
      } catch (err) {
        console.warn('Could not fetch Python status:', err);
      } finally {
        setLoadingStatus(false);
      }
    }
    loadStatus();
  }, []);

  // Update HF input when preset changes
  const handleSelectHfPreset = (idx: number) => {
    setSelectedHfIndex(idx);
    setHfInput(HF_PRESETS[idx].defaultInput);
    setHfResponse(null);
  };

  // Run Hugging Face Inference
  const handleRunHf = async () => {
    try {
      setHfLoading(true);
      const preset = HF_PRESETS[selectedHfIndex];
      const res = await runHuggingFaceInference(
        preset.model,
        hfInput,
        hfToken || undefined,
        preset.candidateLabels
      );
      setHfResponse(res);
    } catch (err: any) {
      setHfResponse({ error: err.message });
    } finally {
      setHfLoading(false);
    }
  };

  // Run Random Forest Inference
  const handleRunRf = async () => {
    try {
      setRfLoading(true);
      const res = await runPythonRandomForest(rfVitals);
      setRfResponse(res);
    } catch (err: any) {
      setRfResponse({ error: err.message });
    } finally {
      setRfLoading(false);
    }
  };

  // Run Bio-NLP
  const handleRunNlp = async () => {
    try {
      setNlpLoading(true);
      const res = await runPythonBiomedicalNLP(nlpText);
      setNlpResponse(res);
    } catch (err: any) {
      setNlpResponse({ error: err.message });
    } finally {
      setNlpLoading(false);
    }
  };

  // Run Drug Interaction
  const handleRunDrugCheck = async () => {
    try {
      setDrugLoading(true);
      const res = await checkPythonDrugInteractions(drugList);
      setDrugResponse(res);
    } catch (err: any) {
      setDrugResponse({ error: err.message });
    } finally {
      setDrugLoading(false);
    }
  };

  // Execute Python Code in Sandbox
  const handleExecuteCode = async () => {
    try {
      setCodeRunning(true);
      const res = await executePythonCode(pythonCode);
      setCodeOutput(res);
    } catch (err: any) {
      setCodeOutput({ success: false, error: err.message });
    } finally {
      setCodeRunning(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-[#0a192f] via-[#0d2137] to-[#0a192f] border border-[#00d4b4]/30 shadow-xl relative overflow-hidden">
        <div className="absolute -right-8 -bottom-8 w-64 h-64 bg-[#00d4b4]/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-8 -top-8 w-64 h-64 bg-[#4f8cff]/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-semibold bg-[#00d4b4]/20 text-[#00d4b4] border border-[#00d4b4]/40 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#00d4b4] animate-pulse" />
                PYTHON 3.10 BACKEND ENGINE
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-semibold bg-[#4f8cff]/20 text-[#4f8cff] border border-[#4f8cff]/40">
                HUGGING FACE MODEL HUB
              </span>
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white flex items-center gap-2.5">
              <Cpu className="w-7 h-7 text-[#00d4b4]" />
              Python Clinical Machine Learning Suite
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl mt-1">
              Integrated Python server-side microservice hosting Hugging Face biomedical transformers,
              pure Python Random Forest ensembles, clinical NLP entity extraction, and live code execution.
            </p>
          </div>

          {/* Quick System Badge */}
          <div className="flex items-center gap-3 bg-[#050914]/80 p-3 rounded-xl border border-white/10 text-xs font-mono">
            <div>
              <div className="text-slate-400 text-[10px]">PYTHON RUNTIME</div>
              <div className="text-emerald-400 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                {systemStatus?.version ? `Python ${systemStatus.version}` : 'Python 3.10.12'}
              </div>
            </div>
            <div className="h-8 w-px bg-white/10" />
            <div>
              <div className="text-slate-400 text-[10px]">HF PIPELINE</div>
              <div className="text-[#00d4b4] font-semibold">Native & API Ready</div>
            </div>
            <div className="h-8 w-px bg-white/10" />
            <div>
              <div className="text-slate-400 text-[10px]">IPC CHANNEL</div>
              <div className="text-purple-400 font-semibold">JSON-RPC / Stdout</div>
            </div>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-2 overflow-x-auto pt-6 border-t border-white/10 mt-6 no-scrollbar">
          {[
            { id: 'huggingface', label: 'Hugging Face Models', icon: Sparkles },
            { id: 'random-forest', label: 'Random Forest Ensemble', icon: GitBranch },
            { id: 'bio-nlp', label: 'Biomedical NER & NLP', icon: Stethoscope },
            { id: 'drug-checker', label: 'Pharmacology CYP450', icon: Pill },
            { id: 'code-studio', label: 'Python Code Studio (REPL)', icon: Terminal },
            { id: 'architecture', label: 'Backend Architecture', icon: Layers },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-medium whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-[#00d4b4] text-black font-semibold shadow-lg shadow-[#00d4b4]/20'
                    : 'bg-[#050914]/60 text-slate-300 hover:text-white hover:bg-white/10 border border-white/5'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-black' : 'text-[#00d4b4]'}`} />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* TAB 1: HUGGING FACE MODELS */}
      {activeTab === 'huggingface' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Model Selector & Config */}
          <div className="lg:col-span-5 space-y-4">
            <div className="p-5 rounded-2xl bg-[#080e1c] border border-white/10 space-y-4">
              <h2 className="text-sm font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-[#00d4b4]" />
                Select Hugging Face Model
              </h2>

              <div className="space-y-2">
                {HF_PRESETS.map((preset, idx) => (
                  <div
                    key={preset.model}
                    onClick={() => handleSelectHfPreset(idx)}
                    className={`p-3 rounded-xl border cursor-pointer transition-all ${
                      selectedHfIndex === idx
                        ? 'bg-[#00d4b4]/10 border-[#00d4b4] text-white'
                        : 'bg-[#050914] border-white/5 text-slate-400 hover:border-white/20 hover:text-slate-200'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs font-semibold">
                      <span className={selectedHfIndex === idx ? 'text-[#00d4b4]' : 'text-slate-200'}>
                        {preset.label}
                      </span>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-white/5 text-slate-400">
                        {preset.task}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                      {preset.description}
                    </p>
                  </div>
                ))}
              </div>

              {/* Optional Token input */}
              <div className="pt-3 border-t border-white/10">
                <label className="text-[11px] font-mono text-slate-400 flex items-center justify-between">
                  <span>HUGGING FACE API TOKEN (OPTIONAL)</span>
                  <span className="text-slate-500">Auto-falls back to Python kernel</span>
                </label>
                <input
                  type="password"
                  placeholder="hf_xxxxxxxxxxxxxxxxxxxx (Optional)"
                  value={hfToken}
                  onChange={(e) => setHfToken(e.target.value)}
                  className="mt-1.5 w-full px-3 py-2 rounded-xl bg-[#050914] border border-white/10 text-xs font-mono text-white placeholder-slate-600 focus:outline-none focus:border-[#00d4b4]"
                />
              </div>
            </div>
          </div>

          {/* Right Column: Input Prompt & Inference Runner */}
          <div className="lg:col-span-7 space-y-4">
            <div className="p-5 rounded-2xl bg-[#080e1c] border border-white/10 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-semibold text-white">
                    {HF_PRESETS[selectedHfIndex].label}
                  </h3>
                  <div className="text-xs font-mono text-[#00d4b4] mt-0.5">
                    Pipeline: {HF_PRESETS[selectedHfIndex].task}
                  </div>
                </div>
                <button
                  onClick={handleRunHf}
                  disabled={hfLoading}
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black text-xs font-bold flex items-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-50"
                >
                  {hfLoading ? (
                    <>
                      <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                      RUNNING INFERENCE...
                    </>
                  ) : (
                    <>
                      <Play className="w-3.5 h-3.5 fill-black" />
                      EXECUTE MODEL
                    </>
                  )}
                </button>
              </div>

              {/* Input Textarea */}
              <div>
                <label className="text-[11px] font-mono text-slate-400 mb-1.5 block">
                  CLINICAL INPUT TEXT / PROMPT
                </label>
                <textarea
                  rows={4}
                  value={hfInput}
                  onChange={(e) => setHfInput(e.target.value)}
                  className="w-full p-3 rounded-xl bg-[#050914] border border-white/10 text-xs text-slate-100 font-sans focus:outline-none focus:border-[#00d4b4] leading-relaxed resize-none"
                />
              </div>

              {/* Candidate Labels if Zero Shot */}
              {HF_PRESETS[selectedHfIndex].candidateLabels && (
                <div>
                  <label className="text-[11px] font-mono text-slate-400 mb-1 block">
                    CANDIDATE MEDICAL SPECIALTIES
                  </label>
                  <div className="flex flex-wrap gap-1.5">
                    {HF_PRESETS[selectedHfIndex].candidateLabels?.map((lbl) => (
                      <span
                        key={lbl}
                        className="px-2 py-0.5 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-400 text-[11px] font-mono"
                      >
                        {lbl}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Inference Result Output */}
              {hfResponse && (
                <div className="mt-4 pt-4 border-t border-white/10 space-y-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-300 flex items-center gap-1.5">
                      <Zap className="w-3.5 h-3.5 text-amber-400" />
                      Inference Output
                    </span>
                    <span className="font-mono text-[11px] text-slate-400">
                      Source: {hfResponse.source || 'python_native_engine'}
                    </span>
                  </div>

                  {/* Render tailored results depending on task */}
                  {hfResponse.result?.labels && (
                    <div className="space-y-2">
                      <div className="text-xs font-medium text-slate-400">Classification Probabilities:</div>
                      {hfResponse.result.labels.map((lbl: string, i: number) => {
                        const score = hfResponse.result.scores[i];
                        const pct = Math.round(score * 100);
                        return (
                          <div key={lbl} className="space-y-1">
                            <div className="flex justify-between text-xs">
                              <span className="text-slate-200 font-medium">{lbl}</span>
                              <span className="font-mono text-[#00d4b4]">{pct}%</span>
                            </div>
                            <div className="w-full h-1.5 rounded-full bg-white/10 overflow-hidden">
                              <div
                                className="h-full bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] rounded-full"
                                style={{ width: `${pct}%` }}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}

                  {hfResponse.result?.entities && (
                    <div className="space-y-2">
                      <div className="text-xs font-medium text-slate-400">
                        Extracted Biomedical Entities ({hfResponse.result.total_entities}):
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {hfResponse.result.entities.map((ent: any, idx: number) => {
                          const isMed = ent.entity_group === 'MEDICATION';
                          const isCond = ent.entity_group === 'CONDITION';
                          const isVital = ent.entity_group === 'VITAL_SIGN';
                          const bg = isMed
                            ? 'bg-purple-500/20 text-purple-300 border-purple-500/40'
                            : isCond
                            ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                            : isVital
                            ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                            : 'bg-blue-500/20 text-blue-300 border-blue-500/40';

                          return (
                            <div
                              key={idx}
                              className={`px-2.5 py-1 rounded-lg border text-xs font-mono flex items-center gap-1.5 ${bg}`}
                            >
                              <span className="font-bold">{ent.word}</span>
                              <span className="text-[10px] opacity-75">({ent.entity_group})</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {hfResponse.result?.[0]?.summary_text && (
                    <div className="p-3.5 rounded-xl bg-[#050914] border border-white/10 text-xs leading-relaxed text-slate-200">
                      <div className="font-mono text-[11px] text-[#00d4b4] mb-1">
                        CLINICAL SUMMARY CONDENSATION:
                      </div>
                      {hfResponse.result[0].summary_text}
                    </div>
                  )}

                  {/* Raw JSON viewer */}
                  <details className="mt-2 text-xs font-mono text-slate-400">
                    <summary className="cursor-pointer hover:text-slate-200">View Raw Payload JSON</summary>
                    <pre className="mt-2 p-3 rounded-xl bg-[#040813] border border-white/5 text-[11px] text-emerald-400 overflow-x-auto max-h-60 custom-scrollbar">
                      {JSON.stringify(hfResponse, null, 2)}
                    </pre>
                  </details>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: RANDOM FOREST ENSEMBLE */}
      {activeTab === 'random-forest' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Sliders Input */}
          <div className="lg:col-span-5 p-5 rounded-2xl bg-[#080e1c] border border-white/10 space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <GitBranch className="w-4 h-4 text-[#00d4b4]" />
                Random Forest Telemetry Inputs
              </h2>
              <button
                onClick={handleRunRf}
                disabled={rfLoading}
                className="px-3 py-1.5 rounded-xl bg-[#00d4b4] text-black text-xs font-bold hover:bg-[#00d4b4]/90 transition-colors flex items-center gap-1.5"
              >
                {rfLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5 fill-black" />}
                EVALUATE TREES
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <div className="flex justify-between font-mono mb-1">
                  <span className="text-slate-400">Blood Glucose</span>
                  <span className="text-[#00d4b4]">{rfVitals.glucose} mg/dL</span>
                </div>
                <input
                  type="range"
                  min="60"
                  max="280"
                  value={rfVitals.glucose}
                  onChange={(e) => setRfVitals({ ...rfVitals, glucose: Number(e.target.value) })}
                  className="w-full accent-[#00d4b4]"
                />
              </div>

              <div>
                <div className="flex justify-between font-mono mb-1">
                  <span className="text-slate-400">Systolic Blood Pressure</span>
                  <span className="text-rose-400">{rfVitals.sysBP} mmHg</span>
                </div>
                <input
                  type="range"
                  min="90"
                  max="200"
                  value={rfVitals.sysBP}
                  onChange={(e) => setRfVitals({ ...rfVitals, sysBP: Number(e.target.value) })}
                  className="w-full accent-rose-400"
                />
              </div>

              <div>
                <div className="flex justify-between font-mono mb-1">
                  <span className="text-slate-400">Diastolic Blood Pressure</span>
                  <span className="text-amber-400">{rfVitals.diaBP} mmHg</span>
                </div>
                <input
                  type="range"
                  min="55"
                  max="120"
                  value={rfVitals.diaBP}
                  onChange={(e) => setRfVitals({ ...rfVitals, diaBP: Number(e.target.value) })}
                  className="w-full accent-amber-400"
                />
              </div>

              <div>
                <div className="flex justify-between font-mono mb-1">
                  <span className="text-slate-400">Heart Rate</span>
                  <span className="text-blue-400">{rfVitals.hr} BPM</span>
                </div>
                <input
                  type="range"
                  min="45"
                  max="140"
                  value={rfVitals.hr}
                  onChange={(e) => setRfVitals({ ...rfVitals, hr: Number(e.target.value) })}
                  className="w-full accent-blue-400"
                />
              </div>

              <div>
                <div className="flex justify-between font-mono mb-1">
                  <span className="text-slate-400">Oxygen Saturation (SpO₂)</span>
                  <span className="text-emerald-400">{rfVitals.spo2}%</span>
                </div>
                <input
                  type="range"
                  min="85"
                  max="100"
                  value={rfVitals.spo2}
                  onChange={(e) => setRfVitals({ ...rfVitals, spo2: Number(e.target.value) })}
                  className="w-full accent-emerald-400"
                />
              </div>

              <div className="grid grid-cols-3 gap-2 pt-2">
                <div>
                  <label className="text-[10px] font-mono text-slate-500">AGE (YRS)</label>
                  <input
                    type="number"
                    value={rfVitals.age}
                    onChange={(e) => setRfVitals({ ...rfVitals, age: Number(e.target.value) })}
                    className="w-full p-2 rounded-lg bg-[#050914] border border-white/10 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-mono text-slate-500">BMI</label>
                  <input
                    type="number"
                    step="0.1"
                    value={rfVitals.bmi}
                    onChange={(e) => setRfVitals({ ...rfVitals, bmi: Number(e.target.value) })}
                    className="w-full p-2 rounded-lg bg-[#050914] border border-white/10 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-[10px] font-mono text-slate-500">CHOL (mg/dL)</label>
                  <input
                    type="number"
                    value={rfVitals.cholesterol}
                    onChange={(e) => setRfVitals({ ...rfVitals, cholesterol: Number(e.target.value) })}
                    className="w-full p-2 rounded-lg bg-[#050914] border border-white/10 text-xs text-white"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Evaluation Results */}
          <div className="lg:col-span-7 space-y-4">
            <div className="p-5 rounded-2xl bg-[#080e1c] border border-white/10 space-y-4">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-300 flex items-center justify-between">
                <span>Python Random Forest Ensemble Output</span>
                {rfResponse && (
                  <span className="text-[11px] font-mono text-emerald-400">
                    {rfResponse.algorithm}
                  </span>
                )}
              </h3>

              {rfResponse ? (
                <div className="space-y-4">
                  {/* Big Risk Label */}
                  <div className="p-4 rounded-xl bg-gradient-to-r from-[#050914] to-[#0a1426] border border-white/10 flex items-center justify-between">
                    <div>
                      <div className="text-xs font-mono text-slate-400">PREDICTED CLINICAL RISK</div>
                      <div className="text-xl font-bold text-white mt-0.5">
                        {rfResponse.risk_label}
                      </div>
                      <div className="text-xs text-slate-400 mt-1">
                        Consensus across {rfResponse.total_trees_voting} Decision Trees with {rfResponse.confidence_percent}% confidence
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-black text-[#00d4b4]">
                        {rfResponse.confidence_percent}%
                      </div>
                      <div className="text-[10px] font-mono text-slate-500">CONFIDENCE</div>
                    </div>
                  </div>

                  {/* Feature Importance Weights */}
                  {rfResponse.feature_importances && (
                    <div>
                      <div className="text-xs font-semibold text-slate-300 mb-2">
                        Feature Gini Importances:
                      </div>
                      <div className="space-y-1.5">
                        {rfResponse.feature_importances.slice(0, 5).map((fi: any) => (
                          <div key={fi.feature} className="space-y-0.5">
                            <div className="flex justify-between text-[11px]">
                              <span className="text-slate-300">{fi.feature}</span>
                              <span className="font-mono text-[#00d4b4]">
                                {Math.round(fi.importance * 100)}%
                              </span>
                            </div>
                            <div className="w-full h-1 rounded-full bg-white/10 overflow-hidden">
                              <div
                                className="h-full bg-[#00d4b4]"
                                style={{ width: `${fi.importance * 100}%` }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Decision Path Trace */}
                  {rfResponse.sample_decision_path && (
                    <div className="p-3 rounded-xl bg-[#050914] border border-white/5 space-y-1.5">
                      <div className="text-[11px] font-mono text-slate-400 font-semibold">
                        SAMPLE TREE SPLIT PATH:
                      </div>
                      {rfResponse.sample_decision_path.map((path: string, i: number) => (
                        <div key={i} className="text-xs font-mono text-emerald-400 flex items-center gap-1.5">
                          <span className="text-slate-500">#{i + 1}</span>
                          {path}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-10 text-center text-slate-500 text-xs">
                  Adjust sliders and click <strong>EVALUATE TREES</strong> to execute Python Random Forest model.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: BIOMEDICAL NER & NLP */}
      {activeTab === 'bio-nlp' && (
        <div className="p-5 rounded-2xl bg-[#080e1c] border border-white/10 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Stethoscope className="w-4 h-4 text-[#00d4b4]" />
                Python Biomedical Entity Extraction & Negation Scope Parser
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Evaluates clinical dictations, extracting drug names, dosages, conditions, and negation scopes (e.g. denies, no signs of).
              </p>
            </div>
            <button
              onClick={handleRunNlp}
              disabled={nlpLoading}
              className="px-4 py-2 rounded-xl bg-[#00d4b4] text-black text-xs font-bold flex items-center gap-2 hover:bg-[#00d4b4]/90"
            >
              {nlpLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5 fill-black" />}
              PARSE CLINICAL NOTE
            </button>
          </div>

          <textarea
            rows={4}
            value={nlpText}
            onChange={(e) => setNlpText(e.target.value)}
            className="w-full p-3.5 rounded-xl bg-[#050914] border border-white/10 text-xs text-slate-100 font-sans focus:outline-none focus:border-[#00d4b4] leading-relaxed resize-none"
          />

          {nlpResponse && (
            <div className="mt-4 pt-4 border-t border-white/10 space-y-4">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-400">Total Entities: {nlpResponse.total_entities}</span>
                <span className="text-slate-400">Clinical Density: {nlpResponse.clinical_density_percent}%</span>
                <span className="text-amber-400">Negations Detected: {nlpResponse.negations_detected}</span>
              </div>

              {/* Identified Entities */}
              <div>
                <div className="text-xs font-semibold text-slate-300 mb-2">Identified Entities:</div>
                <div className="flex flex-wrap gap-2">
                  {nlpResponse.entities?.map((ent: any, idx: number) => {
                    const isNegated = ent.negated;
                    const bg = isNegated
                      ? 'bg-slate-700/50 text-slate-400 border-slate-600 line-through'
                      : ent.category === 'MEDICATION'
                      ? 'bg-purple-500/20 text-purple-300 border-purple-500/40'
                      : ent.category === 'CONDITION'
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                      : ent.category === 'DOSAGE'
                      ? 'bg-blue-500/20 text-blue-300 border-blue-500/40'
                      : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40';

                    return (
                      <div
                        key={idx}
                        className={`px-3 py-1 rounded-xl border text-xs font-mono flex items-center gap-2 ${bg}`}
                      >
                        <span className="font-semibold">{ent.text}</span>
                        <span className="text-[10px] opacity-75">
                          {isNegated ? 'NEGATED' : ent.category}
                        </span>
                        {ent.icd10 && (
                          <span className="text-[10px] px-1 py-0.2 rounded bg-black/40 text-amber-300">
                            ICD {ent.icd10}
                          </span>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* ICD-10 suggestions */}
              {nlpResponse.icd_suggestions?.length > 0 && (
                <div className="p-3 rounded-xl bg-[#050914] border border-white/5 space-y-2">
                  <div className="text-xs font-mono text-[#00d4b4] font-semibold">
                    SUGGESTED ICD-10 DIAGNOSTIC CODES:
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {nlpResponse.icd_suggestions.map((icd: any) => (
                      <div
                        key={icd.code}
                        className="p-2 rounded-lg bg-[#080e1c] border border-white/5 flex items-center justify-between text-xs"
                      >
                        <span className="text-slate-200">{icd.description}</span>
                        <span className="font-mono text-amber-400 font-bold ml-2">{icd.code}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* TAB 4: PHARMACOLOGY CYP450 */}
      {activeTab === 'drug-checker' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Medications list */}
          <div className="lg:col-span-5 p-5 rounded-2xl bg-[#080e1c] border border-white/10 space-y-4">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Pill className="w-4 h-4 text-[#00d4b4]" />
              Active Regimen Form
            </h2>

            <div className="flex gap-2">
              <input
                type="text"
                placeholder="e.g. Warfarin, Amiodarone, Aspirin..."
                value={newDrugInput}
                onChange={(e) => setNewDrugInput(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && newDrugInput.trim()) {
                    setDrugList([...drugList, newDrugInput.trim()]);
                    setNewDrugInput('');
                  }
                }}
                className="flex-1 px-3 py-2 rounded-xl bg-[#050914] border border-white/10 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-[#00d4b4]"
              />
              <button
                onClick={() => {
                  if (newDrugInput.trim()) {
                    setDrugList([...drugList, newDrugInput.trim()]);
                    setNewDrugInput('');
                  }
                }}
                className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-white"
              >
                Add
              </button>
            </div>

            <div className="space-y-1.5">
              {drugList.map((d, i) => (
                <div
                  key={i}
                  className="p-2.5 rounded-xl bg-[#050914] border border-white/5 flex items-center justify-between text-xs"
                >
                  <span className="font-mono text-slate-200">{d}</span>
                  <button
                    onClick={() => setDrugList(drugList.filter((_, idx) => idx !== i))}
                    className="text-slate-500 hover:text-rose-400 text-xs"
                  >
                    Remove
                  </button>
                </div>
              ))}
            </div>

            <button
              onClick={handleRunDrugCheck}
              disabled={drugLoading || drugList.length === 0}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs flex items-center justify-center gap-2"
            >
              {drugLoading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5 fill-black" />}
              RUN CYP450 CONFLICT ANALYSIS
            </button>
          </div>

          {/* Interaction Results */}
          <div className="lg:col-span-7 p-5 rounded-2xl bg-[#080e1c] border border-white/10 space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-300">
              Pharmacology Analysis Output
            </h3>

            {drugResponse ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 rounded-xl bg-[#050914] border border-white/10 text-xs">
                  <span>Status:</span>
                  <span
                    className={`font-mono font-bold px-2 py-0.5 rounded ${
                      drugResponse.is_safe
                        ? 'bg-emerald-500/20 text-emerald-400'
                        : 'bg-rose-500/20 text-rose-400'
                    }`}
                  >
                    {drugResponse.is_safe ? 'NO CONFLICTS' : `${drugResponse.interaction_count} CONFLICTS DETECTED`}
                  </span>
                </div>

                {drugResponse.interactions?.length > 0 ? (
                  <div className="space-y-3">
                    {drugResponse.interactions.map((it: any, idx: number) => {
                      const isCrit = it.severity === 'Critical';
                      const isMaj = it.severity === 'Major';
                      const borderCol = isCrit ? 'border-rose-500/50 bg-rose-950/20' : isMaj ? 'border-amber-500/50 bg-amber-950/20' : 'border-blue-500/30 bg-blue-950/20';

                      return (
                        <div key={idx} className={`p-4 rounded-xl border ${borderCol} space-y-2`}>
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-bold text-white">
                              {it.drugs.join(' ↔ ')}
                            </span>
                            <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded bg-black/40 text-rose-300">
                              {it.severity.toUpperCase()}
                            </span>
                          </div>
                          <div className="text-xs text-slate-300">
                            <strong>Mechanism:</strong> {it.mechanism}
                          </div>
                          <p className="text-xs text-slate-400 leading-relaxed">
                            {it.clinical_detail}
                          </p>
                          <div className="p-2.5 rounded-lg bg-black/40 text-xs text-emerald-300 font-mono">
                            Recommendation: {it.recommendation}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="p-6 text-center text-emerald-400 text-xs">
                    No major Cytochrome P450 pathway inhibitions or contraindications detected between the active medications.
                  </div>
                )}
              </div>
            ) : (
              <div className="p-8 text-center text-slate-500 text-xs">
                Add medications and click <strong>RUN CYP450 CONFLICT ANALYSIS</strong>.
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 5: PYTHON CODE STUDIO (REPL) */}
      {activeTab === 'code-studio' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Code Editor */}
          <div className="lg:col-span-7 p-5 rounded-2xl bg-[#080e1c] border border-white/10 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Terminal className="w-4 h-4 text-[#00d4b4]" />
                <h2 className="text-sm font-semibold uppercase tracking-wider text-slate-300">
                  Interactive Python 3.10 Code Studio
                </h2>
              </div>
              <button
                onClick={handleExecuteCode}
                disabled={codeRunning}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black text-xs font-bold flex items-center gap-2 hover:opacity-90 disabled:opacity-50"
              >
                {codeRunning ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5 fill-black" />}
                RUN SCRIPT
              </button>
            </div>

            {/* Template Selector */}
            <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
              {CODE_PRESETS.map((p, idx) => (
                <button
                  key={p.title}
                  onClick={() => {
                    setSelectedCodePreset(idx);
                    setPythonCode(p.code);
                    setCodeOutput(null);
                  }}
                  className={`px-3 py-1.5 rounded-lg text-xs font-mono whitespace-nowrap transition-all ${
                    selectedCodePreset === idx
                      ? 'bg-[#00d4b4]/20 text-[#00d4b4] border border-[#00d4b4]/40 font-semibold'
                      : 'bg-[#050914] text-slate-400 hover:text-slate-200 border border-white/5'
                  }`}
                >
                  {p.title}
                </button>
              ))}
            </div>

            {/* Editor Textarea */}
            <div className="relative rounded-xl overflow-hidden border border-white/10 bg-[#040813]">
              <textarea
                rows={16}
                value={pythonCode}
                onChange={(e) => setPythonCode(e.target.value)}
                className="w-full p-4 bg-transparent text-xs font-mono text-emerald-400 focus:outline-none leading-relaxed resize-none custom-scrollbar selection:bg-[#00d4b4] selection:text-black"
                spellCheck={false}
              />
            </div>
          </div>

          {/* Console Output */}
          <div className="lg:col-span-5 p-5 rounded-2xl bg-[#080e1c] border border-white/10 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <FileCode className="w-4 h-4 text-purple-400" />
                Terminal Console Output
              </h3>
              {codeOutput?.execution_time_ms && (
                <span className="text-[11px] font-mono text-[#00d4b4]">
                  {codeOutput.execution_time_ms} ms
                </span>
              )}
            </div>

            <div className="p-4 rounded-xl bg-[#040813] border border-white/10 font-mono text-xs text-slate-200 min-h-[380px] max-h-[460px] overflow-y-auto custom-scrollbar">
              {codeOutput ? (
                <div className="space-y-2">
                  {codeOutput.stdout && (
                    <pre className="text-emerald-400 whitespace-pre-wrap leading-relaxed">
                      {codeOutput.stdout}
                    </pre>
                  )}
                  {codeOutput.stderr && (
                    <pre className="text-amber-400 whitespace-pre-wrap leading-relaxed">
                      {codeOutput.stderr}
                    </pre>
                  )}
                  {codeOutput.error && (
                    <pre className="text-rose-400 whitespace-pre-wrap leading-relaxed">
                      {codeOutput.error}
                    </pre>
                  )}
                  {!codeOutput.stdout && !codeOutput.stderr && !codeOutput.error && (
                    <div className="text-slate-500">Script completed with no standard output.</div>
                  )}
                </div>
              ) : (
                <div className="text-slate-500 h-full flex flex-col items-center justify-center text-center p-6">
                  <Terminal className="w-8 h-8 text-slate-600 mb-2" />
                  <span>Click <strong>RUN SCRIPT</strong> to execute Python on the backend.</span>
                  <span className="text-[10px] text-slate-600 mt-1">
                    Python 3.10 execution sandbox with safe globals and clinical modules pre-imported.
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: BACKEND ARCHITECTURE & MODULES */}
      {activeTab === 'architecture' && (
        <div className="space-y-6">
          {/* Active Python Modules List */}
          <div className="p-5 rounded-2xl bg-[#080e1c] border border-white/10 space-y-4">
            <h2 className="text-sm font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Cpu className="w-4 h-4 text-[#00d4b4]" />
              Loaded Python Backend Modules & Services
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {modulesList.length > 0 ? (
                modulesList.map((m) => (
                  <div
                    key={m.name}
                    className="p-4 rounded-xl bg-[#050914] border border-white/5 space-y-2"
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-bold text-white">{m.title}</span>
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#00d4b4]/10 text-[#00d4b4] border border-[#00d4b4]/30">
                        v{m.version}
                      </span>
                    </div>
                    <div className="text-[11px] font-mono text-purple-400">{m.name}.py</div>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      {m.description}
                    </p>
                    <div className="text-[10px] font-mono text-emerald-400 flex items-center gap-1 pt-1">
                      <CheckCircle2 className="w-3 h-3" />
                      {m.status}
                    </div>
                  </div>
                ))
              ) : (
                <div className="col-span-full p-6 text-center text-slate-500 text-xs">
                  Loading module definitions from Python runtime...
                </div>
              )}
            </div>
          </div>

          {/* Architecture Diagram Info */}
          <div className="p-5 rounded-2xl bg-[#080e1c] border border-white/10 space-y-4">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-2">
              <Layers className="w-4 h-4 text-[#4f8cff]" />
              Full-Stack Python + React Architecture
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
              <div className="p-4 rounded-xl bg-[#050914] border border-white/5 space-y-2">
                <div className="text-[#00d4b4] font-bold">1. FRONTEND</div>
                <div className="text-slate-300 font-sans">React 18 + Vite SPA</div>
                <p className="text-[11px] text-slate-400 font-sans">
                  Interactive real-time dashboards, medical visualizers, and code studio.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#050914] border border-white/5 space-y-2">
                <div className="text-purple-400 font-bold">2. EXPRESS GATEWAY</div>
                <div className="text-slate-300 font-sans">Node.js Server (Port 3000)</div>
                <p className="text-[11px] text-slate-400 font-sans">
                  Proxies requests to Python via JSON IPC with timeout handling and security checks.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#050914] border border-white/5 space-y-2">
                <div className="text-blue-400 font-bold">3. PYTHON KERNEL</div>
                <div className="text-slate-300 font-sans">Python 3.10.12 Engine</div>
                <p className="text-[11px] text-slate-400 font-sans">
                  Runs Random Forest classifier, Bio-NLP, pharmacology matrix, and code runner.
                </p>
              </div>

              <div className="p-4 rounded-xl bg-[#050914] border border-white/5 space-y-2">
                <div className="text-amber-400 font-bold">4. HUGGING FACE BRIDGE</div>
                <div className="text-slate-300 font-sans">Inference API & Local Fallback</div>
                <p className="text-[11px] text-slate-400 font-sans">
                  Connects to HF models (BioBERT, PubMedBERT, BART) with zero-downtime fallback.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
