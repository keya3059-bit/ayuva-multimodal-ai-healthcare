import React, { useEffect, useRef } from 'react';

interface AnimatedECGStripProps {
  bpm?: number;
  color?: string;
  height?: number;
  width?: string;
  showGrid?: boolean;
}

export const AnimatedECGStrip: React.FC<AnimatedECGStripProps> = ({
  bpm = 72,
  color = '#00d4b4',
  height = 36,
  width = 'w-full',
  showGrid = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let scanX = 0;
    const dataPoints: number[] = [];
    const maxPoints = canvas.width || 300;

    // Prepopulate zero line
    for (let i = 0; i < maxPoints; i++) {
      dataPoints.push(0);
    }

    // Normal P-Q-R-S-T wave cycle generator
    // Cycle length based on BPM
    const speed = (bpm / 60) * 2.2;
    let phase = 0;

    const getEcgValue = (p: number): number => {
      const mod = p % 100;
      if (mod >= 10 && mod < 18) {
        // P-wave
        return Math.sin(((mod - 10) / 8) * Math.PI) * 4;
      }
      if (mod >= 24 && mod < 27) {
        // Q-dip
        return -3;
      }
      if (mod >= 27 && mod < 32) {
        // R-spike
        return 22;
      }
      if (mod >= 32 && mod < 35) {
        // S-dip
        return -6;
      }
      if (mod >= 45 && mod < 65) {
        // T-wave
        return Math.sin(((mod - 45) / 20) * Math.PI) * 7;
      }
      return 0;
    };

    const render = () => {
      phase += speed;
      const currentVal = getEcgValue(phase);

      dataPoints.shift();
      dataPoints.push(currentVal);

      scanX = (scanX + speed) % maxPoints;

      // Draw frame
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const midY = canvas.height / 2;

      // Draw medical grid if enabled
      if (showGrid) {
        ctx.strokeStyle = 'rgba(0, 212, 180, 0.08)';
        ctx.lineWidth = 1;
        const gridSize = 10;
        for (let x = 0; x < canvas.width; x += gridSize) {
          ctx.beginPath();
          ctx.moveTo(x, 0);
          ctx.lineTo(x, canvas.height);
          ctx.stroke();
        }
        for (let y = 0; y < canvas.height; y += gridSize) {
          ctx.beginPath();
          ctx.moveTo(0, y);
          ctx.lineTo(canvas.width, y);
          ctx.stroke();
        }
      }

      // Draw ECG continuous trace
      ctx.beginPath();
      ctx.strokeStyle = color;
      ctx.lineWidth = 1.8;
      ctx.lineJoin = 'round';
      ctx.shadowColor = color;
      ctx.shadowBlur = 6;

      for (let i = 0; i < dataPoints.length; i++) {
        const x = (i / dataPoints.length) * canvas.width;
        const y = midY - dataPoints[i];
        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
      }
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Glowing leading pulse dot
      const headX = (dataPoints.length - 1) * (canvas.width / dataPoints.length);
      const headY = midY - dataPoints[dataPoints.length - 1];
      ctx.beginPath();
      ctx.arc(headX, headY, 2.5, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.shadowColor = color;
      ctx.shadowBlur = 10;
      ctx.fill();
      ctx.shadowBlur = 0;

      animId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [bpm, color, showGrid]);

  return (
    <div className={`relative ${width} flex items-center overflow-hidden rounded-lg bg-black/40 border border-white/5`}>
      <canvas
        ref={canvasRef}
        width={240}
        height={height}
        className="w-full h-full block"
      />
    </div>
  );
};
