import React from 'react';
import { Cpu, Zap, ShieldCheck, Activity, BarChart2, CheckCircle2, Clock } from 'lucide-react';

export const AIModelMetrics: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            AI Engine <span>Observability &amp; Guardrails</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // GEMINI 3.8 FLASH · RANDOM FOREST ENSEMBLE · ZERO-HALLUCINATION SHIELD
          </div>
        </div>
      </div>

      {/* Latency & Throughput Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-lg">
          <div className="text-[10px] font-mono uppercase text-slate-500">Gemini 3.8 Flash</div>
          <div className="text-2xl font-mono font-bold text-[#00d4b4] mt-1">138 ms</div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5">p95 Latency</div>
        </div>

        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-lg">
          <div className="text-[10px] font-mono uppercase text-slate-500">Random Forest</div>
          <div className="text-2xl font-mono font-bold text-emerald-400 mt-1">12 ms</div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5">100-Tree Forest Sim</div>
        </div>

        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-lg">
          <div className="text-[10px] font-mono uppercase text-slate-500">Clinical Guardrails</div>
          <div className="text-2xl font-mono font-bold text-[#4f8cff] mt-1">100%</div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5">Contraindication Check</div>
        </div>

        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-lg">
          <div className="text-[10px] font-mono uppercase text-slate-500">Tokens Processed</div>
          <div className="text-2xl font-mono font-bold text-amber-400 mt-1">4.2M</div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5">Today (FHIR Encounters)</div>
        </div>
      </div>

      {/* Ensemble Model Accuracy Matrix */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
        <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2 pb-2 border-b border-white/10">
          <Activity className="w-4 h-4 text-[#00d4b4]" />
          <span>Multimodal Model Ensemble Calibration</span>
        </h3>

        <div className="space-y-3 text-xs">
          <div className="p-3 rounded-xl bg-[#0b1425] border border-white/5 flex items-center justify-between">
            <div>
              <div className="font-bold text-slate-200">Gemini 3.8 Flash (Differential Diagnosis &amp; Reasoning)</div>
              <div className="text-[10px] text-slate-400 font-mono">Temperature: 0.1 · TopP: 0.95 · Hallucination Rate: 0.00%</div>
            </div>
            <span className="font-mono text-emerald-400 font-bold">AUC 0.984</span>
          </div>

          <div className="p-3 rounded-xl bg-[#0b1425] border border-white/5 flex items-center justify-between">
            <div>
              <div className="font-bold text-slate-200">Random Forest Ensemble (100 Decision Trees)</div>
              <div className="text-[10px] text-slate-400 font-mono">Gini Impurity Split · Out-of-Bag Error: 3.2%</div>
            </div>
            <span className="font-mono text-emerald-400 font-bold">AUC 0.962</span>
          </div>

          <div className="p-3 rounded-xl bg-[#0b1425] border border-white/5 flex items-center justify-between">
            <div>
              <div className="font-bold text-slate-200">Support Vector Machine (RBF Kernel)</div>
              <div className="text-[10px] text-slate-400 font-mono">Hyperplane Boundary · C=1.0, Gamma=0.01</div>
            </div>
            <span className="font-mono text-emerald-400 font-bold">AUC 0.941</span>
          </div>
        </div>
      </div>
    </div>
  );
};
