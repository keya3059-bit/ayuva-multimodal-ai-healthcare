import React from 'react';
import {
  Building2,
  Ambulance,
  Activity,
  Cpu,
  Users,
  ShieldCheck,
  AlertTriangle,
  ArrowUpRight,
  TrendingUp,
  Server
} from 'lucide-react';
import { HOSPITALS, FLEET_UNITS } from '../../data/mockData';
import { AppSection } from '../../types';

interface AdminDashboardProps {
  onNavigate: (sec: AppSection) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigate }) => {
  const totalBeds = HOSPITALS.reduce((acc, h) => acc + h.totalBeds, 0);
  const totalAvail = HOSPITALS.reduce((acc, h) => acc + h.availableBeds, 0);
  const overallOccupancy = Math.round(((totalBeds - totalAvail) / totalBeds) * 100);

  return (
    <div className="space-y-6">
      {/* Welcome and Status */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-100">
            Regional Health <span>Command Center</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-1 flex items-center gap-2">
            <span>// TIRUPATI HEALTH DISTRICT · ANDHRA PRADESH</span>
            <span>•</span>
            <span className="text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> ALL SYSTEMS NORMAL
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('admin-fleet')}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs shadow-md"
          >
            <Ambulance className="w-4 h-4" />
            <span>Manage 108 Fleet</span>
          </button>
        </div>
      </div>

      {/* Primary KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-lg">
          <div className="text-xl mb-1">🏥</div>
          <div className="text-2xl sm:text-3xl font-extrabold font-mono text-[#00d4b4]">
            {overallOccupancy}%
          </div>
          <div className="text-[11px] font-mono uppercase text-slate-400 mt-0.5">
            District Bed Occupancy
          </div>
          <div className="text-[11px] text-slate-400 mt-2 font-mono">
            {totalAvail} of {totalBeds} beds open
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-lg">
          <div className="text-xl mb-1">🚑</div>
          <div className="text-2xl sm:text-3xl font-extrabold font-mono text-emerald-400">
            {FLEET_UNITS.filter((f) => f.status === 'AVAILABLE').length} / {FLEET_UNITS.length}
          </div>
          <div className="text-[11px] font-mono uppercase text-slate-400 mt-0.5">
            108 Fleet Ready
          </div>
          <div className="text-[11px] text-emerald-400 mt-2 font-mono">
            Avg response time: 6.4m
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-lg">
          <div className="text-xl mb-1">🤖</div>
          <div className="text-2xl sm:text-3xl font-extrabold font-mono text-[#4f8cff]">
            142 ms
          </div>
          <div className="text-[11px] font-mono uppercase text-slate-400 mt-0.5">
            Gemini Inference Latency
          </div>
          <div className="text-[11px] text-slate-400 mt-2 font-mono">
            99.98% uptime SLA
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-lg">
          <div className="text-xl mb-1">📡</div>
          <div className="text-2xl sm:text-3xl font-extrabold font-mono text-amber-400">
            2.4k
          </div>
          <div className="text-[11px] font-mono uppercase text-slate-400 mt-0.5">
            Active IoT Telemetry Streams
          </div>
          <div className="text-[11px] text-amber-400 mt-2 font-mono">
            Ingestion: 14.8 MB/s
          </div>
        </div>
      </div>

      {/* Hospital Capacities Overview */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-white/10">
          <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
            <Building2 className="w-4 h-4 text-[#00d4b4]" />
            <span>District Facilities Load Balancing</span>
          </h3>
          <span className="text-[10px] font-mono text-slate-400">5 HOSPITALS CONNECTED</span>
        </div>

        <div className="space-y-3">
          {HOSPITALS.map((h) => (
            <div
              key={h.id}
              className="p-4 rounded-xl bg-[#0b1425] border border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between sm:justify-start gap-3">
                  <h4 className="font-bold text-sm text-slate-200">{h.name}</h4>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/[0.04] text-slate-400">
                    {h.distance}
                  </span>
                </div>
                <div className="text-xs text-slate-400 font-mono mt-0.5">
                  Wait time: {h.waitTime} · Total: {h.totalBeds} beds
                </div>
                <div className="h-1.5 w-full bg-black/40 rounded-full mt-2 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] rounded-full"
                    style={{ width: `${100 - h.availPercent}%` }}
                  />
                </div>
              </div>

              <div className="text-right font-mono text-xs shrink-0">
                <span className="text-emerald-400 font-bold block">
                  {h.availableBeds} beds open
                </span>
                <span className="text-[10px] text-slate-500">
                  {100 - h.availPercent}% occupied
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* AI & Infrastructure Health */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div
          onClick={() => onNavigate('admin-models')}
          className="p-5 rounded-2xl bg-[#080e1c] border border-white/10 hover:border-[#00d4b4]/40 cursor-pointer transition-all space-y-2 group"
        >
          <div className="w-10 h-10 rounded-xl bg-[#00d4b4]/10 text-[#00d4b4] flex items-center justify-center group-hover:scale-110 transition-transform">
            <Cpu className="w-5 h-5" />
          </div>
          <h4 className="font-bold text-sm text-slate-100">AI Model Observability</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Monitor Gemini 3.8 Flash, Random Forest inference latencies, and clinical safety guardrails.
          </p>
        </div>

        <div
          onClick={() => onNavigate('admin-fleet')}
          className="p-5 rounded-2xl bg-[#080e1c] border border-white/10 hover:border-[#4f8cff]/40 cursor-pointer transition-all space-y-2 group"
        >
          <div className="w-10 h-10 rounded-xl bg-[#4f8cff]/10 text-[#4f8cff] flex items-center justify-center group-hover:scale-110 transition-transform">
            <Ambulance className="w-5 h-5" />
          </div>
          <h4 className="font-bold text-sm text-slate-100">Emergency &amp; Delivery Logistics</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Live telemetry for autonomous medicine delivery vans and rapid 108 trauma ambulances.
          </p>
        </div>
      </div>
    </div>
  );
};
