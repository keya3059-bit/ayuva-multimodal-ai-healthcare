import React, { useState } from 'react';
import { Ambulance, Truck, Battery, Radio, ShieldCheck, MapPin, AlertCircle, Play } from 'lucide-react';
import { FLEET_UNITS } from '../../data/mockData';

export const FleetControl: React.FC = () => {
  const [units, setUnits] = useState(FLEET_UNITS);

  const toggleDispatch = (id: string) => {
    setUnits((prev) =>
      prev.map((u) => {
        if (u.id === id) {
          const newStatus = u.status === 'AVAILABLE' ? 'DEPLOYED' : 'AVAILABLE';
          return { ...u, status: newStatus as any };
        }
        return u;
      })
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            Autonomous Fleet &amp; <span>Dispatch Control</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // 108 RAPID AMBULANCES · COLD-CHAIN MEDICINE CARRIERS · GPS TELEMETRY
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {units.map((u) => (
          <div
            key={u.id}
            className="p-5 rounded-2xl bg-[#080e1c] border border-white/10 hover:border-white/20 transition-all shadow-xl space-y-4"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center justify-center font-bold">
                  {u.type === 'AMBULANCE' ? <Ambulance className="w-6 h-6" /> : <Truck className="w-6 h-6 text-[#00d4b4]" />}
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-100">{u.name}</h4>
                  <div className="text-[11px] font-mono text-slate-400">Unit: {u.id}</div>
                </div>
              </div>

              <span
                className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                  u.status === 'AVAILABLE'
                    ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                    : u.status === 'DEPLOYED'
                    ? 'bg-rose-500/15 text-rose-400 border-rose-500/30'
                    : 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                }`}
              >
                {u.status}
              </span>
            </div>

            <div className="p-3 rounded-xl bg-[#0b1425] border border-white/5 space-y-1.5 text-xs">
              <div className="text-slate-300 font-medium">{u.equipment}</div>
              <div className="text-[10px] font-mono text-slate-400 flex items-center justify-between">
                <span>Coordinates: {u.lat.toFixed(4)}, {u.lng.toFixed(4)}</span>
                <span className="text-[#00d4b4]">Avg ETA: {u.eta}</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-1">
              <div className="flex items-center gap-2 font-mono text-xs text-slate-400">
                <Battery className="w-4 h-4 text-emerald-400" />
                <span>EV Charge: 92%</span>
              </div>

              <button
                onClick={() => toggleDispatch(u.id)}
                className={`px-4 py-2 rounded-xl font-bold text-xs transition-all ${
                  u.status === 'AVAILABLE'
                    ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40'
                    : 'bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40'
                }`}
              >
                {u.status === 'AVAILABLE' ? 'Dispatch to 108 Call' : 'Recall to Base'}
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
