import React from 'react';
import { Building2, Activity, Wind, Droplets, Bed, Users } from 'lucide-react';
import { HOSPITALS } from '../../data/mockData';

export const HospitalCapacity: React.FC = () => {
  const wards = [
    { name: 'Intensive Care Unit (ICU)', total: 64, occupied: 52, color: 'text-rose-400' },
    { name: 'Coronary Care Unit (CCU)', total: 40, occupied: 28, color: 'text-amber-400' },
    { name: 'Emergency & Trauma Bays', total: 32, occupied: 19, color: 'text-[#00d4b4]' },
    { name: 'Pediatric Intensive Care', total: 24, occupied: 14, color: 'text-[#4f8cff]' },
    { name: 'General Medical / Surgical', total: 380, occupied: 295, color: 'text-emerald-400' },
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            Hospital Capacity &amp; <span>Resource Telemetry</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // CRITICAL CARE INFRASTRUCTURE · OXYGEN RESERVES · MECHANICAL VENTILATION
          </div>
        </div>
      </div>

      {/* Critical Resources Quick Gauges */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-cyan-500/15 text-cyan-400 flex items-center justify-center shrink-0">
            <Wind className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl font-mono font-bold text-slate-100">42 / 50</div>
            <div className="text-xs text-slate-400 font-mono">Mechanical Ventilators In Use</div>
            <div className="text-[10px] text-emerald-400 mt-0.5">8 Available on Standby</div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-[#00d4b4]/15 text-[#00d4b4] flex items-center justify-center shrink-0">
            <Droplets className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl font-mono font-bold text-[#00d4b4]">94.2%</div>
            <div className="text-xs text-slate-400 font-mono">Liquid Medical O₂ Reserve</div>
            <div className="text-[10px] text-emerald-400 mt-0.5">Pressure: 4.2 bar (Stable)</div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center shrink-0">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <div className="text-2xl font-mono font-bold text-amber-300">148</div>
            <div className="text-xs text-slate-400 font-mono">Clinical Staff On Duty</div>
            <div className="text-[10px] text-slate-400 mt-0.5">Ratio: 1:3 ICU Staffing</div>
          </div>
        </div>
      </div>

      {/* Ward Breakdown Cards */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
        <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2 pb-2 border-b border-white/10">
          <Bed className="w-4 h-4 text-[#00d4b4]" />
          <span>Ward &amp; Department Bed Allocations</span>
        </h3>

        <div className="space-y-3.5">
          {wards.map((w, idx) => {
            const pct = Math.round((w.occupied / w.total) * 100);
            return (
              <div key={idx} className="space-y-1.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-200">{w.name}</span>
                  <span className="font-mono text-slate-300">
                    {w.occupied} / {w.total} beds ({pct}% occupied)
                  </span>
                </div>
                <div className="h-2 w-full bg-black/40 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      pct > 85 ? 'bg-rose-500' : pct > 70 ? 'bg-amber-400' : 'bg-[#00d4b4]'
                    }`}
                    style={{ width: `${pct}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
