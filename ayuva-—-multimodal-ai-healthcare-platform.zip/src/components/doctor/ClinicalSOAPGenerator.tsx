import React, { useState } from 'react';
import { FileText, Sparkles, Copy, CheckCircle2, RotateCcw, Send, ShieldCheck, PenTool } from 'lucide-react';
import { generateSOAPNote } from '../../services/api';

export const ClinicalSOAPGenerator: React.FC = () => {
  const [patientName, setPatientName] = useState('Arjun Reddy');
  const [patientAge, setPatientAge] = useState(34);
  const [symptoms, setSymptoms] = useState('Substernal chest tightness with exertion for 3 days, mild dyspnea, no diaphoresis');
  const [vitalsStr, setVitalsStr] = useState('BP 132/84 mmHg, HR 74 BPM regular, SpO2 98% room air, Temp 36.8°C');
  const [history, setHistory] = useState('Essential hypertension (5 years), family history of premature CAD (father MI at age 52), non-smoker');

  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [soapNote, setSoapNote] = useState<{
    subjective: string;
    objective: string;
    assessment: string;
    plan: string;
  } | null>({
    subjective: 'Patient reports 3-day history of exertional substernal chest tightness radiating mildly to left shoulder, relieved by rest within 5-10 minutes. Denies diaphoresis, syncope, or orthopnea. Reports compliance with antihypertensive regimen.',
    objective: 'Vitals: BP 132/84 mmHg, HR 74 BPM, SpO2 98%, Temp 36.8°C. Cardiovascular: S1/S2 present, no murmurs or gallops. Lungs clear to auscultation bilaterally. No peripheral edema. ECG shows normal sinus rhythm, no acute ST-T changes.',
    assessment: '1. Atypical Angina Pectoris / Rule out CAD in patient with moderate cardiovascular risk.\n2. Controlled Essential Hypertension.',
    plan: '1. Order fasting lipid profile, HbA1c, and high-sensitivity cardiac Troponin T.\n2. Schedule Exercise Stress Treadmill Test (TMT) within 72 hours.\n3. Prescribe sublingual Nitroglycerin 0.4mg PRN for acute chest discomfort.\n4. Optimize Telmisartan to 40mg daily; dietary sodium restriction (<2g/day).\n5. Return to ED immediately if chest pain persists >15 minutes or radiates to jaw/arm.',
  });

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await generateSOAPNote(
        patientName,
        patientAge,
        symptoms,
        vitalsStr,
        history
      );
      setSoapNote(res.soap);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!soapNote) return;
    const full = `PATIENT: ${patientName} (${patientAge}y)\n\nSUBJECTIVE:\n${soapNote.subjective}\n\nOBJECTIVE:\n${soapNote.objective}\n\nASSESSMENT:\n${soapNote.assessment}\n\nPLAN:\n${soapNote.plan}\n\nSigned: Dr. Rajesh Kumar (MD, DM Cardiology)`;
    navigator.clipboard.writeText(full);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            Clinical <span>SOAP Note Generator</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // GEMINI 3.8 FLASH · FHIR ENCOUNTER COMPLIANT · AUTOMATED CLINICAL SYNTHESIS
          </div>
        </div>

        {soapNote && (
          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-xs font-semibold text-slate-200"
            >
              {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5 text-[#00d4b4]" />}
              <span>{copied ? 'Copied to Clipboard' : 'Copy Full Note'}</span>
            </button>
            <button
              onClick={() => alert('SOAP Note digitally signed with Dr. Rajesh Kumar cryptographic key and committed to FHIR Server.')}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs shadow-md"
            >
              <PenTool className="w-3.5 h-3.5" />
              <span>Sign &amp; Commit to EHR</span>
            </button>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        {/* Clinical Inputs Form */}
        <form onSubmit={handleGenerate} className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <FileText className="w-4 h-4 text-[#00d4b4]" />
              <span>Clinical Encounter Inputs</span>
            </h3>
            <span className="text-[10px] font-mono text-slate-400">PATIENT INTAKE</span>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-2">
              <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
                Patient Name
              </label>
              <input
                type="text"
                value={patientName}
                onChange={(e) => setPatientName(e.target.value)}
                className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-[#00d4b4]"
              />
            </div>
            <div>
              <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
                Age
              </label>
              <input
                type="number"
                value={patientAge}
                onChange={(e) => setPatientAge(Number(e.target.value))}
                className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-[#00d4b4]"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
              Presenting Symptoms &amp; Duration
            </label>
            <textarea
              rows={2}
              value={symptoms}
              onChange={(e) => setSymptoms(e.target.value)}
              className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-[#00d4b4]"
            />
          </div>

          <div>
            <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
              Objective Vitals &amp; Physical Exam Findings
            </label>
            <textarea
              rows={2}
              value={vitalsStr}
              onChange={(e) => setVitalsStr(e.target.value)}
              className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-[#00d4b4]"
            />
          </div>

          <div>
            <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
              Past Medical History &amp; Comorbidities
            </label>
            <textarea
              rows={2}
              value={history}
              onChange={(e) => setHistory(e.target.value)}
              className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-[#00d4b4]"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#00d4b4] via-[#4f8cff] to-cyan-300 text-black font-bold text-xs hover:opacity-90 transition-opacity shadow-lg shadow-[#00d4b4]/20 flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>{loading ? 'Synthesizing SOAP Note with Gemini…' : 'Generate Structured SOAP Note'}</span>
          </button>
        </form>

        {/* Structured Output */}
        <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>Structured Clinical Note</span>
            </h3>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
              READY FOR REVIEW
            </span>
          </div>

          {soapNote && (
            <div className="space-y-3.5 text-xs text-slate-300 leading-relaxed">
              {/* Subjective */}
              <div className="p-3.5 rounded-xl bg-[#0b1425] border border-white/5 space-y-1">
                <div className="text-[11px] font-mono font-bold text-[#00d4b4] uppercase">
                  [S] Subjective
                </div>
                <p className="whitespace-pre-line">{soapNote.subjective}</p>
              </div>

              {/* Objective */}
              <div className="p-3.5 rounded-xl bg-[#0b1425] border border-white/5 space-y-1">
                <div className="text-[11px] font-mono font-bold text-[#4f8cff] uppercase">
                  [O] Objective
                </div>
                <p className="whitespace-pre-line">{soapNote.objective}</p>
              </div>

              {/* Assessment */}
              <div className="p-3.5 rounded-xl bg-[#0b1425] border border-white/5 space-y-1">
                <div className="text-[11px] font-mono font-bold text-amber-400 uppercase">
                  [A] Assessment
                </div>
                <p className="whitespace-pre-line">{soapNote.assessment}</p>
              </div>

              {/* Plan */}
              <div className="p-3.5 rounded-xl bg-[#0b1425] border border-white/5 space-y-1">
                <div className="text-[11px] font-mono font-bold text-emerald-400 uppercase">
                  [P] Plan
                </div>
                <p className="whitespace-pre-line">{soapNote.plan}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
