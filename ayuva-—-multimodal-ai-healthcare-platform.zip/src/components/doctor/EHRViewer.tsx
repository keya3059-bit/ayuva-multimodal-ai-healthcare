import React, { useState } from 'react';
import { ArrowLeft, User, Heart, Activity, FileText, AlertTriangle, Pill, ShieldCheck, Download } from 'lucide-react';
import { Patient } from '../../types';

interface EHRViewerProps {
  patient: Patient;
  onBack: () => void;
  onOpenSOAP: () => void;
}

export const EHRViewer: React.FC<EHRViewerProps> = ({ patient, onBack, onOpenSOAP }) => {
  const [activeTab, setActiveTab] = useState<'vitals' | 'meds' | 'labs' | 'history'>('vitals');

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-slate-300"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
                {patient?.name || 'Patient Record'}
              </h2>
              <span
                className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                  patient?.status === 'Critical'
                    ? 'bg-rose-500/20 text-rose-400 border-rose-500/30'
                    : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                }`}
              >
                {(patient?.status || 'Active').toUpperCase()}
              </span>
            </div>
            <div className="text-xs font-mono text-slate-400 mt-0.5">
              MRN: {patient?.id || 'PT-101'} · {patient?.age || 45} YRS · {patient?.gender || 'M'} · BLOOD: A+ · BED: {patient?.room || 'ICU-3'}
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenSOAP}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs shadow-md"
          >
            <FileText className="w-4 h-4" />
            <span>Generate SOAP Note</span>
          </button>
        </div>
      </div>

      {/* Allergies & Critical Warnings */}
      <div className="p-3.5 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-between text-xs text-rose-300">
        <div className="flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
          <span>
            <strong>CRITICAL ALLERGIES:</strong> Penicillin (Anaphylactoid), NSAIDs (Gastric Ulceration Risk)
          </span>
        </div>
        <span className="font-mono text-[10px] uppercase font-bold text-rose-400">FLAGGED</span>
      </div>

      {/* Navigation Tabs */}
      <div className="flex rounded-xl bg-white/[0.04] p-1 border border-white/5">
        {[
          { id: 'vitals', label: 'Telemetry & Vitals' },
          { id: 'meds', label: 'Active Medications' },
          { id: 'labs', label: 'Recent Pathology' },
          { id: 'history', label: 'Clinical History' },
        ].map((t) => (
          <button
            key={t.id}
            onClick={() => setActiveTab(t.id as any)}
            className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
              activeTab === t.id
                ? 'bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black shadow-md'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {/* Tab Panels */}
      {activeTab === 'vitals' && (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 text-center">
            <div className="text-[10px] font-mono text-slate-500 uppercase">Heart Rate</div>
            <div className="text-2xl font-mono font-bold text-slate-100 mt-1">
              {patient.vitals.heartRate} <span className="text-xs font-normal">BPM</span>
            </div>
            <div className="text-[10px] text-emerald-400 mt-1 font-mono">Resting Normal</div>
          </div>

          <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 text-center">
            <div className="text-[10px] font-mono text-slate-500 uppercase">Blood Oxygen</div>
            <div className="text-2xl font-mono font-bold text-emerald-400 mt-1">
              {patient.vitals.spo2}%
            </div>
            <div className="text-[10px] text-slate-400 mt-1 font-mono">Continuous Pulse Ox</div>
          </div>

          <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 text-center">
            <div className="text-[10px] font-mono text-slate-500 uppercase">Blood Glucose</div>
            <div className="text-2xl font-mono font-bold text-amber-400 mt-1">
              {patient.vitals.bloodGlucose} <span className="text-xs font-normal">mg/dL</span>
            </div>
            <div className="text-[10px] text-amber-400 mt-1 font-mono">CGM Dexcom G7</div>
          </div>

          <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 text-center">
            <div className="text-[10px] font-mono text-slate-500 uppercase">Core Temperature</div>
            <div className="text-2xl font-mono font-bold text-slate-100 mt-1">
              {patient.vitals.temperature}°C
            </div>
            <div className="text-[10px] text-slate-400 mt-1 font-mono">Continuous Sensor</div>
          </div>
        </div>
      )}

      {activeTab === 'meds' && (
        <div className="p-5 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-3">
          <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
            <Pill className="w-4 h-4 text-[#00d4b4]" />
            <span>Active Prescription Regimen</span>
          </h3>

          <div className="space-y-2">
            <div className="p-3 rounded-xl bg-[#0b1425] border border-white/5 flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-slate-200">Metformin HCl 500mg</span>
                <span className="text-slate-400 ml-2 font-mono">Oral Tablet · Twice daily with meals</span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400">ACTIVE (Refills: 3)</span>
            </div>

            <div className="p-3 rounded-xl bg-[#0b1425] border border-white/5 flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-slate-200">Atorvastatin Calcium 10mg</span>
                <span className="text-slate-400 ml-2 font-mono">Oral Tablet · Once daily at bedtime</span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400">ACTIVE (Refills: 2)</span>
            </div>

            <div className="p-3 rounded-xl bg-[#0b1425] border border-white/5 flex items-center justify-between text-xs">
              <div>
                <span className="font-bold text-slate-200">Telmisartan 40mg</span>
                <span className="text-slate-400 ml-2 font-mono">Oral Tablet · Once daily morning</span>
              </div>
              <span className="text-[10px] font-mono text-emerald-400">ACTIVE (Refills: 4)</span>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'labs' && (
        <div className="p-5 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-3">
          <h3 className="font-bold text-sm text-slate-100">Recent Lab Panels &amp; Biomarkers</h3>
          <div className="space-y-2 text-xs">
            <div className="p-3 rounded-xl bg-[#0b1425] border border-white/5 flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-200">Comprehensive Lipid Panel</div>
                <div className="text-[10px] text-slate-400 font-mono">TC 218 · LDL 138 · HDL 44 · TG 182</div>
              </div>
              <span className="text-[10px] font-mono text-amber-400 font-bold">BORDERLINE HIGH</span>
            </div>

            <div className="p-3 rounded-xl bg-[#0b1425] border border-white/5 flex items-center justify-between">
              <div>
                <div className="font-bold text-slate-200">Glycated Hemoglobin (HbA1c)</div>
                <div className="text-[10px] text-slate-400 font-mono">5.8% · Estimated Average Glucose 120 mg/dL</div>
              </div>
              <span className="text-[10px] font-mono text-amber-400 font-bold">PRE-DIABETIC</span>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'history' && (
        <div className="p-5 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-3 text-xs text-slate-300 leading-relaxed">
          <h3 className="font-bold text-sm text-slate-100">Past Medical Encounters</h3>
          <div className="p-3 rounded-xl bg-[#0b1425] border border-white/5 space-y-1">
            <div className="font-bold text-[#00d4b4] text-[11px] font-mono">2029-11-14 · SVIMS Outpatient Cardiology</div>
            <p className="text-slate-400">Annual cardiac surveillance. Resting ECG showed NSR with no ischemic changes. Echocardiogram confirmed normal LV ejection fraction (62%).</p>
          </div>
          <div className="p-3 rounded-xl bg-[#0b1425] border border-white/5 space-y-1">
            <div className="font-bold text-[#00d4b4] text-[11px] font-mono">2028-06-20 · General Medicine Follow-Up</div>
            <p className="text-slate-400">Initiated Metformin 500mg daily following fasting glucose measurement of 118 mg/dL. Advised dietary modifications.</p>
          </div>
        </div>
      )}
    </div>
  );
};
