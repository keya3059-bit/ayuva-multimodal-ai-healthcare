import React from 'react';
import {
  Users,
  Calendar,
  AlertTriangle,
  Stethoscope,
  Activity,
  FileText,
  Video,
  CheckCircle2,
  Clock,
  ArrowUpRight
} from 'lucide-react';
import { PATIENTS } from '../../data/mockData';
import { Patient, AppSection } from '../../types';

interface DoctorDashboardProps {
  onNavigate: (sec: AppSection) => void;
  onSelectPatient: (pat: Patient) => void;
}

export const DoctorDashboard: React.FC<DoctorDashboardProps> = ({
  onNavigate,
  onSelectPatient,
}) => {
  const criticalPatients = PATIENTS.filter(
    (p) => p.status === 'Critical' || p.status === 'Under Review'
  );

  return (
    <div className="space-y-6">
      {/* Welcome & Status */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-100">
            Physician <span>Clinical Cockpit</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-1 flex items-center gap-2">
            <span>// DR. RAJESH KUMAR (MD, DM CARDIOLOGY)</span>
            <span>•</span>
            <span className="text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> ON-DUTY (SVIMS)
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onNavigate('soap-generator')}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs shadow-md hover:opacity-90 transition-opacity"
          >
            <FileText className="w-4 h-4" />
            <span>New AI SOAP Note</span>
          </button>
          <button
            onClick={() => onNavigate('teleconsultation')}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/[0.05] hover:bg-white/[0.1] border border-white/10 text-xs font-semibold text-slate-200"
          >
            <Video className="w-4 h-4 text-[#00d4b4]" />
            <span>Join Telehealth</span>
          </button>
        </div>
      </div>

      {/* Top Clinical Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-lg">
          <div className="text-xl mb-1">👥</div>
          <div className="text-2xl sm:text-3xl font-extrabold font-mono text-slate-100">
            {PATIENTS.length}
          </div>
          <div className="text-[11px] font-mono uppercase text-slate-400 mt-0.5">
            Active In-Care Patients
          </div>
          <div className="text-[11px] text-[#00d4b4] mt-2">
            2 require priority review
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-lg">
          <div className="text-xl mb-1">🚨</div>
          <div className="text-2xl sm:text-3xl font-extrabold font-mono text-rose-400">
            1
          </div>
          <div className="text-[11px] font-mono uppercase text-slate-400 mt-0.5">
            Critical Telemetry Alerts
          </div>
          <div className="text-[11px] text-rose-400 mt-2">
            ST-segment elevation flagged
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-lg">
          <div className="text-xl mb-1">📅</div>
          <div className="text-2xl sm:text-3xl font-extrabold font-mono text-[#4f8cff]">
            6
          </div>
          <div className="text-[11px] font-mono uppercase text-slate-400 mt-0.5">
            Consultations Scheduled Today
          </div>
          <div className="text-[11px] text-slate-400 mt-2">
            Next: 10:00 AM (Telehealth)
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-lg">
          <div className="text-xl mb-1">⚡</div>
          <div className="text-2xl sm:text-3xl font-extrabold font-mono text-emerald-400">
            98.2%
          </div>
          <div className="text-[11px] font-mono uppercase text-slate-400 mt-0.5">
            AI Triage Agreement
          </div>
          <div className="text-[11px] text-emerald-400 mt-2">
            Ensemble model aligned
          </div>
        </div>
      </div>

      {/* Critical Patients & Telemetry Watch */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-rose-400" />
            <span>Priority Inpatient &amp; Outpatient Watchlist</span>
          </h3>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-rose-500/15 text-rose-400 border border-rose-500/30">
            ACTIVE TRIAGE
          </span>
        </div>

        <div className="space-y-3">
          {criticalPatients.map((pat) => (
            <div
              key={pat.id}
              onClick={() => onSelectPatient(pat)}
              className="p-4 rounded-xl bg-[#0b1425] border border-white/5 hover:border-[#00d4b4]/40 cursor-pointer transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3"
            >
              <div className="flex items-center gap-3.5">
                <div className="w-11 h-11 rounded-xl bg-rose-500/20 text-rose-300 font-bold flex items-center justify-center shrink-0">
                  {pat.avatar}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4 className="font-bold text-sm text-slate-100">{pat.name}</h4>
                    <span className="text-[10px] font-mono text-slate-400">
                      {pat.age}y / {pat.gender}
                    </span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-500/20 text-rose-400 border border-rose-500/30">
                      {pat.status}
                    </span>
                  </div>
                  <div className="text-xs text-slate-300 mt-0.5 font-medium">
                    {pat.condition}
                  </div>
                  <div className="text-[11px] text-slate-500 font-mono mt-0.5">
                    Bed: {pat.room} · Attending: {pat.doctor}
                  </div>
                </div>
              </div>

              {/* Vitals summary */}
              <div className="flex items-center gap-4 text-xs font-mono shrink-0">
                <div className="text-right">
                  <div className="text-slate-500 text-[10px]">HEART RATE</div>
                  <div className="font-bold text-slate-200">{pat.vitals.heartRate} bpm</div>
                </div>
                <div className="text-right">
                  <div className="text-slate-500 text-[10px]">GLUCOSE</div>
                  <div className="font-bold text-amber-400">{pat.vitals.bloodGlucose} mg/dL</div>
                </div>
                <div className="text-right">
                  <div className="text-slate-500 text-[10px]">SpO₂</div>
                  <div className="font-bold text-emerald-400">{pat.vitals.spo2}%</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Access to Doctor Functions */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div
          onClick={() => onNavigate('doctor-patients')}
          className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 hover:border-[#00d4b4]/50 cursor-pointer transition-all space-y-2 group"
        >
          <div className="w-10 h-10 rounded-xl bg-[#00d4b4]/10 text-[#00d4b4] flex items-center justify-center group-hover:scale-110 transition-transform">
            <Users className="w-5 h-5" />
          </div>
          <h4 className="font-bold text-sm text-slate-100">All Patients Directory</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Search patient charts, historical lab trends, and allergy rosters.
          </p>
        </div>

        <div
          onClick={() => onNavigate('soap-generator')}
          className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 hover:border-[#4f8cff]/50 cursor-pointer transition-all space-y-2 group"
        >
          <div className="w-10 h-10 rounded-xl bg-[#4f8cff]/10 text-[#4f8cff] flex items-center justify-center group-hover:scale-110 transition-transform">
            <FileText className="w-5 h-5" />
          </div>
          <h4 className="font-bold text-sm text-slate-100">AI Clinical SOAP Drafter</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Synthesize Subjective, Objective, Assessment, and Plan notes instantly with Gemini.
          </p>
        </div>

        <div
          onClick={() => onNavigate('teleconsultation')}
          className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 hover:border-emerald-500/50 cursor-pointer transition-all space-y-2 group"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center group-hover:scale-110 transition-transform">
            <Video className="w-5 h-5" />
          </div>
          <h4 className="font-bold text-sm text-slate-100">HD Teleconsultation Suite</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            WebRTC encrypted audio/video consultation with live continuous vital streams.
          </p>
        </div>
      </div>
    </div>
  );
};
