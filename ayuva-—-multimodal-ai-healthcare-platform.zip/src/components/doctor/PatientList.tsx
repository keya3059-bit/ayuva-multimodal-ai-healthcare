import React, { useState } from 'react';
import { Search, Filter, Stethoscope, ChevronRight, User, AlertCircle, Heart } from 'lucide-react';
import { PATIENTS } from '../../data/mockData';
import { Patient } from '../../types';

interface PatientListProps {
  onSelectPatient: (pat: Patient) => void;
}

export const PatientList: React.FC<PatientListProps> = ({ onSelectPatient }) => {
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');

  const filtered = PATIENTS.filter((p) => {
    const matchesSearch =
      p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.condition.toLowerCase().includes(search.toLowerCase()) ||
      p.id.toLowerCase().includes(search.toLowerCase());

    const matchesStatus = statusFilter === 'ALL' || p.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            Patient <span>Directory &amp; Census</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // INPATIENT &amp; OUTPATIENT EHR · ABHA INTEGRATED
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by patient name, MRN, or clinical condition…"
            className="w-full bg-[#080e1c] border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-[#00d4b4]"
          />
        </div>

        <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
          {['ALL', 'Stable', 'Under Review', 'Critical'].map((s) => (
            <button
              key={s}
              onClick={() => setStatusFilter(s)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors border ${
                statusFilter === s
                  ? 'bg-[#00d4b4]/20 border-[#00d4b4] text-[#00d4b4]'
                  : 'bg-[#080e1c] border-white/10 text-slate-400 hover:text-white'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Patient List */}
      <div className="space-y-3">
        {filtered.map((pat) => (
          <div
            key={pat.id}
            onClick={() => onSelectPatient(pat)}
            className="p-4 sm:p-5 rounded-2xl bg-[#080e1c] border border-white/10 hover:border-[#00d4b4]/40 cursor-pointer transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 group shadow-lg"
          >
            <div className="flex items-center gap-3.5">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#00d4b4]/20 to-[#4f8cff]/20 text-[#00d4b4] border border-[#00d4b4]/30 font-bold flex items-center justify-center text-sm shrink-0">
                {pat.avatar}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-sm text-slate-100 group-hover:text-[#00d4b4] transition-colors">
                    {pat.name}
                  </h4>
                  <span className="text-[10px] font-mono text-slate-400">
                    {pat.age}y / {pat.gender}
                  </span>
                  <span
                    className={`text-[9px] font-mono px-2 py-0.5 rounded-full border ${
                      pat.status === 'Critical'
                        ? 'bg-rose-500/20 text-rose-400 border-rose-500/30'
                        : pat.status === 'Under Review'
                        ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                        : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                    }`}
                  >
                    {pat.status.toUpperCase()}
                  </span>
                </div>
                <div className="text-xs text-slate-300 font-medium mt-0.5">
                  {pat.condition}
                </div>
                <div className="text-[10px] font-mono text-slate-500 mt-1">
                  MRN: {pat.id} · Room: {pat.room} · Attending: {pat.doctor}
                </div>
              </div>
            </div>

            {/* Vitals Summary Pill */}
            <div className="flex items-center justify-between md:justify-end gap-5 pt-3 md:pt-0 border-t md:border-t-0 border-white/5">
              <div className="flex items-center gap-3 font-mono text-xs">
                <div className="text-right">
                  <span className="text-[10px] text-slate-500 block">HR</span>
                  <span className="font-bold text-slate-200">{pat.vitals.heartRate} bpm</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-500 block">GLU</span>
                  <span className="font-bold text-amber-400">{pat.vitals.bloodGlucose}</span>
                </div>
                <div className="text-right">
                  <span className="text-[10px] text-slate-500 block">SpO₂</span>
                  <span className="font-bold text-emerald-400">{pat.vitals.spo2}%</span>
                </div>
              </div>

              <div className="w-8 h-8 rounded-xl bg-white/[0.04] group-hover:bg-[#00d4b4] group-hover:text-black flex items-center justify-center text-slate-400 transition-colors">
                <ChevronRight className="w-4 h-4" />
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
