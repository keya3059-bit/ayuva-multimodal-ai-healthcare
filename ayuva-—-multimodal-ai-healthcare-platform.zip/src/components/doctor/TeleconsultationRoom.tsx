import React, { useState, useEffect, useRef } from 'react';
import { Video, Mic, MicOff, VideoOff, PhoneOff, Share2, Pill, MessageSquare, Send, Heart, Activity } from 'lucide-react';
import { Patient } from '../../types';

interface TeleconsultationRoomProps {
  patient: Patient;
  onEndCall: () => void;
}

export const TeleconsultationRoom: React.FC<TeleconsultationRoomProps> = ({ patient, onEndCall }) => {
  const [micOn, setMicOn] = useState(true);
  const [videoOn, setVideoOn] = useState(true);
  const [activeTab, setActiveTab] = useState<'notes' | 'prescribe' | 'transcript'>('transcript');
  const [prescriptText, setPrescriptText] = useState('');
  const [transcript, setTranscript] = useState<string[]>([
    'Dr. Rajesh: Good morning Arjun, how has your chest discomfort been over the last 48 hours?',
    'Arjun: Morning Doctor. It has subsided slightly, mostly feeling tightness after climbing stairs.',
    'Dr. Rajesh: I see your continuous ECG patch is showing normal sinus rhythm at 74 BPM right now.',
  ]);

  const patientVideoCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Simulated Patient Video Stream Canvas
  useEffect(() => {
    const canvas = patientVideoCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frame = 0;
    let animId: number;

    const render = () => {
      frame++;
      const W = canvas.width;
      const H = canvas.height;

      // Dark clinical room background
      ctx.fillStyle = '#0a101f';
      ctx.fillRect(0, 0, W, H);

      // Patient silhouette portrait
      const cx = W / 2;
      const cy = H * 0.52;

      // Soft glow
      const grd = ctx.createRadialGradient(cx, cy, 30, cx, cy, 140);
      grd.addColorStop(0, 'rgba(79, 140, 255, 0.15)');
      grd.addColorStop(1, 'transparent');
      ctx.fillStyle = grd;
      ctx.fillRect(0, 0, W, H);

      // Head
      ctx.beginPath();
      ctx.ellipse(cx, cy - 35, 34, 42, 0, 0, Math.PI * 2);
      ctx.fillStyle = '#1e293b';
      ctx.fill();
      ctx.strokeStyle = 'rgba(0, 212, 180, 0.3)';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Shoulders
      ctx.beginPath();
      ctx.ellipse(cx, cy + 50, 75, 45, 0, 0, Math.PI);
      ctx.fillStyle = '#1e293b';
      ctx.fill();
      ctx.stroke();

      // Face landmarks subtle tracking
      for (let i = 0; i < 4; i++) {
        const lx = cx - 18 + i * 12 + Math.sin(frame * 0.04) * 2;
        const ly = cy - 30 + (i % 2) * 8;
        ctx.beginPath();
        ctx.arc(lx, ly, 2, 0, Math.PI * 2);
        ctx.fillStyle = '#00d4b4';
        ctx.fill();
      }

      // Facial photoplethysmography (rPPG) pulse indicator
      const pulseR = 8 + (Math.sin(frame * 0.08) + 1) * 3;
      ctx.beginPath();
      ctx.arc(W - 25, 25, pulseR, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(244, 63, 94, 0.4)';
      ctx.fill();
      ctx.beginPath();
      ctx.arc(W - 25, 25, 4, 0, Math.PI * 2);
      ctx.fillStyle = '#f43f5e';
      ctx.fill();

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, []);

  return (
    <div className="space-y-4">
      {/* Top Banner */}
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            <h2 className="text-xl font-bold text-slate-100">
              Encrypted Teleconsultation Room
            </h2>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
              WebRTC E2EE
            </span>
          </div>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            Patient: {patient?.name || 'Patient'} ({patient?.age || 45}y) · Session ID: #RTC-7712-SEC
          </div>
        </div>

        <button
          onClick={onEndCall}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-bold transition-colors"
        >
          <PhoneOff className="w-3.5 h-3.5" />
          <span>End Consultation</span>
        </button>
      </div>

      {/* Main Video & Workspace Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Video Canvas Column */}
        <div className="lg:col-span-2 space-y-3">
          <div className="relative rounded-3xl overflow-hidden bg-[#060c18] border border-white/10 shadow-2xl">
            {/* Patient Video Stream */}
            <canvas
              ref={patientVideoCanvasRef}
              width={640}
              height={380}
              className="w-full h-auto"
            />

            {/* Live Patient Vital Signs HUD Overlay */}
            <div className="absolute top-4 left-4 p-2.5 rounded-2xl bg-black/70 backdrop-blur-md border border-white/10 flex items-center gap-3 text-xs font-mono">
              <div className="flex items-center gap-1.5 text-rose-400">
                <Heart className="w-3.5 h-3.5 animate-pulse" />
                <span className="font-bold">{patient.vitals.heartRate} BPM</span>
              </div>
              <span className="text-slate-600">|</span>
              <div className="text-emerald-400">
                <span>SpO₂: {patient.vitals.spo2}%</span>
              </div>
              <span className="text-slate-600">|</span>
              <div className="text-amber-400">
                <span>GLU: {patient.vitals.bloodGlucose}</span>
              </div>
            </div>

            {/* Doctor Self-View PiP */}
            <div className="absolute bottom-4 right-4 w-32 h-24 rounded-2xl overflow-hidden bg-[#080e1c] border-2 border-[#00d4b4]/60 shadow-xl flex items-center justify-center text-center">
              <div className="text-[10px] font-mono text-slate-400">
                <div className="w-8 h-8 rounded-full bg-[#00d4b4]/20 text-[#00d4b4] flex items-center justify-center mx-auto mb-1 font-bold">
                  RK
                </div>
                Dr. Rajesh (You)
              </div>
            </div>

            {/* Call Control Toolbar */}
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex items-center gap-2 p-2 rounded-2xl bg-black/80 backdrop-blur-md border border-white/10">
              <button
                onClick={() => setMicOn(!micOn)}
                className={`p-2.5 rounded-xl transition-colors ${
                  micOn ? 'bg-white/[0.1] text-slate-200' : 'bg-rose-500/20 text-rose-400'
                }`}
              >
                {micOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
              </button>

              <button
                onClick={() => setVideoOn(!videoOn)}
                className={`p-2.5 rounded-xl transition-colors ${
                  videoOn ? 'bg-white/[0.1] text-slate-200' : 'bg-rose-500/20 text-rose-400'
                }`}
              >
                {videoOn ? <Video className="w-4 h-4" /> : <VideoOff className="w-4 h-4" />}
              </button>

              <button
                onClick={() => alert('Screen sharing enabled for clinical review.')}
                className="p-2.5 rounded-xl bg-white/[0.1] text-slate-200 hover:bg-white/[0.2]"
              >
                <Share2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Clinical Sidebar Column */}
        <div className="rounded-3xl bg-[#080e1c] border border-white/10 shadow-2xl p-4 flex flex-col space-y-3">
          {/* Sub-Tabs */}
          <div className="flex rounded-xl bg-white/[0.04] p-1 border border-white/5">
            {[
              { id: 'transcript', label: 'AI Scribe' },
              { id: 'prescribe', label: 'Rx Pad' },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setActiveTab(t.id as any)}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                  activeTab === t.id
                    ? 'bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black shadow-md'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          {activeTab === 'transcript' ? (
            <div className="flex-1 flex flex-col justify-between space-y-3">
              <div className="space-y-2 text-xs text-slate-300 leading-relaxed overflow-y-auto max-h-[320px] pr-1">
                {transcript.map((line, idx) => (
                  <div
                    key={idx}
                    className="p-2 rounded-xl bg-[#0b1425] border border-white/5 text-[11px]"
                  >
                    {line}
                  </div>
                ))}
              </div>

              <div className="p-2 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-[10px] text-emerald-300 flex items-center gap-1.5 font-mono">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>AI Clinical Scribe is actively logging SOAP data</span>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="text-xs font-bold text-slate-200">Issue Digital e-Prescription</div>
              <textarea
                rows={6}
                value={prescriptText}
                onChange={(e) => setPrescriptText(e.target.value)}
                placeholder="1. Tab. Metformin 500mg - 1 tab BID with meals x 30 days&#10;2. Tab. Telmisartan 40mg - 1 tab OD morning x 30 days"
                className="w-full bg-[#0b1425] border border-white/10 rounded-xl p-3 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-[#00d4b4]"
              />
              <button
                onClick={() => {
                  alert(`Digital prescription signed by Dr. Rajesh Kumar & dispatched to Ayuva Pharmacy drone fleet!`);
                  setPrescriptText('');
                }}
                className="w-full py-2 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs shadow-md"
              >
                Sign &amp; Transmit to Pharmacy
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
