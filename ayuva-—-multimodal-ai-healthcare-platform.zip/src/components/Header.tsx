import React from 'react';
import {
  Menu,
  Search,
  Bell,
  Sun,
  Moon,
  Activity,
  User
} from 'lucide-react';
import { UserProfile } from '../types';

interface HeaderProps {
  user: UserProfile;
  onOpenSidebar: () => void;
  onOpenNotifications: () => void;
  unreadCount: number;
  isLightMode: boolean;
  onToggleTheme: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  onOpenSidebar,
  onOpenNotifications,
  unreadCount,
  isLightMode,
  onToggleTheme,
  searchQuery,
  onSearchChange,
}) => {
  return (
    <header className="h-16 px-4 sm:px-6 bg-[#04080f]/90 border-b border-white/10 backdrop-blur-xl sticky top-0 z-30 flex items-center justify-between gap-3">
      <div className="flex items-center gap-3">
        <button
          onClick={onOpenSidebar}
          className="lg:hidden p-2 rounded-lg text-slate-300 hover:text-white hover:bg-white/5 transition-colors"
          aria-label="Open Navigation"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="relative hidden sm:flex items-center w-64 md:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search symptoms, doctors, records…"
            className="w-full bg-[#080e1c] border border-white/10 rounded-xl pl-9 pr-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-[#00d4b4] transition-colors"
          />
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-3">
        {/* Portal Badge */}
        <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-[#080e1c] border border-white/10 text-[11px] font-semibold text-slate-300">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="capitalize">{user.portal} Portal</span>
        </div>

        {/* Theme Toggle */}
        <button
          onClick={onToggleTheme}
          className="p-2 rounded-xl bg-[#080e1c] border border-white/10 text-slate-400 hover:text-[#00d4b4] transition-colors"
          title="Toggle Dark / Light theme"
        >
          {isLightMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
        </button>

        {/* Notifications Button */}
        <button
          onClick={onOpenNotifications}
          className="relative p-2 rounded-xl bg-[#080e1c] border border-white/10 text-slate-400 hover:text-[#00d4b4] transition-colors"
          title="Notifications"
        >
          <Bell className="w-4 h-4" />
          {unreadCount > 0 && (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-rose-500 border border-[#04080f]" />
          )}
        </button>

        {/* User Pill */}
        <div className="flex items-center gap-2 pl-1 sm:pl-2 border-l border-white/10">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#00d4b4] to-[#4f8cff] flex items-center justify-center font-bold text-xs text-black shrink-0 shadow-md">
            {user.avatar || 'AU'}
          </div>
          <div className="hidden md:block text-left">
            <div className="text-xs font-semibold text-slate-200 leading-none truncate max-w-[120px]">
              {user.name}
            </div>
            <div className="text-[10px] text-slate-400 leading-none mt-1">
              {user.role}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
