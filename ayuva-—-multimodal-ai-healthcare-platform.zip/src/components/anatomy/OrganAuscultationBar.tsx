import React, { useEffect, useRef, useState } from 'react';
import {
  Volume2,
  VolumeX,
  Play,
  Pause,
  Activity,
  Radio,
  Sparkles,
  Stethoscope,
  Headphones,
  Sliders,
  ChevronDown
} from 'lucide-react';
import {
  organAudioEngine,
  OrganSoundType,
  OrganAudioPreset,
  OrganAudioState
} from '../../utils/organAudioEngine';

interface OrganAuscultationBarProps {
  currentOrgan: OrganSoundType;
  selectedStructureName?: string;
  heartBPM: number;
  respirationRate: number;
  brainWaveBand: 'alpha' | 'beta' | 'gamma' | 'theta';
  renalGFR: number;
  liverPortalFlow: number;
  spineAxialLoad: number;
  className?: string;
}

export const OrganAuscultationBar: React.FC<OrganAuscultationBarProps> = ({
  currentOrgan,
  selectedStructureName,
  heartBPM,
  respirationRate,
  brainWaveBand,
  renalGFR,
  liverPortalFlow,
  spineAxialLoad,
  className = ''
}) => {
  const [audioState, setAudioState] = useState<OrganAudioState>(organAudioEngine.getState());
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [prevVolume, setPrevVolume] = useState<number>(0.65);
  const [showPresetsMenu, setShowPresetsMenu] = useState<boolean>(false);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Subscribe to audio engine changes
  useEffect(() => {
    const unsubscribe = organAudioEngine.subscribe((state) => {
      setAudioState(state);
    });
    return () => unsubscribe();
  }, []);

  // Update biometric parameters in audio engine whenever props change
  useEffect(() => {
    organAudioEngine.updateParameters({
      bpm: heartBPM,
      respirationRate: respirationRate,
      brainwave: brainWaveBand,
      gfr: renalGFR,
      portalFlow: liverPortalFlow,
      axialLoad: spineAxialLoad
    });
  }, [heartBPM, respirationRate, brainWaveBand, renalGFR, liverPortalFlow, spineAxialLoad]);

  // When organ changes, update active sound if playing
  useEffect(() => {
    if (audioState.isPlaying && audioState.activeOrgan !== currentOrgan) {
      organAudioEngine.startSound(currentOrgan);
    }
  }, [currentOrgan, audioState.isPlaying, audioState.activeOrgan]);

  // Real-time oscilloscope / frequency audio visualizer canvas animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    const dataArray = new Uint8Array(64);

    const render = () => {
      animId = requestAnimationFrame(render);
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      if (!audioState.isPlaying) {
        // Idle flat line with subtle resting glow
        ctx.beginPath();
        ctx.moveTo(0, height / 2);
        ctx.lineTo(width, height / 2);
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.15)';
        ctx.lineWidth = 1.5;
        ctx.stroke();
        return;
      }

      organAudioEngine.getByteTimeDomainData(dataArray);

      // Draw glowing oscilloscope waveform
      ctx.beginPath();
      const sliceWidth = width / dataArray.length;
      let x = 0;

      for (let i = 0; i < dataArray.length; i++) {
        const v = dataArray[i] / 128.0;
        const y = (v * height) / 2;

        if (i === 0) {
          ctx.moveTo(x, y);
        } else {
          ctx.lineTo(x, y);
        }
        x += sliceWidth;
      }

      // Organ-specific color theme
      let strokeColor = '#06b6d4'; // cyan default
      if (currentOrgan === 'heart') strokeColor = '#f43f5e'; // rose
      else if (currentOrgan === 'lungs') strokeColor = '#14b8a6'; // teal
      else if (currentOrgan === 'kidneys') strokeColor = '#3b82f6'; // blue
      else if (currentOrgan === 'liver') strokeColor = '#f59e0b'; // amber
      else if (currentOrgan === 'spine') strokeColor = '#a855f7'; // purple

      ctx.strokeStyle = strokeColor;
      ctx.lineWidth = 2;
      ctx.shadowBlur = 8;
      ctx.shadowColor = strokeColor;
      ctx.stroke();
      ctx.shadowBlur = 0; // reset
    };

    render();

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [audioState.isPlaying, currentOrgan]);

  const handleTogglePlay = () => {
    organAudioEngine.toggleSound(currentOrgan);
  };

  const handleToggleMute = () => {
    if (isMuted) {
      organAudioEngine.setVolume(prevVolume || 0.6);
      setIsMuted(false);
    } else {
      setPrevVolume(audioState.volume);
      organAudioEngine.setVolume(0);
      setIsMuted(true);
    }
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    organAudioEngine.setVolume(val);
    if (val > 0 && isMuted) {
      setIsMuted(false);
    }
  };

  // Presets available per organ
  const getPresetsForOrgan = (): { id: OrganAudioPreset; label: string; desc: string }[] => {
    switch (currentOrgan) {
      case 'heart':
        return [
          { id: 'normal-sinus', label: 'Normal S1/S2 Sinus Rhythm', desc: 'Bicuspid/tricuspid & aortic closure (lub-dub)' },
          { id: 'mitral-murmur', label: 'Mitral Regurgitation Murmur', desc: 'Holosystolic high-frequency turbulent murmur' },
          { id: 'tachycardia-gallop', label: 'Ventricular S3/S4 Gallop', desc: 'Rapid passive ventricular filling cadence' }
        ];
      case 'brain':
        return [
          { id: 'alpha-relaxed', label: 'Alpha Wave Synchrony (10 Hz)', desc: 'Parieto-occipital wakeful contemplative rhythm' },
          { id: 'beta-focused', label: 'Beta Active Alertness (20 Hz)', desc: 'Frontal cognitive processing and active vigilance' },
          { id: 'gamma-cognitive', label: 'Gamma Burst Resonance (42 Hz)', desc: 'High-frequency cross-modal synaptic binding' },
          { id: 'theta-deep', label: 'Theta Restorative Drone (6 Hz)', desc: 'Hippocampal memory consolidation frequency' }
        ];
      case 'lungs':
        return [
          { id: 'vesicular-normal', label: 'Vesicular Breath Sounds', desc: 'Soft low-pitch rustle over peripheral alveoli' },
          { id: 'bronchial', label: 'Bronchial Breath Sounds', desc: 'Hollow, tubular sounds over central trachea' },
          { id: 'wheeze', label: 'Expiratory Wheeze (Asthmatic)', desc: 'High-pitched musical adventitious vibration' }
        ];
      case 'kidneys':
        return [
          { id: 'renal-arterial', label: 'Renal Artery Pulsatile Flow', desc: 'Systolic arterial pulse with parenchymal perfusion' },
          { id: 'glomerular-filtration', label: 'Glomerular Ultrafiltration', desc: 'Continuous capillary countercurrent exchange hum' }
        ];
      case 'liver':
        return [
          { id: 'portal-venous-hum', label: 'Portal Vein Venous Hum', desc: 'Continuous low-frequency laminar venous flow' },
          { id: 'sinusoidal-flow', label: 'Hepatic Sinusoid Inflow', desc: 'Low-shear microvascular reticuloendothelial flow' }
        ];
      case 'spine':
        return [
          { id: 'axial-resonance', label: 'Lumbar Axial Resonance', desc: 'Weight-bearing hydraulic intervertebral damping' },
          { id: 'vertebral-articulation', label: 'Facet Joint Articulation', desc: 'Biomechanical segment alignment acoustic tone' }
        ];
      default:
        return [];
    }
  };

  const presets = getPresetsForOrgan();
  const currentPresetItem = presets.find((p) => p.id === audioState.activePreset) || presets[0];

  const getOrganTheme = () => {
    switch (currentOrgan) {
      case 'heart':
        return {
          border: 'border-rose-500/30',
          bgGlow: 'bg-rose-500/10',
          accentBtn: 'bg-rose-500 hover:bg-rose-600 text-white shadow-rose-500/30',
          badgeText: 'text-rose-400',
          waveColor: '#f43f5e'
        };
      case 'brain':
        return {
          border: 'border-cyan-500/30',
          bgGlow: 'bg-cyan-500/10',
          accentBtn: 'bg-cyan-400 hover:bg-cyan-500 text-black font-bold shadow-cyan-400/30',
          badgeText: 'text-cyan-300',
          waveColor: '#06b6d4'
        };
      case 'lungs':
        return {
          border: 'border-teal-500/30',
          bgGlow: 'bg-teal-500/10',
          accentBtn: 'bg-teal-500 hover:bg-teal-600 text-white shadow-teal-500/30',
          badgeText: 'text-teal-300',
          waveColor: '#14b8a6'
        };
      case 'kidneys':
        return {
          border: 'border-blue-500/30',
          bgGlow: 'bg-blue-500/10',
          accentBtn: 'bg-blue-500 hover:bg-blue-600 text-white shadow-blue-500/30',
          badgeText: 'text-blue-300',
          waveColor: '#3b82f6'
        };
      case 'liver':
        return {
          border: 'border-amber-500/30',
          bgGlow: 'bg-amber-500/10',
          accentBtn: 'bg-amber-500 hover:bg-amber-600 text-black font-bold shadow-amber-500/30',
          badgeText: 'text-amber-300',
          waveColor: '#f59e0b'
        };
      case 'spine':
        return {
          border: 'border-purple-500/30',
          bgGlow: 'bg-purple-500/10',
          accentBtn: 'bg-purple-500 hover:bg-purple-600 text-white shadow-purple-500/30',
          badgeText: 'text-purple-300',
          waveColor: '#a855f7'
        };
    }
  };

  const theme = getOrganTheme();

  return (
    <div
      className={`p-3.5 sm:p-4 rounded-2xl bg-[#060b17]/95 border ${theme.border} shadow-xl backdrop-blur-md relative overflow-hidden ${className}`}
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
        {/* Left: Auscultation Badge & Play/Stop Trigger */}
        <div className="flex items-center gap-3">
          <button
            onClick={handleTogglePlay}
            className={`p-3 rounded-2xl flex items-center justify-center transition-all shadow-lg ${
              audioState.isPlaying
                ? `${theme.accentBtn} ring-4 ring-white/10 scale-105`
                : 'bg-white/10 hover:bg-white/15 text-white border border-white/20'
            }`}
            title={audioState.isPlaying ? 'Pause Organ Auscultation' : 'Listen to Organ Auscultation (Web Audio)'}
          >
            {audioState.isPlaying ? (
              <Pause className="w-5 h-5 fill-current" />
            ) : (
              <Play className="w-5 h-5 fill-current translate-x-0.5" />
            )}
          </button>

          <div>
            <div className="flex items-center gap-2">
              <span className="flex items-center gap-1.5 text-xs font-mono font-bold tracking-wide uppercase text-white">
                <Stethoscope className={`w-3.5 h-3.5 ${theme.badgeText} ${audioState.isPlaying ? 'animate-pulse' : ''}`} />
                <span>3D ORGAN AUSCULTATION</span>
              </span>
              <span
                className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-semibold uppercase ${
                  audioState.isPlaying
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : 'bg-white/5 text-slate-400 border border-white/10'
                }`}
              >
                {audioState.isPlaying ? 'LIVE AUDIO ACTIVE' : 'MUTED / STANDBY'}
              </span>
            </div>

            <p className="text-[11px] text-slate-300 mt-0.5 flex items-center gap-1.5">
              <span>Acoustic Profile:</span>
              <span className={`font-semibold ${theme.badgeText}`}>
                {currentPresetItem?.label || 'Auscultation Stream'}
              </span>
              {selectedStructureName && (
                <span className="hidden sm:inline text-slate-400">• Probe: {selectedStructureName}</span>
              )}
            </p>
          </div>
        </div>

        {/* Center: Live Real-time Oscilloscope Canvas */}
        <div className="flex-1 max-w-xs sm:max-w-sm flex items-center gap-3 bg-[#03060f] px-3 py-1.5 rounded-xl border border-white/10">
          <Activity className={`w-4 h-4 shrink-0 ${audioState.isPlaying ? theme.badgeText : 'text-slate-500'}`} />
          <canvas
            ref={canvasRef}
            width={200}
            height={32}
            className="w-full h-8 rounded"
          />
        </div>

        {/* Right: Sound Presets Dropdown & Volume Slider */}
        <div className="flex items-center gap-3 flex-wrap sm:flex-nowrap">
          {/* Preset Selector */}
          <div className="relative">
            <button
              onClick={() => setShowPresetsMenu(!showPresetsMenu)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/15 text-xs text-slate-200 font-medium transition-all"
            >
              <Radio className="w-3.5 h-3.5 text-cyan-400" />
              <span className="max-w-[130px] truncate text-[11px]">
                {currentPresetItem?.label.split(' ')[0] || 'Mode'}
              </span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {showPresetsMenu && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setShowPresetsMenu(false)}
                />
                <div className="absolute right-0 bottom-full mb-2 w-64 p-1.5 rounded-xl bg-[#080e1c] border border-white/20 shadow-2xl z-50 space-y-1">
                  <div className="px-2 py-1 text-[10px] font-mono text-slate-400 uppercase tracking-wider">
                    {currentOrgan.toUpperCase()} BIOACOUSTIC PRESETS
                  </div>
                  {presets.map((preset) => (
                    <button
                      key={preset.id}
                      onClick={() => {
                        organAudioEngine.setPreset(preset.id);
                        if (!audioState.isPlaying) {
                          organAudioEngine.startSound(currentOrgan, preset.id);
                        }
                        setShowPresetsMenu(false);
                      }}
                      className={`w-full text-left px-2.5 py-1.5 rounded-lg text-xs transition-all ${
                        audioState.activePreset === preset.id
                          ? 'bg-white/15 text-white font-semibold'
                          : 'text-slate-300 hover:bg-white/5 hover:text-white'
                      }`}
                    >
                      <div className="font-medium text-[11px]">{preset.label}</div>
                      <div className="text-[10px] text-slate-400 leading-tight">{preset.desc}</div>
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Volume Control */}
          <div className="flex items-center gap-1.5 bg-white/5 px-2.5 py-1.5 rounded-xl border border-white/10">
            <button
              onClick={handleToggleMute}
              className="text-slate-400 hover:text-white transition-colors"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted || audioState.volume === 0 ? (
                <VolumeX className="w-4 h-4 text-rose-400" />
              ) : (
                <Volume2 className="w-4 h-4 text-slate-300" />
              )}
            </button>
            <input
              type="range"
              min="0"
              max="1"
              step="0.05"
              value={isMuted ? 0 : audioState.volume}
              onChange={handleVolumeChange}
              className="w-16 accent-cyan-400 cursor-pointer"
              title={`Volume: ${Math.round((isMuted ? 0 : audioState.volume) * 100)}%`}
            />
            <span className="font-mono text-[10px] text-slate-400 w-7 text-right">
              {Math.round((isMuted ? 0 : audioState.volume) * 100)}%
            </span>
          </div>

          {/* Quick Sound Probe Button */}
          <button
            onClick={() => {
              organAudioEngine.playStructureProbeSound(currentOrgan, selectedStructureName);
            }}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-[11px] font-mono text-slate-300 hover:text-white transition-all whitespace-nowrap"
            title="Play localized acoustic probe tone for the active anatomical structure"
          >
            <Headphones className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden lg:inline">Acoustic Probe</span>
          </button>
        </div>
      </div>
    </div>
  );
};
