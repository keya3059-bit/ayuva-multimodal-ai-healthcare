import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  FileText,
  Printer,
  Copy,
  Download,
  Check,
  ShieldCheck,
  Sparkles,
  Heart,
  Brain,
  Calendar,
  User,
  Activity,
  Edit3,
  ChevronDown,
  Info,
  CheckCircle2,
  Stamp
} from 'lucide-react';
import { OrganType } from './Anatomical3DViewer';

interface ClinicalReportGeneratorProps {
  organ: OrganType;
  onSwitchOrgan?: (organ: OrganType) => void;
}

export const ClinicalReportGenerator: React.FC<ClinicalReportGeneratorProps> = ({
  organ,
  onSwitchOrgan,
}) => {
  const [reportFormat, setReportFormat] = useState<'physician' | 'patient'>('physician');
  const [copied, setCopied] = useState<boolean>(false);
  const [downloaded, setDownloaded] = useState<boolean>(false);
  const [isSigned, setIsSigned] = useState<boolean>(true);
  const [physicianAddendum, setPhysicianAddendum] = useState<string>(
    'Patient instructed to remain NPO except medications until catheterization consult at 0800 tomorrow.'
  );
  const [isEditingAddendum, setIsEditingAddendum] = useState<boolean>(false);

  const reportDate = new Date().toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });
  const reportTime = new Date().toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });

  // Cardiology Report Data
  const cardiacReport = {
    examTitle: 'DUAL-SOURCE CORONARY CT ANGIOGRAPHY (CCTA) WITH FFR-CT HEMODYNAMICS',
    modality: 'Computed Tomography Angiography (256-Slice Somatom Definition Flash)',
    indication: '58-year-old male presenting with exertional retrosternal angina and abnormal treadmill stress ECG. Evaluate for hemodynamically significant coronary artery stenosis.',
    technique: 'Prospective ECG-gated axial acquisition following intravenous administration of 75 mL Omnipaque 350 contrast agent. Sublingual nitroglycerin (0.4 mg) and IV Metoprolol (5 mg) administered pre-scan. Heart rate stable at 58 BPM during scan. High-definition multiplanar and 3D volume rendering reconstruction performed with AI vessel segmentation.',
    findings: {
      leftMain: 'Patent, normal caliber without luminal narrowing or vulnerable soft plaque (0% stenosis).',
      lad: 'Moderate-to-severe focal stenosis (68% luminal reduction) in the mid-LAD immediately distal to the first diagonal branch (D1). Mixed fibrocalcific plaque with dense calcified core (Agatston Calcium Score: 284). AI-derived Fractional Flow Reserve (FFR-CT) distal to lesion is 0.74, indicating lesion-specific physiological ischemia.',
      lcx: 'Mild eccentric plaque in proximal LCx causing approximately 25-30% luminal narrowing. Distal flow is brisk with preserved vessel caliber.',
      rca: 'Dominant right coronary artery with minor intimal irregularities without flow-limiting stenosis (<20% narrowing).',
      myocardium: 'Normal left ventricular chamber size with mild concentric left ventricular remodeling. No transmural myocardial infarction scar. Calculated Left Ventricular Ejection Fraction (LVEF): 56%. Estimated peak systolic wall stress: 41.2 kPa.',
      extracardiac: 'Visualized thoracic aorta caliber: 38.6 mm (mild upper normal ectasia). Visualized lung bases are clear without active focal consolidation or pleural effusion.'
    },
    impression: [
      '1. CAD-RADS 4A / P3 / FFR(+) : Severe hemodynamically significant stenosis (68%) of the mid-Left Anterior Descending (LAD) coronary artery with ischemic FFR-CT of 0.74.',
      '2. Non-obstructive coronary atherosclerosis involving the proximal Circumflex artery (CAD-RADS 2).',
      '3. Mild concentric left ventricular remodeling with preserved global systolic function (LVEF 56%).',
      '4. Total Coronary Artery Calcium (CAC) Agatston Score: 312 (72nd percentile for age/gender, High Cardiovascular Plaque Burden).'
    ],
    icd10: [
      { code: 'I25.110', desc: 'Atherosclerotic heart disease of native coronary artery with unstable angina pectoris' },
      { code: 'I25.84', desc: 'Coronary atherosclerosis due to calcified coronary lesion' },
      { code: 'I10', desc: 'Essential (primary) hypertension' },
      { code: 'E78.00', desc: 'Pure hypercholesterolemia, unspecified' }
    ],
    recommendations: [
      'Urgent Cardiology consult for invasive coronary catheterization with high probability of Percutaneous Coronary Intervention (PCI) and Drug-Eluting Stent (DES) to mid-LAD.',
      'Initiate guideline-directed medical therapy: Aspirin 81 mg daily + P2Y12 inhibitor, high-intensity Atorvastatin 80 mg daily, and beta-blocker titration.',
      'Lifestyle modification counseling including cardiac rehabilitation post-revascularization.'
    ]
  };

  // Neurology / Stroke Report Data
  const neuroReport = {
    examTitle: 'MULTIPARAMETRIC 3.0-TESLA BRAIN MRI WITH DIFFUSION & ARTERIAL SPIN PERFUSION',
    modality: 'Magnetic Resonance Imaging 3.0T (Siemens Magnetom Skyra)',
    indication: '58-year-old male presenting with acute onset right hemiparesis and expressive aphasia commencing 3.2 hours prior to imaging. Evaluate for acute ischemic stroke and penumbral target mismatch.',
    technique: 'Axial and sagittal multiparametric sequences including Diffusion-Weighted Imaging (DWI, b=0, 1000 s/mm²), Apparent Diffusion Coefficient (ADC) mapping, 3D T2-FLAIR, T2*-weighted Gradient Recalled Echo (GRE), Susceptibility Weighted Imaging (SWI), and 3D Arterial Spin Labeling (ASL) cerebral perfusion.',
    findings: {
      parenchyma: 'Area of restricted diffusion (bright on DWI with corresponding dark hypointensity on ADC map, mean ADC value 540 x 10^-6 mm²/s) in the left temporoparietal cortex and insular ribbon, measuring 16.4 mL in volume, diagnostic of acute ischemic core infarct.',
      perfusion: 'Arterial Spin Labeling and Tmax > 6.0s perfusion delay map demonstrates a total hypoperfusion zone of 54.8 mL across the left Middle Cerebral Artery (MCA) M2 vascular territory. Penumbra volume calculated at 38.4 mL with a salvageable Target Mismatch Ratio of 3.34x (DEFUSE-3 / DAWN criteria satisfied).',
      vessels: 'MRA of intracranial vessels demonstrates focal flow attenuation in the inferior trunk of the left M2 MCA segment. Internal Carotid Artery (ICA) siphon and basilar artery remain widely patent.',
      hemorrhage: 'No evidence of acute intracranial hemorrhage, petechial microbleeds, or cortical superficial siderosis on SWI.',
      massEffect: 'No midline shift (0.0 mm). Ventricles, cisterns, and cortical sulci are within normal limits for age without evidence of impending herniation. ASPECTS score: 8 / 10.'
    },
    impression: [
      '1. Acute ischemic stroke involving the left MCA posterior parietal territory with 16.4 mL core infarct volume.',
      '2. Substantial viable ischemic penumbra measuring 38.4 mL (Penumbra/Core Target Mismatch Ratio: 3.34x), indicating high salvagability upon prompt reperfusion.',
      '3. Favorable ASPECTS score of 8/10 with no intracranial hemorrhage.',
      '4. Patient presents within the 4.5-hour therapeutic window for IV thrombolysis and satisfies extended-window EVT criteria.'
    ],
    icd10: [
      { code: 'I63.411', desc: 'Cerebral infarction due to embolism of left middle cerebral artery' },
      { code: 'R47.01', desc: 'Aphasia, expressive' },
      { code: 'G81.91', desc: 'Hemiplegia, unspecified affecting right dominant side' }
    ],
    recommendations: [
      'Immediate Code Stroke activation for IV Thrombolytic therapy (IV-Alteplase 0.9 mg/kg) under strict blood pressure parameters (<185/110 mmHg).',
      'Neuro-interventional radiology notification for emergent mechanical thrombectomy if M1/M2 branch accessibility is confirmed.',
      'Continuous neuro-ICU monitoring with serial NIHSS evaluations every 15 minutes.'
    ]
  };

  // Pulmonary / Lungs Report Data
  const pulmonaryReport = {
    examTitle: 'HIGH-RESOLUTION CHEST CT (HRCT) WITH VOLUMETRIC AIRWAY & DIFFUSION MODELING',
    modality: 'Computed Tomography Dual-Source Volumetric HRCT (Siemens Somatom)',
    indication: '58-year-old male with progressive exertional dyspnea, non-productive cough, and baseline SpO2 of 96%. Rule out subclinical interstitial fibrosis or chronic obstructive remodeling.',
    technique: 'Volumetric inspiratory and expiratory high-resolution thin-section CT (0.625 mm slice collimation) without intravenous contrast. Computer-aided parenchymal densitometry with automated lobe-by-lobe lung volumetry.',
    findings: {
      trachea: 'Trachea and central carina are midline with normal cross-sectional luminal area. No tracheobronchomalacia.',
      bronchialTree: 'Segmental and subsegmental bronchi display uniform wall thickness. No focal bronchiectasis, mucus plugging, or bronchiolectasis.',
      parenchyma: 'Lung parenchyma displays symmetric aeration. No ground-glass opacities, mosaic attenuation, traction bronchiectasis, or honeycombing.',
      pleura: 'Visceral and parietal pleural surfaces are thin and smooth without pleural effusion, thickening, or calcified plaques.',
      mediastinum: 'Mediastinal and hilar lymph nodes are normal in size (<10 mm short axis). Cardiac silhouette is normal in contour with no pericardial effusion.'
    },
    impression: [
      '1. Normal inspiratory/expiratory HRCT of the chest with no evidence of interstitial lung disease or active alveolitis.',
      '2. Preserved bilateral lung volume (TLC estimated at 5.8 L) with normal automated parenchymal density distribution (-850 to -910 HU).',
      '3. No pulmonary embolism, focal mass lesion, or pleural disease.'
    ],
    icd10: [
      { code: 'R06.02', desc: 'Shortness of breath on exertion' },
      { code: 'Z71.89', desc: 'Other specified healthcare counseling / clinical checkup' }
    ],
    recommendations: [
      'Pulmonary function testing (spirometry with post-bronchodilator challenge and DLCO) to complement volumetric CT data.',
      'Maintain regular aerobic conditioning and avoid environmental respiratory particulate exposure.'
    ]
  };

  // Renal / Kidneys Report Data
  const renalReport = {
    examTitle: 'CONTRAST-ENHANCED RENAL MULTIPHASE CT & DUPLEX RENOVASCULAR HEMODYNAMICS',
    modality: 'Multidetector Helical CT Urography & Color Duplex Doppler (GE Revolution)',
    indication: '58-year-old male with mild borderline hypertension. Evaluate renal parenchymal thickness, cortical perfusion, and main renal artery velocity gradients.',
    technique: 'Multiphase acquisition including non-contrast, corticomedullary (35s post-IV Isovue 370), nephrographic (90s), and delayed excretory phases (8 min). Transabdominal renal resistive index (RI) measured by spectral Doppler.',
    findings: {
      rightKidney: 'Measures 11.4 cm in bipolar length with normal cortical thickness (1.8 cm). Homogeneous nephrographic enhancement without focal solid lesion, cyst, or stone. Peak systolic velocity in main renal artery: 94 cm/s (normal < 180 cm/s). Resistive Index: 0.62.',
      leftKidney: 'Measures 11.7 cm in bipolar length with preserved corticomedullary differentiation. No hydronephrosis, calculus, or cortical scar. Main renal artery PSV: 98 cm/s. Resistive Index: 0.64.',
      collectingSystem: 'Bilateral calyces, renal pelves, and ureters opacify symmetrically without filling defects or extrinsic stricture.',
      vascularity: 'Single main renal artery bilaterally without proximal ostial stenosis. Renal veins are widely patent without thrombus.'
    },
    impression: [
      '1. Structurally normal bilateral kidneys with intact cortical thickness and symmetric prompt excretion.',
      '2. Normal renal artery duplex velocities with normal resistive indices (RI < 0.70), excluding renovascular hypertension.',
      '3. Calculated eGFR is concordant with preserved bilateral functional nephron mass (>90 mL/min).'
    ],
    icd10: [
      { code: 'I10', desc: 'Essential primary hypertension' },
      { code: 'Z87.442', desc: 'Personal history of normal kidney structure' }
    ],
    recommendations: [
      'Continue standard hydration and routine annual serum creatinine / microalbuminuria screening.',
      'Avoid high-dose NSAIDs to preserve renal autoregulatory hemodynamics.'
    ]
  };

  // Hepatic / Liver Report Data
  const hepaticReport = {
    examTitle: 'DYNAMIC MULTIPHASE HEPATIC MRI WITH MR ELASTOGRAPHY (MRE)',
    modality: 'Magnetic Resonance Imaging 3.0T with Eovist Hepatobiliary Phase Contrast',
    indication: '58-year-old male with metabolic health optimization check. Evaluate liver fat fraction, portal venous flow, and hepatic stiffness.',
    technique: 'Multiphasic 3D GRE imaging before and after IV Gd-EOB-DTPA (Eovist) contrast: arterial (20s), portal venous (60s), transitional (3m), and hepatobiliary excretory phase (20m). Acoustic shear wave MR elastography performed at 60 Hz.',
    findings: {
      parenchyma: 'Liver is normal in size and contour with sharp edges. No architectural distortion or nodular surface. Proton density fat fraction (PDFF): 3.2% (normal < 5.0%, no significant steatosis).',
      elastography: 'Mean liver stiffness measured across Couinaud segments: 2.3 kPa (Stage F0-F1, normal liver elasticity, no significant fibrosis).',
      focalLesions: 'No suspicious hypervascular lesions on arterial phase. Normal homogeneous uptake on 20-minute hepatobiliary phase.',
      vasculature: 'Main portal vein is patent with normal hepatopetal flow direction (mean velocity 24 cm/s). Hepatic veins drain normally into the IVC.',
      biliary: 'Intrahepatic and extrahepatic bile ducts are non-dilated. Common bile duct measures 4.2 mm. Gallbladder is normal without calculi.'
    },
    impression: [
      '1. Normal hepatic MRI and MR Elastography: liver stiffness 2.3 kPa (consistent with no significant fibrosis, F0).',
      '2. Normal hepatic proton density fat fraction (PDFF 3.2%, no hepatic steatosis).',
      '3. Fully patent portal venous vasculature with preserved hepatopetal hemodynamics.'
    ],
    icd10: [
      { code: 'Z13.89', desc: 'Encounter for screening for other disorder' },
      { code: 'K76.9', desc: 'Liver disease, unspecified (excluded by exam)' }
    ],
    recommendations: [
      'Maintain balanced low-glycemic Mediterranean nutrition to prevent hepatic metabolic stress.',
      'Routine annual metabolic panel (AST, ALT, Bilirubin, Albumin).'
    ]
  };

  // Vertebral Spine Report Data
  const spineReport = {
    examTitle: 'WHOLE-SPINE HIGH-FIELD MRI WITH SAGITTAL & AXIAL BIOMECHANICAL WEIGHT-BEARING RECONSTRUCTION',
    modality: 'Magnetic Resonance Imaging 3.0T (T1, T2, STIR, 3D Myelography)',
    indication: '58-year-old male with intermittent posture-related lower back stiffness. Evaluate spinal canal dimensions, neural foramina, and disc hydration.',
    technique: 'High-resolution sagittal and axial T1-weighted, T2-weighted, and short-tau inversion recovery (STIR) sequences spanning the cervical, thoracic, and lumbar spine. Neural exit foramina analyzed with high-contrast myelo-renderings.',
    findings: {
      alignment: 'Normal physiologic cervical lordosis, thoracic kyphosis, and lumbar lordosis maintained. No listhesis, spondylolysis, or pathologic compression deformity.',
      vertebralBodies: 'Preserved vertebral body height and normal bone marrow signal without occult fracture or infiltrative marrow replacement.',
      discs: 'Mild L4-L5 disc desiccation with subtle 1.8 mm broad-based disc bulge. No significant canal stenosis. L5-S1 disc height and hydration are well maintained.',
      thecalSac: 'Thecal sac and spinal cord terminate normally at conus medullaris (L1 level). Cauda equina nerve roots are free-floating without arachnoiditis.',
      foramina: 'Neuroforamina are widely patent bilaterally at all levels without focal nerve root impingement.'
    },
    impression: [
      '1. Normal spinal sagittal alignment with well-preserved vertebral body heights throughout the axis.',
      '2. Mild non-compressive L4-L5 disc desiccation without central canal stenosis or exit foraminal narrowing.',
      '3. Intact spinal cord caliber and normal signal without cord myelopathy or tethering.'
    ],
    icd10: [
      { code: 'M54.5', desc: 'Low back pain, unspecified' },
      { code: 'M51.36', desc: 'Other intervertebral disc degeneration, lumbar region' }
    ],
    recommendations: [
      'Core stabilization physical therapy focusing on transverse abdominis and multifidus strengthening.',
      'Ergonomic workstation adjustment with regular dynamic posture changes.'
    ]
  };

  const getReport = () => {
    switch (organ) {
      case 'heart': return cardiacReport;
      case 'brain': return neuroReport;
      case 'lungs': return pulmonaryReport;
      case 'kidneys': return renalReport;
      case 'liver': return hepaticReport;
      case 'spine': return spineReport;
      default: return cardiacReport;
    }
  };

  const currentReport = getReport();

  // Copy plain-text report format
  const handleCopyReport = () => {
    const text = `
AYUVA HEALTHCARE CLINICAL DIAGNOSTIC REPORT
================================================================================
EXAM: ${currentReport.examTitle}
DATE: ${reportDate} ${reportTime}
PATIENT: Alex Morgan | MRN: #AYU-9028-44 | DOB: 14-MAY-1968 | GENDER: Male
REFERRING PHYSICIAN: Dr. Sarah Jenkins, MD, FACC
PERFORMING RADIOLOGIST: Dr. Rajesh Kumar, MD, FACR

CLINICAL INDICATION:
${currentReport.indication}

EXAMINATION TECHNIQUE:
${currentReport.technique}

IMAGING FINDINGS:
${Object.entries(currentReport.findings)
  .map(([k, v]) => `• ${k.toUpperCase()}: ${v}`)
  .join('\n')}

IMPRESSION:
${currentReport.impression.join('\n')}

PRIMARY ICD-10 DIAGNOSES:
${currentReport.icd10.map((item) => `• ${item.code} - ${item.desc}`).join('\n')}

CLINICAL RECOMMENDATIONS:
${currentReport.recommendations.join('\n')}

PHYSICIAN ADDENDUM:
${physicianAddendum}

ELECTRONIC SIGNATURE:
Digitally signed by: Rajesh Kumar, MD, Department of Cardiovascular & Interventional Radiology
Authentication Hash: 0x8F92-B44E-2910-CCAA-AYUVA-VERIFIED
================================================================================
    `.trim();

    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  const handleDownloadReport = () => {
    const text = `
================================================================================
AYUVA ADVANCED MEDICAL IMAGING & RADIOLOGY
OFFICIAL STRUCTURED CLINICAL REPORT
================================================================================
PATIENT: Alex Morgan | MRN: #AYU-9028-44 | AGE: 58 | GENDER: Male
EXAM DATE: ${reportDate} ${reportTime}
PROCEDURE: ${currentReport.examTitle}
MODALITY: ${currentReport.modality}
ACCREDITATION: JCI & ACR Gold Seal of Excellence
--------------------------------------------------------------------------------
CLINICAL INDICATION:
${currentReport.indication}

TECHNIQUE:
${currentReport.technique}

IMAGING FINDINGS:
${Object.entries(currentReport.findings)
  .map(([k, v]) => `• ${k.toUpperCase()}: ${v}`)
  .join('\n')}

IMPRESSION:
${currentReport.impression.join('\n')}

PRIMARY ICD-10 DIAGNOSES:
${currentReport.icd10.map((item) => `• ${item.code} - ${item.desc}`).join('\n')}

CLINICAL RECOMMENDATIONS:
${currentReport.recommendations.join('\n')}

PHYSICIAN ADDENDUM:
${physicianAddendum}

VERIFIED ELECTRONIC SIGNATURE:
Digitally signed by: Dr. Rajesh Kumar, MD, FACR
Chief of Cardiovascular & Neuro-Interventional Radiology
License: #MD-98441-RAD | Auth Hash: 0x8F92-B44E-2910-CCAA-AYUVA-VERIFIED
Timestamp: ${new Date().toISOString()}
================================================================================
    `.trim();

    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Ayuva_Clinical_Report_${organ.toUpperCase()}_#AYU-9028-44.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setDownloaded(true);
    setTimeout(() => setDownloaded(false), 2500);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-5">
      {/* Top Banner & Control Bar */}
      <div className="p-4 rounded-2xl bg-[#080e1c] border border-emerald-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <FileText className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white tracking-tight">
                Official Clinical Diagnostic & Radiology Report
              </h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                ACR / ACC COMPLIANT
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Auto-synthesized structured clinical report containing imaging findings, AI predictive metrics, and verified physician sign-off.
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex flex-wrap items-center gap-2 shrink-0">
          {/* Format Mode Toggle */}
          <div className="flex items-center bg-[#040812] p-1 rounded-xl border border-white/10 text-xs">
            <button
              onClick={() => setReportFormat('physician')}
              className={`px-3 py-1 rounded-lg font-medium transition-all ${
                reportFormat === 'physician'
                  ? 'bg-emerald-500 text-black font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Physician Report
            </button>
            <button
              onClick={() => setReportFormat('patient')}
              className={`px-3 py-1 rounded-lg font-medium transition-all ${
                reportFormat === 'patient'
                  ? 'bg-emerald-500 text-black font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Patient Friendly
            </button>
          </div>

          <button
            onClick={handleCopyReport}
            className="px-3 py-1.5 rounded-xl bg-[#040812] border border-white/10 hover:border-white/30 text-xs font-mono text-slate-300 flex items-center gap-1.5 transition-all"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied!' : 'Copy Text'}</span>
          </button>

          <button
            onClick={handleDownloadReport}
            className="px-3 py-1.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/40 text-xs font-mono text-cyan-300 flex items-center gap-1.5 transition-all shadow-sm"
          >
            {downloaded ? <Check className="w-3.5 h-3.5 text-cyan-400" /> : <Download className="w-3.5 h-3.5" />}
            <span>{downloaded ? 'Downloaded!' : 'Download (.txt)'}</span>
          </button>

          <button
            onClick={handlePrint}
            className="px-3 py-1.5 rounded-xl bg-white text-black font-semibold text-xs flex items-center gap-1.5 hover:bg-slate-200 transition-all shadow-md"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Structured Clinical Report Paper Canvas */}
      <div className="max-w-4xl mx-auto p-6 sm:p-10 rounded-2xl bg-[#0b1222] border border-white/15 text-slate-200 shadow-2xl space-y-6 font-sans">
        {/* Hospital & Institutional Header */}
        <div className="border-b-2 border-white/20 pb-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white font-black text-xl shadow-lg">
              AY
            </div>
            <div>
              <h1 className="text-xl font-extrabold tracking-tight text-white">
                AYUVA ADVANCED MEDICAL IMAGING & RADIOLOGY
              </h1>
              <div className="text-xs font-mono text-cyan-400 mt-0.5">
                DEPARTMENT OF CARDIOVASCULAR & NEURO-INTERVENTIONAL MEDICINE
              </div>
            </div>
          </div>
          <div className="text-right text-xs font-mono text-slate-400">
            <div>ACCREDITATION: JCI & ACR GOLD SEAL</div>
            <div>REPORT ID: #REP-2026-9048-X</div>
            <div className="text-emerald-400 font-bold">STATUS: FINAL VERIFIED</div>
          </div>
        </div>

        {/* Patient Demographics Banner */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-4 rounded-xl bg-[#060a14] border border-white/10 text-xs font-mono">
          <div>
            <span className="text-slate-500 block text-[10px]">PATIENT NAME</span>
            <span className="text-white font-bold">Alex Morgan</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px]">MRN / PATIENT ID</span>
            <span className="text-white font-bold">#AYU-9028-44</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px]">AGE / GENDER</span>
            <span className="text-white font-bold">58 Yrs / Male</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[10px]">EXAM DATE & TIME</span>
            <span className="text-white font-bold">{reportDate} {reportTime}</span>
          </div>
        </div>

        {/* Exam Title & Modality */}
        <div className="p-3.5 rounded-xl bg-cyan-950/20 border border-cyan-500/30">
          <div className="text-[10px] font-mono text-cyan-400 uppercase">PROCEDURE PERFORMED</div>
          <h2 className="text-base font-bold text-white mt-0.5">
            {currentReport.examTitle}
          </h2>
          <div className="text-xs text-slate-400 mt-1">
            <strong>Modality:</strong> {currentReport.modality}
          </div>
        </div>

        {reportFormat === 'physician' ? (
          /* =========================================================
             PHYSICIAN TECHNICAL FORMAT
             ========================================================= */
          <div className="space-y-6 text-sm">
            {/* Indication */}
            <div className="space-y-1">
              <h3 className="text-xs font-bold uppercase tracking-wider text-cyan-400 font-mono">
                CLINICAL INDICATION & HISTORY
              </h3>
              <p className="text-slate-300 leading-relaxed bg-[#060a14] p-3 rounded-xl border border-white/5">
                {currentReport.indication}
              </p>
            </div>

            {/* Technique */}
            <div className="space-y-1">
              <h3 className="text-xs font-bold uppercase tracking-wider text-cyan-400 font-mono">
                EXAMINATION TECHNIQUE & PROTOCOL
              </h3>
              <p className="text-slate-400 text-xs leading-relaxed bg-[#060a14] p-3 rounded-xl border border-white/5">
                {currentReport.technique}
              </p>
            </div>

            {/* Detailed Findings */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-cyan-400 font-mono">
                DETAILED IMAGING FINDINGS
              </h3>
              <div className="p-4 rounded-xl bg-[#060a14] border border-white/5 space-y-3">
                {Object.entries(currentReport.findings).map(([key, val]) => (
                  <div key={key} className="text-xs">
                    <span className="font-bold text-white uppercase font-mono mr-2">
                      {key.replace(/([A-Z])/g, ' $1')}:
                    </span>
                    <span className="text-slate-300 leading-relaxed">{val}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Impression (Crucial Summary) */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-purple-400 font-mono flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                IMPRESSION & QUANTITATIVE SYNTHESIS
              </h3>
              <div className="p-4 rounded-xl bg-purple-950/20 border border-purple-500/30 space-y-2">
                {currentReport.impression.map((imp, idx) => (
                  <div key={idx} className="text-xs font-medium text-purple-200 leading-relaxed">
                    {imp}
                  </div>
                ))}
              </div>
            </div>

            {/* ICD-10 Diagnostic Codes */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-amber-400 font-mono">
                PRIMARY ICD-10-CM BILLING & DIAGNOSIS CODES
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {currentReport.icd10.map((codeItem) => (
                  <div
                    key={codeItem.code}
                    className="p-2.5 rounded-xl bg-[#060a14] border border-white/5 flex items-start gap-2.5"
                  >
                    <span className="px-2 py-0.5 rounded font-mono text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 shrink-0">
                      {codeItem.code}
                    </span>
                    <span className="text-xs text-slate-300 leading-snug">{codeItem.desc}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Recommendations */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-400 font-mono flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5" />
                EVIDENCE-BASED CARE PLAN & RECOMMENDATIONS
              </h3>
              <div className="p-4 rounded-xl bg-emerald-950/20 border border-emerald-500/30 space-y-2">
                {currentReport.recommendations.map((rec, idx) => (
                  <div key={idx} className="text-xs text-emerald-200 flex items-start gap-2">
                    <span className="text-emerald-400 font-bold">•</span>
                    <span>{rec}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Customizable Attending Addendum */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
                  <Edit3 className="w-3.5 h-3.5 text-cyan-400" />
                  PHYSICIAN ADDENDUM & DIRECT ORDERS
                </h3>
                <button
                  onClick={() => setIsEditingAddendum(!isEditingAddendum)}
                  className="text-xs font-mono text-cyan-400 hover:underline"
                >
                  {isEditingAddendum ? 'Done Editing' : 'Edit Addendum'}
                </button>
              </div>
              {isEditingAddendum ? (
                <textarea
                  value={physicianAddendum}
                  onChange={(e) => setPhysicianAddendum(e.target.value)}
                  className="w-full p-3 rounded-xl bg-[#060a14] border border-cyan-500/40 text-xs text-white focus:outline-none focus:ring-1 focus:ring-cyan-400 min-h-[70px]"
                />
              ) : (
                <p className="text-xs text-slate-300 bg-[#060a14] p-3 rounded-xl border border-white/5 italic">
                  "{physicianAddendum}"
                </p>
              )}
            </div>
          </div>
        ) : (
          /* =========================================================
             PATIENT FRIENDLY SUMMARY FORMAT
             ========================================================= */
          <div className="space-y-6 text-sm">
            <div className="p-4 rounded-2xl bg-cyan-950/30 border border-cyan-500/40 space-y-2">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Heart className="w-5 h-5 text-cyan-400" />
                Plain-Language Overview for Alex
              </h3>
              <p className="text-slate-300 text-xs leading-relaxed">
                {organ === 'heart'
                  ? 'Your heart scan identified a 68% narrowing in the main artery supplying blood to the front of your heart (the LAD artery). This narrowing is causing reduced blood flow (ischemia) when you exert yourself, explaining your recent chest tightness. Your heart muscle pump strength remains good at 56%.'
                  : 'Your brain scan detected an area of reduced blood flow in the left hemisphere of your brain that happened 3 hours ago. Because you arrived at the hospital quickly, the large majority of brain cells in this zone are still salvageable with rapid medical treatment to dissolve or remove the blockage.'}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl bg-[#060a14] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-emerald-400 uppercase">GOOD NEWS</span>
                <div className="text-sm font-bold text-white">
                  {organ === 'heart' ? 'Healthy Heart Muscle Pumping' : 'Over 70% Brain Tissue is Salvageable'}
                </div>
                <p className="text-xs text-slate-400">
                  {organ === 'heart'
                    ? 'No permanent heart muscle scarring was found. Pumping function is preserved.'
                    : 'The core stroke area is small, meaning rapid therapy can prevent permanent impairment.'}
                </p>
              </div>

              <div className="p-4 rounded-2xl bg-[#060a14] border border-white/10 space-y-1">
                <span className="text-[10px] font-mono text-amber-400 uppercase">NEXT TREATMENT STEP</span>
                <div className="text-sm font-bold text-white">
                  {organ === 'heart' ? 'Coronary Stenting (PCI)' : 'Clot Dissolving & Thrombectomy'}
                </div>
                <p className="text-xs text-slate-400">
                  {organ === 'heart'
                    ? 'Your doctor will open the narrowed artery with a tiny mesh tube (stent).'
                    : 'The stroke team is administering targeted medications to restore brain blood flow.'}
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Digital Signature Footer & Attestation */}
        <div className="pt-6 border-t border-white/15 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs font-mono">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsSigned(!isSigned)}
              className={`w-10 h-10 rounded-xl flex items-center justify-center transition-all ${
                isSigned
                  ? 'bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 hover:bg-emerald-500/30'
                  : 'bg-amber-500/20 border border-amber-500/40 text-amber-400 hover:bg-amber-500/30'
              }`}
              title="Click to sign or un-sign report"
            >
              {isSigned ? <ShieldCheck className="w-5 h-5" /> : <Edit3 className="w-5 h-5" />}
            </button>
            <div>
              <div className="font-bold text-white flex items-center gap-2">
                <span>Dr. Rajesh Kumar, MD, FACR</span>
                <span
                  className={`px-1.5 py-0.5 rounded text-[9px] font-mono ${
                    isSigned
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  }`}
                >
                  {isSigned ? 'SIGNED & ATTESTED' : 'PENDING SIGNATURE'}
                </span>
              </div>
              <div className="text-slate-400 text-[11px]">Chief of Cardiovascular & Neuro-Radiology</div>
              <div className={isSigned ? 'text-emerald-400 text-[10px]' : 'text-amber-400 text-[10px]'}>
                {isSigned
                  ? 'VERIFIED ELECTRONIC SIGNATURE [SHA-256]'
                  : 'CLICK ICON TO ATTEST AND APPLY SIGNATURE'}
              </div>
            </div>
          </div>
          <div className="text-right text-[11px] text-slate-500">
            <div>LICENSE: #MD-98441-RAD</div>
            <div>SIG HASH: {isSigned ? '0x8F92...CCAA' : '[AWAITING SIGNATURE]'}</div>
          </div>
        </div>
      </div>
    </div>
  );
};
