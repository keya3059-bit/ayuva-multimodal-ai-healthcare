import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Maximize2,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Ruler,
  Crosshair,
  Sliders,
  Layers,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  Eye,
  Info,
  Activity,
  Contrast,
  Sun,
  ShieldCheck,
  FileText,
  Check,
  Share2
} from 'lucide-react';
import { OrganType } from './Anatomical3DViewer';

// High-resolution radiological assets
import brainMriImg from '../../assets/images/brain_mri_analysis_1789617764034.jpg';
import cardiacAngioImg from '../../assets/images/cardiac_ct_angiogram_1789617779210.jpg';
import brainSagittalImg from '../../assets/images/brain_neural_lobes_1789616973656.jpg';
import heartChambersImg from '../../assets/images/heart_chambers_valves_1789616961173.jpg';
import lungs3DImg from '../../assets/images/medical_lungs_detail_1789645373964.jpg';
import kidney3DImg from '../../assets/images/medical_kidney_detail_1789645387170.jpg';
import liver3DImg from '../../assets/images/medical_liver_detail_1789645402871.jpg';
import spine3DImg from '../../assets/images/medical_spine_detail_1789645414923.jpg';

interface ImageAnalysisViewerProps {
  organ: OrganType;
  onOpenReport?: () => void;
  onOpenPredictor?: () => void;
}

type WindowPreset = 'default' | 'angio' | 'soft-tissue' | 'brain' | 'bone';
type ColorLUT = 'gray' | 'hot-iron' | 'rainbow-pet' | 'invert';
type ActiveTool = 'none' | 'caliper' | 'density-probe' | 'roi-box';

interface Measurement {
  id: string;
  x1: number;
  y1: number;
  x2: number;
  y2: number;
  distanceMm: number;
  label: string;
}

interface AnomalyROI {
  id: string;
  title: string;
  category: 'Critical' | 'Moderate' | 'Normal';
  xPercent: number;
  yPercent: number;
  widthPercent: number;
  heightPercent: number;
  finding: string;
  metric: string;
  recommendation: string;
}

export const ImageAnalysisViewer: React.FC<ImageAnalysisViewerProps> = ({
  organ,
  onOpenReport,
  onOpenPredictor,
}) => {
  // Viewer Display Controls
  const [activePreset, setActivePreset] = useState<WindowPreset>('default');
  const [colorLut, setColorLut] = useState<ColorLUT>('gray');
  const [activeTool, setActiveTool] = useState<ActiveTool>('none');
  const [brightness, setBrightness] = useState<number>(100);
  const [contrast, setContrast] = useState<number>(100);
  const [zoom, setZoom] = useState<number>(1.0);
  const [showAnomalies, setShowAnomalies] = useState<boolean>(true);
  const [showGridHUD, setShowGridHUD] = useState<boolean>(true);
  const [selectedAnomalyId, setSelectedAnomalyId] = useState<string | null>(null);

  // Selected scan modality
  const [scanType, setScanType] = useState<'primary-scan' | 'secondary-slice'>('primary-scan');
  const [exportedFinding, setExportedFinding] = useState<boolean>(false);

  // Caliper Measurement State
  const [measurements, setMeasurements] = useState<Measurement[]>([]);
  const [caliperStart, setCaliperStart] = useState<{ x: number; y: number } | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Density Probe State (Simulated Hounsfield Units)
  const [probeData, setProbeData] = useState<{ x: number; y: number; hu: number; tissue: string } | null>(null);

  const getActiveImage = () => {
    switch (organ) {
      case 'heart':
        return scanType === 'primary-scan' ? cardiacAngioImg : heartChambersImg;
      case 'brain':
        return scanType === 'primary-scan' ? brainMriImg : brainSagittalImg;
      case 'lungs':
        return lungs3DImg;
      case 'kidneys':
        return kidney3DImg;
      case 'liver':
        return liver3DImg;
      case 'spine':
        return spine3DImg;
      default:
        return cardiacAngioImg;
    }
  };

  const activeImage = getActiveImage();

  // Detected Clinical Anomalies for Heart & Brain
  const heartAnomalies: AnomalyROI[] = [
    {
      id: 'lad-stenosis',
      title: 'Mid-LAD Calcified Atheromatous Plaque',
      category: 'Critical',
      xPercent: 44,
      yPercent: 42,
      widthPercent: 22,
      heightPercent: 18,
      finding: 'Focal 68% luminal diameter reduction in the mid-left anterior descending artery with dense calcified cap.',
      metric: 'LAD Stenosis: 68% | FFR: 0.74',
      recommendation: 'Urgent cardiac cath lab evaluation for PCI with Drug-Eluting Stent (DES).'
    },
    {
      id: 'aortic-root',
      title: 'Ascending Aorta Ectasia',
      category: 'Moderate',
      xPercent: 40,
      yPercent: 14,
      widthPercent: 25,
      heightPercent: 20,
      finding: 'Ascending thoracic aortic root measured at 38.6 mm (mild upper limit dilation, no acute dissection flap).',
      metric: 'Aortic Caliber: 38.6 mm',
      recommendation: 'Annual serial echocardiography / CT follow-up; strict blood pressure optimization.'
    },
    {
      id: 'lv-myocardium',
      title: 'LV Antero-Apical Wall Hypokinesis',
      category: 'Moderate',
      xPercent: 52,
      yPercent: 62,
      widthPercent: 28,
      heightPercent: 22,
      finding: 'Subendocardial perfusion attenuation matching LAD myocardial territory with preserved global EF (56%).',
      metric: 'LVEF: 56% | Regional Strain: -12.4%',
      recommendation: 'Cardioprotective medical management with beta-blockers and high-intensity statin.'
    }
  ];

  const brainAnomalies: AnomalyROI[] = [
    {
      id: 'mca-ischemia',
      title: 'Left MCA M1/M2 Segment Hypoperfusion',
      category: 'Critical',
      xPercent: 48,
      yPercent: 38,
      widthPercent: 26,
      heightPercent: 22,
      finding: 'Tmax > 6s delay involving 48.2 mL of left temporoparietal cortex consistent with ischemic penumbra.',
      metric: 'Penumbra Volume: 48.2 mL | Tmax > 6s',
      recommendation: 'Evaluate immediately for Endovascular Thrombectomy (EVT); DEFUSE-3 criteria positive.'
    },
    {
      id: 'infarct-core',
      title: 'Restricted Diffusion Infarct Core',
      category: 'Critical',
      xPercent: 45,
      yPercent: 44,
      widthPercent: 18,
      heightPercent: 16,
      finding: 'High DWI signal with corresponding ADC hypointensity (low ADC values < 620 x 10^-6 mm²/s) measuring 16.4 mL.',
      metric: 'Infarct Core: 16.4 mL | ASPECTS: 8/10',
      recommendation: 'Candidate for neuroprotective hemodynamics and neuro-ICU continuous monitoring.'
    },
    {
      id: 'ventricle-asymmetry',
      title: 'Ventricular Frontal Horn Symmetry',
      category: 'Normal',
      xPercent: 42,
      yPercent: 28,
      widthPercent: 20,
      heightPercent: 16,
      finding: 'Normal lateral ventricles without midline shift or acute subfalcine herniation.',
      metric: 'Midline Shift: 0.0 mm (Nil)',
      recommendation: 'Serial repeat scan at 24 hours to confirm stable mass effect.'
    }
  ];

  const lungsAnomalies: AnomalyROI[] = [
    {
      id: 'apical-parenchyma',
      title: 'Right Upper Lobe Subpleural Reticulation',
      category: 'Moderate',
      xPercent: 46,
      yPercent: 28,
      widthPercent: 22,
      heightPercent: 18,
      finding: 'Minimal dependent subpleural reticular density with preserved baseline alveolar architecture and no honeycombing.',
      metric: 'Parenchymal Attenuation: -860 HU',
      recommendation: 'Follow-up volumetric HRCT at 12 months; avoid respiratory irritants.'
    },
    {
      id: 'bronchial-patency',
      title: 'Tracheobronchial Caliber Symmetry',
      category: 'Normal',
      xPercent: 42,
      yPercent: 44,
      widthPercent: 24,
      heightPercent: 18,
      finding: 'Patent lobar and segmental bronchial lumen without wall thickening or luminal impaction.',
      metric: 'Airway Ratio: 0.82 (Normal)',
      recommendation: 'Preserve healthy respiratory hygiene and routine clinical monitoring.'
    }
  ];

  const kidneysAnomalies: AnomalyROI[] = [
    {
      id: 'cortex-perfusion',
      title: 'Bilateral Renal Cortical Homogeneity',
      category: 'Normal',
      xPercent: 40,
      yPercent: 36,
      widthPercent: 24,
      heightPercent: 20,
      finding: 'Intact symmetric corticomedullary differentiation without focal polar defect, cortical scarring, or cyst.',
      metric: 'Cortical Thickness: 1.8 cm | RI: 0.62',
      recommendation: 'Preserve adequate hydration and routine metabolic panels.'
    },
    {
      id: 'collecting-system',
      title: 'Pelvicalyceal Junction Unobstructed',
      category: 'Normal',
      xPercent: 45,
      yPercent: 50,
      widthPercent: 20,
      heightPercent: 18,
      finding: 'Prompt symmetric excretory opacification without caliceal blunting, calculus, or hydronephrotic dilation.',
      metric: 'Pelvis AP Diameter: 4.8 mm',
      recommendation: 'Annual urinalysis and microalbumin check.'
    }
  ];

  const liverAnomalies: AnomalyROI[] = [
    {
      id: 'portal-inflow',
      title: 'Main Portal Vein Hepatopetal Hemodynamics',
      category: 'Normal',
      xPercent: 44,
      yPercent: 40,
      widthPercent: 24,
      heightPercent: 20,
      finding: 'Smooth uniform portal vein contour with brisk hepatopetal flow velocity without periportal edema.',
      metric: 'Portal Velocity: 24.2 cm/s | RI: 0.66',
      recommendation: 'Maintain regular metabolic lifestyle and hepatic enzyme checks.'
    },
    {
      id: 'hepatic-parenchyma',
      title: 'Couinaud Segments Homogeneous Attenuation',
      category: 'Normal',
      xPercent: 38,
      yPercent: 30,
      widthPercent: 28,
      heightPercent: 24,
      finding: 'Liver parenchyma displays uniform acoustic density and attenuation without focal architectural distortion.',
      metric: 'Liver Stiffness: 2.3 kPa (F0)',
      recommendation: 'Annual metabolic checkup.'
    }
  ];

  const spineAnomalies: AnomalyROI[] = [
    {
      id: 'l4-l5-disc',
      title: 'L4-L5 Mild Broad-Based Disc Desiccation',
      category: 'Moderate',
      xPercent: 44,
      yPercent: 54,
      widthPercent: 22,
      heightPercent: 16,
      finding: 'Minimal T2 disc signal loss with 1.8 mm broad-based disc bulge without significant central spinal stenosis.',
      metric: 'Thecal Sac AP Diameter: 12.4 mm',
      recommendation: 'Core muscular conditioning and posture stabilization therapy.'
    },
    {
      id: 'canal-patency',
      title: 'Spinal Canal & Neural Foramina Alignment',
      category: 'Normal',
      xPercent: 42,
      yPercent: 32,
      widthPercent: 24,
      heightPercent: 20,
      finding: 'Intact canal diameter throughout cervical and thoracic segments with free-floating cauda equina roots.',
      metric: 'Canal Area: 184 mm² (Spacious)',
      recommendation: 'Routine ergonomic health maintenance.'
    }
  ];

  const getActiveAnomalies = (): AnomalyROI[] => {
    switch (organ) {
      case 'heart': return heartAnomalies;
      case 'brain': return brainAnomalies;
      case 'lungs': return lungsAnomalies;
      case 'kidneys': return kidneysAnomalies;
      case 'liver': return liverAnomalies;
      case 'spine': return spineAnomalies;
      default: return heartAnomalies;
    }
  };

  const activeAnomalies = getActiveAnomalies();
  const currentSelectedAnomaly = activeAnomalies.find((a) => a.id === selectedAnomalyId) || activeAnomalies[0];

  // Preset Filters CSS Style
  const getFilterStyle = (): React.CSSProperties => {
    let filterString = `brightness(${brightness}%) contrast(${contrast}%)`;

    if (activePreset === 'angio') {
      filterString += ' contrast(165%) brightness(115%)';
    } else if (activePreset === 'soft-tissue') {
      filterString += ' contrast(125%) brightness(95%) saturate(120%)';
    } else if (activePreset === 'brain') {
      filterString += ' contrast(145%) brightness(105%)';
    } else if (activePreset === 'bone') {
      filterString += ' contrast(220%) brightness(85%) grayscale(100%)';
    }

    if (colorLut === 'hot-iron') {
      filterString += ' sepia(100%) hue-rotate(330deg) saturate(280%)';
    } else if (colorLut === 'rainbow-pet') {
      filterString += ' hue-rotate(180deg) saturate(300%) contrast(130%)';
    } else if (colorLut === 'invert') {
      filterString += ' invert(100%)';
    }

    return { filter: filterString };
  };

  // Canvas Click / Mouse Handling for Caliper & Density Probe
  const handleStageClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    if (activeTool === 'caliper') {
      if (!caliperStart) {
        setCaliperStart({ x, y });
      } else {
        // Calculate physical millimeters (approx calibrated: 100% width ~ 140mm for heart, 180mm for brain)
        const scaleMm = organ === 'heart' ? 1.4 : 1.8;
        const dx = (x - caliperStart.x) * scaleMm;
        const dy = (y - caliperStart.y) * scaleMm;
        const distance = Math.sqrt(dx * dx + dy * dy);

        const newMeasurement: Measurement = {
          id: `meas-${Date.now()}`,
          x1: caliperStart.x,
          y1: caliperStart.y,
          x2: x,
          y2: y,
          distanceMm: parseFloat(distance.toFixed(1)),
          label: `${distance.toFixed(1)} mm`
        };

        setMeasurements((prev) => [...prev.slice(-3), newMeasurement]);
        setCaliperStart(null);
      }
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (activeTool !== 'density-probe' || !containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;

    // Simulate Tissue Density in Hounsfield Units (HU) based on spatial coordinates and organ
    let hu = 0;
    let tissue = 'Air / Artifact (-1000 HU)';

    if (organ === 'heart') {
      if (y > 35 && y < 55 && x > 40 && x < 55) {
        hu = 840 + Math.floor(Math.random() * 80);
        tissue = 'Dense Calcified Plaque (Dense HU)';
      } else if (x > 30 && x < 70 && y > 25 && y < 75) {
        hu = 45 + Math.floor(Math.random() * 15);
        tissue = 'Myocardial Muscle (+45 HU)';
      } else if (y < 25 && x > 35 && x < 65) {
        hu = 220 + Math.floor(Math.random() * 40);
        tissue = 'Iodinated Contrast in Aorta (+240 HU)';
      } else {
        hu = -700 + Math.floor(Math.random() * 50);
        tissue = 'Lung Parenchyma (-700 HU)';
      }
    } else {
      if (x > 40 && x < 52 && y > 40 && y < 50) {
        hu = 22 + Math.floor(Math.random() * 6);
        tissue = 'Acute Ischemic Cytotoxic Edema (+22 HU)';
      } else if (x > 35 && x < 65 && y > 25 && y < 75) {
        hu = 38 + Math.floor(Math.random() * 8);
        tissue = 'Cerebral Cortex Grey Matter (+38 HU)';
      } else if (x > 45 && x < 55 && y > 35 && y < 55) {
        hu = 8 + Math.floor(Math.random() * 4);
        tissue = 'Cerebrospinal Fluid (CSF +8 HU)';
      } else {
        hu = 950 + Math.floor(Math.random() * 100);
        tissue = 'Cranial Bone Calvarium (+950 HU)';
      }
    }

    setProbeData({ x, y, hu, tissue });
  };

  const clearMeasurements = () => {
    setMeasurements([]);
    setCaliperStart(null);
  };

  return (
    <div className="space-y-5">
      {/* Top Banner Toolbar */}
      <div className="p-4 rounded-2xl bg-[#080e1c] border border-cyan-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Crosshair className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white tracking-tight">
                {organ === 'heart'
                  ? 'Coronary CT Angiography & Hemodynamic Analysis'
                  : 'Diagnostic Brain MRI & Neuro-Perfusion Analysis'}
              </h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                DICOM 3.0 / PACS READY
              </span>
            </div>
            <p className="text-xs text-slate-400">
              High-resolution radiologic analysis with calibrated calipers, Hounsfield Unit density probe, and AI lesion segmentations.
            </p>
          </div>
        </div>

        {/* Action Shortcuts to Predictor & Report */}
        <div className="flex items-center gap-2 shrink-0">
          {onOpenPredictor && (
            <button
              onClick={onOpenPredictor}
              className="px-3 py-1.5 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/40 text-xs font-semibold flex items-center gap-1.5 transition-all"
            >
              <Activity className="w-3.5 h-3.5 text-purple-400" />
              <span>Predictive Risk Engine</span>
            </button>
          )}
          {onOpenReport && (
            <button
              onClick={onOpenReport}
              className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-semibold flex items-center gap-1.5 transition-all"
            >
              <FileText className="w-3.5 h-3.5 text-emerald-400" />
              <span>Generate Diagnostic Report</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Analysis Workspace */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-5">
        {/* LEFT / CENTER: Interactive Imaging Viewport (8 Columns) */}
        <div className="xl:col-span-8 space-y-4">
          <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-3">
            {/* Viewport Header Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 text-xs border-b border-white/10 pb-3">
              {/* Scan Modality Toggle */}
              <div className="flex items-center gap-1 bg-[#040812] p-1 rounded-xl border border-white/10">
                <button
                  onClick={() => setScanType('primary-scan')}
                  className={`px-3 py-1 rounded-lg font-medium transition-all ${
                    scanType === 'primary-scan'
                      ? 'bg-cyan-500 text-black font-bold shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {organ === 'heart' ? 'CT Angiogram 3D Volume' : 'Axial Diffusion MRI (DWI)'}
                </button>
                <button
                  onClick={() => setScanType('secondary-slice')}
                  className={`px-3 py-1 rounded-lg font-medium transition-all ${
                    scanType === 'secondary-slice'
                      ? 'bg-cyan-500 text-black font-bold shadow-sm'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {organ === 'heart' ? 'Internal Four-Chamber Cut' : 'Sagittal Midline Cut'}
                </button>
              </div>

              {/* Active Medical Measurement Tools */}
              <div className="flex items-center gap-1.5">
                <span className="text-[11px] font-mono text-slate-400 mr-1 hidden sm:inline">TOOL:</span>
                <button
                  onClick={() => {
                    setActiveTool(activeTool === 'caliper' ? 'none' : 'caliper');
                    setCaliperStart(null);
                  }}
                  className={`px-2.5 py-1 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-all ${
                    activeTool === 'caliper'
                      ? 'bg-amber-500 text-black border-amber-400 font-bold'
                      : 'bg-[#040812] text-slate-300 border-white/10 hover:border-white/30'
                  }`}
                  title="Measure lumen diameter or lesion size in mm"
                >
                  <Ruler className="w-3.5 h-3.5" />
                  <span>Caliper (mm)</span>
                </button>

                <button
                  onClick={() => setActiveTool(activeTool === 'density-probe' ? 'none' : 'density-probe')}
                  className={`px-2.5 py-1 rounded-lg border text-xs font-semibold flex items-center gap-1.5 transition-all ${
                    activeTool === 'density-probe'
                      ? 'bg-cyan-400 text-black border-cyan-300 font-bold'
                      : 'bg-[#040812] text-slate-300 border-white/10 hover:border-white/30'
                  }`}
                  title="Inspect tissue Hounsfield Units"
                >
                  <Crosshair className="w-3.5 h-3.5" />
                  <span>HU Density Probe</span>
                </button>

                {measurements.length > 0 && (
                  <button
                    onClick={clearMeasurements}
                    className="px-2 py-1 rounded-lg text-[11px] text-slate-400 hover:text-rose-400 bg-[#040812] border border-white/10"
                    title="Clear measurements"
                  >
                    Clear Calipers
                  </button>
                )}
              </div>
            </div>

            {/* Medical Imaging Stage (DICOM Canvas Style) */}
            <div
              ref={containerRef}
              onClick={handleStageClick}
              onMouseMove={handleMouseMove}
              className="relative w-full aspect-[4/3] rounded-xl overflow-hidden bg-black border border-white/15 select-none cursor-crosshair flex items-center justify-center shadow-2xl"
            >
              {/* Image Container with Zoom & Filter applied */}
              <div
                className="relative w-full h-full transition-transform duration-200 ease-out flex items-center justify-center"
                style={{
                  transform: `scale(${zoom})`,
                  ...getFilterStyle()
                }}
              >
                <img
                  src={activeImage}
                  alt="Medical scan analysis"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover pointer-events-none"
                />
              </div>

              {/* DICOM HUD Header Information Overlay */}
              {showGridHUD && (
                <div className="absolute inset-0 pointer-events-none p-3 flex flex-col justify-between text-[11px] font-mono text-cyan-300/80 z-20">
                  <div className="flex justify-between">
                    <div>
                      <div>HOSP: AYUVA ADVANCED RADIOLOGY</div>
                      <div>ID: #AYU-9028-44 // MORGAN, A.</div>
                      <div>MODALITY: {organ === 'heart' ? 'CT-ANGIO (256-SLICE)' : 'MRI 3.0T (DIFFUSION)'}</div>
                    </div>
                    <div className="text-right">
                      <div>WL: {activePreset.toUpperCase()}</div>
                      <div>LUT: {colorLut.toUpperCase()}</div>
                      <div>ZOOM: {Math.round(zoom * 100)}%</div>
                    </div>
                  </div>

                  <div className="flex justify-between items-end">
                    <div>
                      <div>KVP: 120 // MA: 320</div>
                      <div>SLICE THK: 0.625 mm</div>
                      <div>FOV: {organ === 'heart' ? '220 mm' : '240 mm'}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-emerald-400">CALIBRATION: 1.0 px = 0.28 mm</div>
                      <div>MATRIX: 512 x 512 DICOM</div>
                    </div>
                  </div>
                </div>
              )}

              {/* Subdued HUD Crosshair Calibration Grid */}
              {showGridHUD && (
                <div className="absolute inset-0 pointer-events-none opacity-25 bg-[radial-gradient(circle_at_center,#00e5ff18_0%,transparent_70%)]" />
              )}

              {/* AI Anomaly Detection Bounding Boxes & Tags */}
              {showAnomalies &&
                activeAnomalies.map((anomaly) => {
                  const isSelected = anomaly.id === selectedAnomalyId;
                  const borderColor =
                    anomaly.category === 'Critical'
                      ? 'border-rose-500 bg-rose-500/10 text-rose-300'
                      : anomaly.category === 'Moderate'
                      ? 'border-amber-500 bg-amber-500/10 text-amber-300'
                      : 'border-emerald-500 bg-emerald-500/10 text-emerald-300';

                  return (
                    <div
                      key={anomaly.id}
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedAnomalyId(anomaly.id);
                      }}
                      className={`absolute rounded-lg border-2 cursor-pointer transition-all z-20 ${borderColor} ${
                        isSelected ? 'ring-4 ring-white/30 scale-105' : 'hover:scale-105'
                      }`}
                      style={{
                        left: `${anomaly.xPercent}%`,
                        top: `${anomaly.yPercent}%`,
                        width: `${anomaly.widthPercent}%`,
                        height: `${anomaly.heightPercent}%`
                      }}
                    >
                      {/* Label badge */}
                      <div className="absolute -top-3.5 left-2 px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-[#040812] border border-white/20 whitespace-nowrap shadow-md">
                        {anomaly.title}
                      </div>

                      {/* Small Pulsing Target Point */}
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-white/20 border border-white flex items-center justify-center">
                        <div className="w-1 h-1 rounded-full bg-white animate-ping" />
                      </div>
                    </div>
                  );
                })}

              {/* Drawn Caliper Lines */}
              {measurements.map((m) => (
                <svg
                  key={m.id}
                  className="absolute inset-0 w-full h-full pointer-events-none z-30"
                >
                  <line
                    x1={`${m.x1}%`}
                    y1={`${m.y1}%`}
                    x2={`${m.x2}%`}
                    y2={`${m.y2}%`}
                    stroke="#f59e0b"
                    strokeWidth="2.5"
                    strokeDasharray="4 2"
                  />
                  <circle cx={`${m.x1}%`} cy={`${m.y1}%`} r="4" fill="#f59e0b" />
                  <circle cx={`${m.x2}%`} cy={`${m.y2}%`} r="4" fill="#f59e0b" />
                  <rect
                    x={`${(m.x1 + m.x2) / 2 - 4}%`}
                    y={`${(m.y1 + m.y2) / 2 - 2}%`}
                    width="44"
                    height="18"
                    rx="4"
                    fill="#040812"
                    stroke="#f59e0b"
                  />
                  <text
                    x={`${(m.x1 + m.x2) / 2}%`}
                    y={`${(m.y1 + m.y2) / 2 + 1.2}%`}
                    fill="#f59e0b"
                    fontSize="11"
                    fontFamily="monospace"
                    fontWeight="bold"
                    textAnchor="middle"
                  >
                    {m.label}
                  </text>
                </svg>
              ))}

              {/* Caliper In-Progress Anchor */}
              {caliperStart && (
                <div
                  className="absolute w-3 h-3 rounded-full bg-amber-400 ring-4 ring-amber-400/40 -translate-x-1/2 -translate-y-1/2 z-30 pointer-events-none"
                  style={{ left: `${caliperStart.x}%`, top: `${caliperStart.y}%` }}
                />
              )}

              {/* Real-Time Density Probe Cursor Display */}
              {activeTool === 'density-probe' && probeData && (
                <div
                  className="absolute pointer-events-none bg-[#040812]/95 border border-cyan-400 p-2 rounded-xl text-xs font-mono shadow-2xl z-40 -translate-x-1/2 -translate-y-full -mt-3"
                  style={{ left: `${probeData.x}%`, top: `${probeData.y}%` }}
                >
                  <div className="text-[10px] text-slate-400 flex items-center gap-1">
                    <Crosshair className="w-3 h-3 text-cyan-400" />
                    HOUNSFIELD PROBE
                  </div>
                  <div className="text-white font-bold text-sm">
                    {probeData.hu > 0 ? `+${probeData.hu}` : probeData.hu} HU
                  </div>
                  <div className="text-[10px] text-cyan-300">{probeData.tissue}</div>
                </div>
              )}
            </div>

            {/* Viewport Bottom Controls: Window Presets, LUTs, Zoom */}
            <div className="pt-2 border-t border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs">
              {/* Window Presets */}
              <div className="flex items-center gap-1.5">
                <span className="text-slate-400 font-mono text-[11px]">WINDOW:</span>
                {[
                  { id: 'default', label: 'Default' },
                  { id: 'angio', label: 'Angio Contrast' },
                  { id: 'soft-tissue', label: 'Soft Tissue' },
                  { id: 'brain', label: 'Neuro Window' },
                  { id: 'bone', label: 'Bone / Plaque' }
                ].map((preset) => (
                  <button
                    key={preset.id}
                    onClick={() => setActivePreset(preset.id as WindowPreset)}
                    className={`px-2 py-1 rounded text-[11px] font-mono transition-all ${
                      activePreset === preset.id
                        ? 'bg-white text-black font-bold'
                        : 'bg-[#040812] text-slate-400 hover:text-white border border-white/5'
                    }`}
                  >
                    {preset.label}
                  </button>
                ))}
              </div>

              {/* Color LUTs */}
              <div className="flex items-center gap-1.5">
                <span className="text-slate-400 font-mono text-[11px]">LUT:</span>
                {[
                  { id: 'gray', label: 'DICOM Gray' },
                  { id: 'hot-iron', label: 'Hot Iron' },
                  { id: 'rainbow-pet', label: 'Rainbow' },
                  { id: 'invert', label: 'Inverted' }
                ].map((lut) => (
                  <button
                    key={lut.id}
                    onClick={() => setColorLut(lut.id as ColorLUT)}
                    className={`px-2 py-1 rounded text-[11px] font-mono transition-all ${
                      colorLut === lut.id
                        ? 'bg-cyan-500 text-black font-bold'
                        : 'bg-[#040812] text-slate-400 hover:text-white border border-white/5'
                    }`}
                  >
                    {lut.label}
                  </button>
                ))}
              </div>

              {/* Zoom & Overlay Toggles */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowAnomalies(!showAnomalies)}
                  className={`px-2.5 py-1 rounded text-xs font-mono flex items-center gap-1 ${
                    showAnomalies
                      ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
                      : 'bg-[#040812] text-slate-400 border border-white/10'
                  }`}
                >
                  <AlertTriangle className="w-3 h-3" />
                  AI Lesions
                </button>
                <button
                  onClick={() => setShowGridHUD(!showGridHUD)}
                  className={`px-2.5 py-1 rounded text-xs font-mono flex items-center gap-1 ${
                    showGridHUD
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                      : 'bg-[#040812] text-slate-400 border border-white/10'
                  }`}
                >
                  <Eye className="w-3 h-3" />
                  DICOM HUD
                </button>
                <div className="flex items-center gap-1 bg-[#040812] p-0.5 rounded border border-white/10">
                  <button
                    onClick={() => setZoom((z) => Math.max(0.8, z - 0.2))}
                    className="p-1 text-slate-400 hover:text-white"
                  >
                    <ZoomOut className="w-3.5 h-3.5" />
                  </button>
                  <span className="px-1 text-[10px] font-mono text-slate-300">{Math.round(zoom * 100)}%</span>
                  <button
                    onClick={() => setZoom((z) => Math.min(2.0, z + 0.2))}
                    className="p-1 text-slate-400 hover:text-white"
                  >
                    <ZoomIn className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Diagnostic Inspector & Detected Lesion Details (4 Columns) */}
        <div className="xl:col-span-4 space-y-4">
          {/* Active Lesion Detailed Inspection Card */}
          <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
            <div className="border-b border-white/10 pb-3 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase text-slate-400">
                  AI SEGMENTATION ANALYSIS
                </span>
                <h3 className="text-base font-bold text-white tracking-tight mt-0.5">
                  {currentSelectedAnomaly.title}
                </h3>
              </div>
              <span
                className={`px-2.5 py-1 rounded-full text-xs font-mono font-bold border ${
                  currentSelectedAnomaly.category === 'Critical'
                    ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse'
                    : currentSelectedAnomaly.category === 'Moderate'
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/40'
                    : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40'
                }`}
              >
                {currentSelectedAnomaly.category.toUpperCase()}
              </span>
            </div>

            {/* Quantitative Finding */}
            <div className="p-3 rounded-xl bg-[#040812] border border-white/5 space-y-1">
              <div className="text-[10px] font-mono text-cyan-400 uppercase">QUANTITATIVE METRIC</div>
              <div className="text-sm font-bold text-white">{currentSelectedAnomaly.metric}</div>
              <p className="text-xs text-slate-300 leading-relaxed mt-1">
                {currentSelectedAnomaly.finding}
              </p>
            </div>

            {/* Clinical Recommendation */}
            <div className="p-3 rounded-xl bg-purple-950/20 border border-purple-500/30 text-xs space-y-1">
              <div className="text-[10px] font-mono text-purple-400 uppercase flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                CLINICAL PROTOCOL ACTION
              </div>
              <p className="text-slate-200 leading-relaxed">
                {currentSelectedAnomaly.recommendation}
              </p>
            </div>

            {/* Transfer to Report CTA */}
            <div className="pt-1">
              <button
                onClick={() => {
                  setExportedFinding(true);
                  setTimeout(() => {
                    if (onOpenReport) onOpenReport();
                  }, 800);
                }}
                className={`w-full flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs font-semibold transition-all shadow-md ${
                  exportedFinding
                    ? 'bg-emerald-500 text-black'
                    : 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white'
                }`}
              >
                {exportedFinding ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Finding Logged to Report! Opening...</span>
                  </>
                ) : (
                  <>
                    <FileText className="w-4 h-4" />
                    <span>Append Lesion to Diagnostic Report</span>
                  </>
                )}
              </button>
            </div>

            {/* Detected Lesion Switcher */}
            <div className="space-y-1.5 pt-2 border-t border-white/10">
              <span className="text-[11px] font-mono text-slate-400">DETECTED REGIONS ({activeAnomalies.length}):</span>
              <div className="space-y-1.5">
                {activeAnomalies.map((a) => (
                  <button
                    key={a.id}
                    onClick={() => setSelectedAnomalyId(a.id)}
                    className={`w-full p-2 rounded-xl text-left text-xs transition-all border ${
                      a.id === selectedAnomalyId
                        ? 'bg-white/10 border-white/30 text-white font-semibold'
                        : 'bg-[#040812] border-white/5 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="truncate">{a.title}</span>
                      <span
                        className={`text-[9px] font-mono px-1.5 py-0.5 rounded ${
                          a.category === 'Critical'
                            ? 'bg-rose-500/20 text-rose-300'
                            : 'bg-amber-500/20 text-amber-300'
                        }`}
                      >
                        {a.category}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Quick Guidance Box */}
          <div className="p-3.5 rounded-2xl bg-[#080e1c] border border-white/5 text-xs text-slate-400 space-y-1.5">
            <div className="font-semibold text-slate-200 flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-cyan-400" />
              Medical Measurement Tips
            </div>
            <p className="text-[11px] leading-relaxed">
              Select <strong>Caliper (mm)</strong> and click two anatomical coordinates to measure arterial lumen diameter or lesion boundaries. Select <strong>HU Density Probe</strong> to hover over any scan quadrant to identify tissue attenuation in Hounsfield Units.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
