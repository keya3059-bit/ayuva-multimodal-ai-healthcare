import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Activity,
  Heart,
  Brain,
  Sliders,
  TrendingUp,
  AlertOctagon,
  ShieldCheck,
  Zap,
  RotateCcw,
  Sparkles,
  Info,
  ChevronRight,
  FileText,
  Clock,
  Gauge,
  Check,
  Flame,
  Stethoscope
} from 'lucide-react';
import { OrganType } from './Anatomical3DViewer';

interface ClinicalPredictorProps {
  organ: OrganType;
  onOpenReport?: () => void;
}

export const ClinicalPredictor: React.FC<ClinicalPredictorProps> = ({
  organ,
  onOpenReport
}) => {
  // -------------------------------------------------------------
  // CARDIOLOGY PREDICTOR PARAMETERS
  // -------------------------------------------------------------
  const [stenosisPercent, setStenosisPercent] = useState<number>(68); // 0 - 100%
  const [ffrValue, setFfrValue] = useState<number>(0.74); // 0.50 - 1.00
  const [systolicBp, setSystolicBp] = useState<number>(138); // 90 - 200 mmHg
  const [ldlCholesterol, setLdlCholesterol] = useState<number>(142); // 50 - 250 mg/dL
  const [troponinI, setTroponinI] = useState<number>(0.18); // 0.01 - 3.00 ng/mL
  const [lvefPercent, setLvefPercent] = useState<number>(56); // 20 - 75 %
  const [patientAge, setPatientAge] = useState<number>(58); // 30 - 85 years

  // -------------------------------------------------------------
  // NEUROLOGY / STROKE PREDICTOR PARAMETERS
  // -------------------------------------------------------------
  const [onsetHours, setOnsetHours] = useState<number>(3.2); // 0.5 - 24.0 hours
  const [coreVolumeMl, setCoreVolumeMl] = useState<number>(16); // 0 - 120 mL
  const [penumbraVolumeMl, setPenumbraVolumeMl] = useState<number>(52); // 10 - 200 mL
  const [neuroBpSystolic, setNeuroBpSystolic] = useState<number>(154); // 100 - 220 mmHg
  const [serumGlucose, setSerumGlucose] = useState<number>(132); // 70 - 350 mg/dL
  const [baselineNihss, setBaselineNihss] = useState<number>(14); // 0 - 42 points
  const [exportedToReport, setExportedToReport] = useState<boolean>(false);

  // Quick Preset Clinical Cases
  const applyHeartPreset = (type: 'stemi' | 'stable' | 'mild') => {
    if (type === 'stemi') {
      setStenosisPercent(94);
      setFfrValue(0.61);
      setSystolicBp(162);
      setLdlCholesterol(178);
      setTroponinI(2.45);
      setLvefPercent(38);
      setPatientAge(64);
    } else if (type === 'stable') {
      setStenosisPercent(68);
      setFfrValue(0.74);
      setSystolicBp(138);
      setLdlCholesterol(142);
      setTroponinI(0.18);
      setLvefPercent(56);
      setPatientAge(58);
    } else {
      setStenosisPercent(22);
      setFfrValue(0.89);
      setSystolicBp(122);
      setLdlCholesterol(94);
      setTroponinI(0.01);
      setLvefPercent(65);
      setPatientAge(48);
    }
  };

  const applyNeuroPreset = (type: 'hyperacute' | 'extended' | 'tia') => {
    if (type === 'hyperacute') {
      setOnsetHours(2.1);
      setCoreVolumeMl(12);
      setPenumbraVolumeMl(65);
      setNeuroBpSystolic(152);
      setSerumGlucose(128);
      setBaselineNihss(15);
    } else if (type === 'extended') {
      setOnsetHours(13.5);
      setCoreVolumeMl(24);
      setPenumbraVolumeMl(98);
      setNeuroBpSystolic(176);
      setSerumGlucose(164);
      setBaselineNihss(19);
    } else {
      setOnsetHours(0.8);
      setCoreVolumeMl(0);
      setPenumbraVolumeMl(8);
      setNeuroBpSystolic(134);
      setSerumGlucose(105);
      setBaselineNihss(2);
    }
  };

  // -------------------------------------------------------------
  // CARDIOLOGY REAL-TIME PREDICTIVE CALCULATIONS
  // -------------------------------------------------------------
  // CAD-RADS classification (Coronary Artery Disease - Reporting and Data System)
  const getCadRads = (stenosis: number): { score: string; desc: string; severity: 'Mild' | 'Moderate' | 'Severe' | 'Critical' } => {
    if (stenosis === 0) return { score: 'CAD-RADS 0', desc: 'No identifiable coronary plaque / normal', severity: 'Mild' };
    if (stenosis < 25) return { score: 'CAD-RADS 1', desc: 'Minimal non-obstructive stenosis (1-24%)', severity: 'Mild' };
    if (stenosis < 50) return { score: 'CAD-RADS 2', desc: 'Mild non-obstructive stenosis (25-49%)', severity: 'Mild' };
    if (stenosis < 70) return { score: 'CAD-RADS 3', desc: 'Moderate stenosis (50-69%) - FFR indicated', severity: 'Moderate' };
    if (stenosis < 100) return { score: 'CAD-RADS 4A', desc: 'Severe stenosis (70-99%) - high hemodynamic significance', severity: 'Severe' };
    return { score: 'CAD-RADS 5', desc: 'Total coronary occlusion (100%)', severity: 'Critical' };
  };

  const cadRads = getCadRads(stenosisPercent);

  // 10-Year ASCVD Risk (Modified Framingham / Pooled Cohort Equation proxy)
  const calculateAscvdRisk = (): number => {
    let risk = (patientAge - 30) * 0.35 + (systolicBp - 110) * 0.12 + (ldlCholesterol - 80) * 0.06;
    if (stenosisPercent >= 50) risk += 6.5;
    if (troponinI > 0.04) risk += 4.2;
    return Math.min(65, Math.max(2.1, parseFloat(risk.toFixed(1))));
  };
  const ascvdRisk = calculateAscvdRisk();

  // 30-Day MACE (Major Adverse Cardiac Events: MI, Death, Repeat Revasc)
  const calculateMaceRisk = (): number => {
    let mace = 2.0;
    if (ffrValue < 0.80) mace += 7.8;
    if (stenosisPercent >= 70) mace += 6.4;
    if (troponinI >= 0.10) mace += 8.5;
    if (lvefPercent < 45) mace += 5.2;
    return Math.min(48, Math.max(1.2, parseFloat(mace.toFixed(1))));
  };
  const maceRisk = calculateMaceRisk();

  // Peak Systolic Myocardial Wall Stress (Laplace Law approximation in kPa)
  const peakWallStress = parseFloat(((systolicBp * 0.133 * 38) / (2 * 11)).toFixed(1)); // ~32 - 55 kPa

  // -------------------------------------------------------------
  // NEUROLOGY REAL-TIME PREDICTIVE CALCULATIONS
  // -------------------------------------------------------------
  // ASPECTS (Alberta Stroke Program Early CT Score: 10 down to 0)
  const calculateAspects = (): number => {
    let deducted = Math.floor(coreVolumeMl / 12);
    return Math.max(2, Math.min(10, 10 - deducted));
  };
  const aspectsScore = calculateAspects();

  // Mismatch Ratio (Ischemic Penumbra to Core)
  const mismatchRatio = coreVolumeMl > 0 ? parseFloat((penumbraVolumeMl / coreVolumeMl).toFixed(2)) : 5.0;
  const salvageableTissueMl = Math.max(0, penumbraVolumeMl - coreVolumeMl);

  // 90-Day Good Functional Outcome (mRS 0-2) probability
  const calculateMrsGoodOutcome = (): number => {
    let prob = 78;
    prob -= baselineNihss * 2.2;
    prob -= onsetHours * 2.8;
    prob -= coreVolumeMl * 0.45;
    if (mismatchRatio >= 1.8) prob += 14; // positive penumbral rescue
    return Math.min(92, Math.max(5, Math.round(prob)));
  };
  const mrsOutcomeProb = calculateMrsGoodOutcome();

  // Symptomatic Intracranial Hemorrhage (sICH) Risk %
  const calculateSichRisk = (): number => {
    let risk = 2.5;
    if (onsetHours > 4.5) risk += 4.5;
    if (neuroBpSystolic > 185) risk += 6.2;
    if (serumGlucose > 180) risk += 3.8;
    if (coreVolumeMl > 50) risk += 5.0;
    return Math.min(35, Math.max(1.5, parseFloat(risk.toFixed(1))));
  };
  const sichRisk = calculateSichRisk();

  const resetHeartDefaults = () => {
    setStenosisPercent(68);
    setFfrValue(0.74);
    setSystolicBp(138);
    setLdlCholesterol(142);
    setTroponinI(0.18);
    setLvefPercent(56);
    setPatientAge(58);
  };

  const resetNeuroDefaults = () => {
    setOnsetHours(3.2);
    setCoreVolumeMl(16);
    setPenumbraVolumeMl(52);
    setNeuroBpSystolic(154);
    setSerumGlucose(132);
    setBaselineNihss(14);
  };

  return (
    <div className="space-y-5">
      {/* Top Banner */}
      <div className="p-4 rounded-2xl bg-[#080e1c] border border-purple-500/30 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <Activity className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white tracking-tight">
                {organ === 'heart'
                  ? 'Cardiovascular Hemodynamic & Ischemia Risk Predictor'
                  : 'Acute Ischemic Stroke & Penumbral Salvage Predictor'}
              </h2>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-purple-500/20 text-purple-300 border border-purple-500/40">
                CLINICAL AI INFERENCE
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Interactive physiological simulator calculating evidence-based clinical scores (CAD-RADS, ASCVD, ASPECTS, and Penumbra Salvage Mismatch).
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={organ === 'heart' ? resetHeartDefaults : resetNeuroDefaults}
            className="px-3 py-1.5 rounded-xl bg-[#040812] border border-white/10 hover:border-white/30 text-xs font-mono text-slate-300 flex items-center gap-1.5 transition-all"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Sliders</span>
          </button>
          {onOpenReport && (
            <button
              onClick={onOpenReport}
              className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-semibold flex items-center gap-1.5 transition-all"
            >
              <FileText className="w-3.5 h-3.5 text-emerald-400" />
              <span>Export Values to Report</span>
            </button>
          )}
        </div>
      </div>

      {/* Main Grid: Parameters on Left (5 cols), Live Outputs on Right (7 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* LEFT: Interactive Physiological Sliders (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  CLINICAL INPUT VARIABLES
                </h3>
              </div>
              <span className="text-[10px] font-mono text-slate-400">SLIDE TO TEST</span>
            </div>

            {/* Quick Clinical Case Presets */}
            <div className="p-2.5 rounded-xl bg-[#040812] border border-white/5 space-y-2">
              <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                <span className="flex items-center gap-1 text-purple-300 font-bold">
                  <Stethoscope className="w-3.5 h-3.5" />
                  PRESET CASE SCENARIOS:
                </span>
                <span className="text-[10px] text-slate-500">Instant Clinical Profile</span>
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                {organ === 'heart' ? (
                  <>
                    <button
                      onClick={() => applyHeartPreset('stemi')}
                      className="px-2 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-[10px] font-semibold text-rose-300 text-left transition-all truncate"
                      title="Acute STEMI Emergency (94% Stenosis, FFR 0.61, Troponin 2.45)"
                    >
                      🔥 STEMI Acute
                    </button>
                    <button
                      onClick={() => applyHeartPreset('stable')}
                      className="px-2 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-[10px] font-semibold text-amber-300 text-left transition-all truncate"
                      title="Severe Stable Angina (68% Stenosis, FFR 0.74, Troponin 0.18)"
                    >
                      ⚡ Severe CAD
                    </button>
                    <button
                      onClick={() => applyHeartPreset('mild')}
                      className="px-2 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-[10px] font-semibold text-emerald-300 text-left transition-all truncate"
                      title="Mild Non-Obstructive Plaque (22% Stenosis, FFR 0.89)"
                    >
                      ✅ Mild CAD
                    </button>
                  </>
                ) : (
                  <>
                    <button
                      onClick={() => applyNeuroPreset('hyperacute')}
                      className="px-2 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 text-[10px] font-semibold text-rose-300 text-left transition-all truncate"
                      title="Hyperacute Stroke (2.1h window, IV-tPA candidate)"
                    >
                      🚨 Acute Code
                    </button>
                    <button
                      onClick={() => applyNeuroPreset('extended')}
                      className="px-2 py-1.5 rounded-lg bg-purple-500/10 hover:bg-purple-500/20 border border-purple-500/30 text-[10px] font-semibold text-purple-300 text-left transition-all truncate"
                      title="Extended Window Stroke (13.5h, EVT candidate)"
                    >
                      🎯 EVT Window
                    </button>
                    <button
                      onClick={() => applyNeuroPreset('tia')}
                      className="px-2 py-1.5 rounded-lg bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/30 text-[10px] font-semibold text-emerald-300 text-left transition-all truncate"
                      title="Transient Ischemic Attack (0.8h, Core 0mL, NIHSS 2)"
                    >
                      ✅ TIA Profile
                    </button>
                  </>
                )}
              </div>
            </div>

            {/* CONDITIONAL CONTROLS: HEART */}
            {organ === 'heart' ? (
              <div className="space-y-4 text-xs">
                {/* Coronary Stenosis % */}
                <div className="space-y-1.5">
                  <div className="flex justify-between font-mono">
                    <span className="text-slate-300 font-semibold">Coronary Stenosis Severity</span>
                    <span className="text-cyan-400 font-bold">{stenosisPercent}% Lumen Reduction</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="1"
                    value={stenosisPercent}
                    onChange={(e) => setStenosisPercent(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>0% (Patent)</span>
                    <span>50% (Ischemic Threshold)</span>
                    <span>100% (Total)</span>
                  </div>
                </div>

                {/* Fractional Flow Reserve (FFR) */}
                <div className="space-y-1.5">
                  <div className="flex justify-between font-mono">
                    <span className="text-slate-300 font-semibold">Fractional Flow Reserve (FFR)</span>
                    <span className={`font-bold ${ffrValue < 0.80 ? 'text-rose-400' : 'text-emerald-400'}`}>
                      {ffrValue.toFixed(2)} {ffrValue < 0.80 ? '(Ischemic <0.80)' : '(Hemodynamically Normal)'}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.50"
                    max="1.00"
                    step="0.01"
                    value={ffrValue}
                    onChange={(e) => setFfrValue(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-400"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>0.50 (Severe)</span>
                    <span className="text-amber-400">0.80 (Cutoff)</span>
                    <span>1.00 (Max)</span>
                  </div>
                </div>

                {/* Systolic Blood Pressure */}
                <div className="space-y-1.5">
                  <div className="flex justify-between font-mono">
                    <span className="text-slate-300 font-semibold">Systolic Blood Pressure</span>
                    <span className="text-amber-300 font-bold">{systolicBp} mmHg</span>
                  </div>
                  <input
                    type="range"
                    min="90"
                    max="200"
                    step="1"
                    value={systolicBp}
                    onChange={(e) => setSystolicBp(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                  />
                </div>

                {/* High Sensitivity Troponin I */}
                <div className="space-y-1.5">
                  <div className="flex justify-between font-mono">
                    <span className="text-slate-300 font-semibold">High-Sensitivity Troponin I</span>
                    <span className={`font-bold ${troponinI > 0.04 ? 'text-rose-400' : 'text-emerald-400'}`}>
                      {troponinI.toFixed(2)} ng/mL {troponinI > 0.04 ? '(Myocardial Injury)' : '(Normal)'}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.01"
                    max="1.50"
                    step="0.01"
                    value={troponinI}
                    onChange={(e) => setTroponinI(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-400"
                  />
                </div>

                {/* Left Ventricular Ejection Fraction (LVEF) */}
                <div className="space-y-1.5">
                  <div className="flex justify-between font-mono">
                    <span className="text-slate-300 font-semibold">Ejection Fraction (LVEF)</span>
                    <span className={`font-bold ${lvefPercent < 50 ? 'text-amber-400' : 'text-emerald-400'}`}>
                      {lvefPercent}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min="25"
                    max="75"
                    step="1"
                    value={lvefPercent}
                    onChange={(e) => setLvefPercent(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-400"
                  />
                </div>

                {/* Patient Age */}
                <div className="space-y-1.5">
                  <div className="flex justify-between font-mono">
                    <span className="text-slate-300 font-semibold">Patient Age</span>
                    <span className="text-slate-200 font-bold">{patientAge} Years</span>
                  </div>
                  <input
                    type="range"
                    min="30"
                    max="85"
                    step="1"
                    value={patientAge}
                    onChange={(e) => setPatientAge(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-slate-400"
                  />
                </div>
              </div>
            ) : (
              /* CONDITIONAL CONTROLS: BRAIN / STROKE */
              <div className="space-y-4 text-xs">
                {/* Onset to Door Time */}
                <div className="space-y-1.5">
                  <div className="flex justify-between font-mono">
                    <span className="text-slate-300 font-semibold">Time from Symptom Onset</span>
                    <span className={`font-bold ${onsetHours <= 4.5 ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {onsetHours.toFixed(1)} Hours {onsetHours <= 4.5 ? '(Within IV-tPA window)' : '(Extended EVT window)'}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0.5"
                    max="24.0"
                    step="0.1"
                    value={onsetHours}
                    onChange={(e) => setOnsetHours(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>0.5h</span>
                    <span className="text-emerald-400">4.5h (IV tPA limit)</span>
                    <span>24.0h (DAWN EVT limit)</span>
                  </div>
                </div>

                {/* Infarct Core Volume (mL) */}
                <div className="space-y-1.5">
                  <div className="flex justify-between font-mono">
                    <span className="text-slate-300 font-semibold">Irreversible Core Infarct (DWI)</span>
                    <span className={`font-bold ${coreVolumeMl > 50 ? 'text-rose-400' : 'text-amber-400'}`}>
                      {coreVolumeMl} mL
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="100"
                    step="1"
                    value={coreVolumeMl}
                    onChange={(e) => setCoreVolumeMl(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-rose-400"
                  />
                  <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                    <span>0 mL (No necrosis)</span>
                    <span className="text-amber-400">70 mL (DEFUSE cutoff)</span>
                    <span>100 mL</span>
                  </div>
                </div>

                {/* Penumbra Volume (mL) */}
                <div className="space-y-1.5">
                  <div className="flex justify-between font-mono">
                    <span className="text-slate-300 font-semibold">Total Hypoperfused Tissue (Tmax&gt;6s)</span>
                    <span className="text-purple-400 font-bold">{penumbraVolumeMl} mL</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="160"
                    step="1"
                    value={penumbraVolumeMl}
                    onChange={(e) => setPenumbraVolumeMl(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-400"
                  />
                </div>

                {/* Baseline NIHSS Score */}
                <div className="space-y-1.5">
                  <div className="flex justify-between font-mono">
                    <span className="text-slate-300 font-semibold">Baseline NIH Stroke Scale (NIHSS)</span>
                    <span className={`font-bold ${baselineNihss >= 15 ? 'text-rose-400' : 'text-amber-400'}`}>
                      {baselineNihss} Points {baselineNihss >= 15 ? '(Severe Stroke)' : '(Moderate)'}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="42"
                    step="1"
                    value={baselineNihss}
                    onChange={(e) => setBaselineNihss(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
                  />
                </div>

                {/* Systolic BP */}
                <div className="space-y-1.5">
                  <div className="flex justify-between font-mono">
                    <span className="text-slate-300 font-semibold">Admission Systolic BP</span>
                    <span className={`font-bold ${neuroBpSystolic > 185 ? 'text-rose-400' : 'text-emerald-400'}`}>
                      {neuroBpSystolic} mmHg {neuroBpSystolic > 185 ? '(>185: Must lower for tPA)' : '(Permissible)'}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="100"
                    max="220"
                    step="2"
                    value={neuroBpSystolic}
                    onChange={(e) => setNeuroBpSystolic(Number(e.target.value))}
                    className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-400"
                  />
                </div>
              </div>
            )}
          </div>
        </div>

        {/* RIGHT: Live Predictive Output Scores & Action Protocols (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          {/* Real-time Predictive Metrics Bento Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {organ === 'heart' ? (
              <>
                {/* Metric 1: CAD-RADS */}
                <div className="p-4 rounded-2xl bg-[#080e1c] border border-cyan-500/20 shadow-lg space-y-2">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400">CORONARY CAD-RADS</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        cadRads.severity === 'Severe' || cadRads.severity === 'Critical'
                          ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                          : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                      }`}
                    >
                      {cadRads.severity.toUpperCase()}
                    </span>
                  </div>
                  <div className="text-2xl font-black text-white">{cadRads.score}</div>
                  <p className="text-xs text-slate-300 leading-snug">{cadRads.desc}</p>
                </div>

                {/* Metric 2: 10-Year ASCVD Risk % */}
                <div className="p-4 rounded-2xl bg-[#080e1c] border border-purple-500/20 shadow-lg space-y-2">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400">10-YR ASCVD RISK</span>
                    <span className="text-purple-400 font-bold">POOLED COHORT</span>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-black text-purple-300">{ascvdRisk}%</span>
                    <span className="text-xs font-mono text-purple-400">
                      {ascvdRisk > 20 ? 'HIGH RISK' : ascvdRisk > 7.5 ? 'INTERMEDIATE' : 'LOW'}
                    </span>
                  </div>
                  {/* Progress Bar */}
                  <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-300 ${
                        ascvdRisk > 20 ? 'bg-rose-500' : ascvdRisk > 7.5 ? 'bg-amber-500' : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.min(100, ascvdRisk * 2)}%` }}
                    />
                  </div>
                </div>

                {/* Metric 3: 30-Day MACE Probability */}
                <div className="p-4 rounded-2xl bg-[#080e1c] border border-rose-500/20 shadow-lg space-y-2">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400">30-DAY MACE RISK</span>
                    <span className="text-rose-400 font-bold">ISCHEMIC RATE</span>
                  </div>
                  <div className="text-2xl font-black text-rose-300">{maceRisk}%</div>
                  <p className="text-xs text-slate-400 leading-snug">
                    Predicted 30-day major adverse cardiac event probability without revascularization.
                  </p>
                </div>

                {/* Metric 4: Peak Myocardial Wall Stress */}
                <div className="p-4 rounded-2xl bg-[#080e1c] border border-amber-500/20 shadow-lg space-y-2">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400">PEAK WALL STRESS</span>
                    <span className="text-amber-400 font-bold">LAPLACE LAW</span>
                  </div>
                  <div className="text-2xl font-black text-amber-300">{peakWallStress} kPa</div>
                  <p className="text-xs text-slate-400 leading-snug">
                    Normal: 30–42 kPa. Elevated values trigger ventricular remodeling and hypertrophy.
                  </p>
                </div>
              </>
            ) : (
              <>
                {/* Metric 1: ASPECTS Score */}
                <div className="p-4 rounded-2xl bg-[#080e1c] border border-cyan-500/20 shadow-lg space-y-2">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400">ASPECTS SCORE</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        aspectsScore >= 8
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : aspectsScore >= 6
                          ? 'bg-amber-500/20 text-amber-300'
                          : 'bg-rose-500/20 text-rose-300'
                      }`}
                    >
                      {aspectsScore >= 6 ? 'FAVORABLE' : 'EXTENSIVE'}
                    </span>
                  </div>
                  <div className="text-3xl font-black text-white">{aspectsScore} / 10</div>
                  <p className="text-xs text-slate-300 leading-snug">
                    Alberta Stroke Program Early CT Score. Scores ≥ 6 correlate with favorable thrombectomy outcomes.
                  </p>
                </div>

                {/* Metric 2: Penumbra Mismatch Ratio */}
                <div className="p-4 rounded-2xl bg-[#080e1c] border border-purple-500/20 shadow-lg space-y-2">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400">PERFUSION MISMATCH</span>
                    <span className="text-purple-400 font-bold">SALVAGEABLE</span>
                  </div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl font-black text-purple-300">{mismatchRatio}x</span>
                    <span className="text-xs font-mono text-emerald-400">
                      +{salvageableTissueMl} mL Salvageable
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 leading-snug">
                    Penumbra/Core ratio &gt; 1.8x satisfies DEFUSE-3 and DAWN criteria for mechanical thrombectomy.
                  </p>
                </div>

                {/* Metric 3: 90-Day Good Outcome (mRS 0-2) */}
                <div className="p-4 rounded-2xl bg-[#080e1c] border border-emerald-500/20 shadow-lg space-y-2">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400">90-DAY INDEPENDENCE</span>
                    <span className="text-emerald-400 font-bold">mRS 0–2 PROBABILITY</span>
                  </div>
                  <div className="text-3xl font-black text-emerald-300">{mrsOutcomeProb}%</div>
                  <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-400 transition-all duration-300"
                      style={{ width: `${mrsOutcomeProb}%` }}
                    />
                  </div>
                </div>

                {/* Metric 4: Hemorrhage Risk (sICH) */}
                <div className="p-4 rounded-2xl bg-[#080e1c] border border-rose-500/20 shadow-lg space-y-2">
                  <div className="flex items-center justify-between text-xs font-mono">
                    <span className="text-slate-400">sICH BLEED RISK</span>
                    <span className="text-rose-400 font-bold">ECASS CRITERIA</span>
                  </div>
                  <div className="text-2xl font-black text-rose-300">{sichRisk}%</div>
                  <p className="text-xs text-slate-400 leading-snug">
                    Symptomatic intracerebral hemorrhage risk under systemic thrombolysis protocols.
                  </p>
                </div>
              </>
            )}
          </div>

          {/* AI Clinical Pathway & Evidence-Based Intervention Protocol */}
          <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-3">
            <div className="flex items-center gap-2 border-b border-white/10 pb-3">
              <Sparkles className="w-4 h-4 text-purple-400" />
              <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                SYNTHESIZED CLINICAL DECISION SUPPORT
              </h3>
            </div>

            {organ === 'heart' ? (
              <div className="space-y-3 text-xs">
                <div className="p-3 rounded-xl bg-purple-950/20 border border-purple-500/30">
                  <div className="text-purple-300 font-bold flex items-center gap-1.5 mb-1">
                    <ShieldCheck className="w-4 h-4 text-purple-400" />
                    RECOMMENDED REVASCULARIZATION PATHWAY:
                  </div>
                  <p className="text-slate-200 leading-relaxed">
                    {ffrValue < 0.80 || stenosisPercent >= 70
                      ? 'Hemodynamically Significant Coronary Stenosis confirmed (FFR < 0.80). Class I Guideline recommendation for Percutaneous Coronary Intervention (PCI) with Drug-Eluting Stent (DES) to mid-LAD, supplemented by Dual Antiplatelet Therapy (DAPT with Aspirin + Ticagrelor 90mg BID).'
                      : 'Non-hemodynamically significant plaque (FFR ≥ 0.80). Recommend Optimal Medical Therapy (OMT): High-intensity Atorvastatin 80mg daily, ACE-inhibitor for BP control, and lifestyle modification.'}
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-300">
                  <div className="p-2.5 rounded-xl bg-[#040812] border border-white/5">
                    <div className="text-[10px] font-mono text-cyan-400">ISCHEMIC BURDEN</div>
                    <div className="font-semibold text-white mt-0.5">
                      {ffrValue < 0.75 ? 'Severe Reversible Myocardial Deficit' : 'Low-to-Moderate Deficit'}
                    </div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#040812] border border-white/5">
                    <div className="text-[10px] font-mono text-amber-400">STENT GRAFT COMPATIBILITY</div>
                    <div className="font-semibold text-white mt-0.5">
                      DES 3.0mm x 18mm Everolimus-Eluting
                    </div>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-3 text-xs">
                <div className="p-3 rounded-xl bg-purple-950/20 border border-purple-500/30">
                  <div className="text-purple-300 font-bold flex items-center gap-1.5 mb-1">
                    <Zap className="w-4 h-4 text-purple-400" />
                    ACUTE STROKE CODE TRIAGE:
                  </div>
                  <p className="text-slate-200 leading-relaxed">
                    {onsetHours <= 4.5 && neuroBpSystolic <= 185
                      ? 'ELIGIBLE FOR INTRAVENOUS THROMBOLYSIS (IV-tPA): Patient is within the 4.5-hour therapeutic window with favorable ASPECTS score (≥6). Administer IV Alteplase (0.9 mg/kg, 10% bolus over 1 min, remainder over 60 min).'
                      : onsetHours <= 24 && mismatchRatio >= 1.8 && coreVolumeMl < 70
                      ? 'HIGH PRIORITY ENDOVASCULAR MECHANICAL THROMBECTOMY (EVT): Candidate for stent-retriever/aspiration thrombectomy under DAWN/DEFUSE-3 extended window guidelines. Favorable target mismatch detected.'
                      : 'EXTENSIVE INFARCT / POST-WINDOW PROTOCOL: Core infarct volume exceeds safe threshold for aggressive reperfusion. Focus on neuroprotection, permissive hypertension, anti-edema mannitol/hypertonic saline, and decompressive craniectomy monitoring.'}
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-300">
                  <div className="p-2.5 rounded-xl bg-[#040812] border border-white/5">
                    <div className="text-[10px] font-mono text-cyan-400">TISSUE SALVAGE POTENTIAL</div>
                    <div className="font-semibold text-white mt-0.5">
                      {mismatchRatio >= 1.8 ? 'Significant Viable Penumbra at Risk' : 'Limited Salvage Margin'}
                    </div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-[#040812] border border-white/5">
                    <div className="text-[10px] font-mono text-amber-400">EVT THROMBECTOMY SUITABILITY</div>
                    <div className="font-semibold text-white mt-0.5">
                      {aspectsScore >= 6 ? 'Class I Indication (High Benefit)' : 'Suboptimal Anatomy'}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Export Stratification CTA Button */}
            <div className="pt-2 border-t border-white/10">
              <button
                onClick={() => {
                  setExportedToReport(true);
                  setTimeout(() => {
                    if (onOpenReport) onOpenReport();
                  }, 800);
                }}
                className={`w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl text-xs font-semibold transition-all shadow-lg ${
                  exportedToReport
                    ? 'bg-emerald-500 text-black'
                    : 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white'
                }`}
              >
                {exportedToReport ? (
                  <>
                    <Check className="w-4 h-4" />
                    <span>Calculated Risks Sent to Report! Opening...</span>
                  </>
                ) : (
                  <>
                    <FileText className="w-4 h-4" />
                    <span>Append Risk Stratification to Clinical Diagnostic Report</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
