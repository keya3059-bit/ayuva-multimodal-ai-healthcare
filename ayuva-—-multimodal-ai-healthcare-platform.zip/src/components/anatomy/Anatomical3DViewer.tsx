import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Heart,
  Brain,
  Wind,
  Droplets,
  Dna,
  Eye,
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Layers,
  Activity,
  Zap,
  Info,
  Sliders,
  AlertTriangle,
  Sparkles,
  Search,
  CheckCircle2,
  ChevronRight,
  Maximize2,
  Crosshair,
  Ruler,
  TrendingUp,
  FileText,
  ArrowRight,
  ArrowLeft,
  Stethoscope,
  Volume2,
  VolumeX,
  Headphones
} from 'lucide-react';

// Specialized Clinical Modules
import { ImageAnalysisViewer } from './ImageAnalysisViewer';
import { ClinicalPredictor } from './ClinicalPredictor';
import { ClinicalReportGenerator } from './ClinicalReportGenerator';
import { OrganAuscultationBar } from './OrganAuscultationBar';
import { organAudioEngine } from '../../utils/organAudioEngine';

// High-resolution anatomical models
import brain3DImg from '../../assets/images/medical_brain_detail_1789616926989.jpg';
import brainSagittalImg from '../../assets/images/brain_neural_lobes_1789616973656.jpg';
import heart3DImg from '../../assets/images/medical_heart_detail_1789616941560.jpg';
import heartChambersImg from '../../assets/images/heart_chambers_valves_1789616961173.jpg';
import lungs3DImg from '../../assets/images/medical_lungs_detail_1789645373964.jpg';
import kidney3DImg from '../../assets/images/medical_kidney_detail_1789645387170.jpg';
import liver3DImg from '../../assets/images/medical_liver_detail_1789645402871.jpg';
import spine3DImg from '../../assets/images/medical_spine_detail_1789645414923.jpg';

import {
  AnatomicalStructure,
  HEART_STRUCTURES,
  BRAIN_STRUCTURES,
  LUNGS_STRUCTURES,
  KIDNEYS_STRUCTURES,
  LIVER_STRUCTURES,
  SPINE_STRUCTURES
} from './anatomicalData';

export type OrganType = 'heart' | 'brain' | 'lungs' | 'kidneys' | 'liver' | 'spine';
export type ViewPerspective = 'surface' | 'cross-section' | 'conduction-neural';
export type WorkspaceTab = '3d-detailing' | 'image-analysis' | 'predictive-engine' | 'diagnostic-report';

export const Anatomical3DViewer: React.FC = () => {
  // Navigation & Model Selection
  const [selectedOrgan, setSelectedOrgan] = useState<OrganType>('heart');
  const [workspaceTab, setWorkspaceTab] = useState<WorkspaceTab>('3d-detailing');
  const [viewPerspective, setViewPerspective] = useState<ViewPerspective>('surface');
  const [selectedStructureId, setSelectedStructureId] = useState<string>('aortic-arch');

  // Interactive Layer Toggles
  const [showHotspotPins, setShowHotspotPins] = useState<boolean>(true);
  const [showVascularOverlay, setShowVascularOverlay] = useState<boolean>(true);
  const [showElectrophysiology, setShowElectrophysiology] = useState<boolean>(true);
  const [showStressHeatmap, setShowStressHeatmap] = useState<boolean>(false);

  // Zoom & Pan State
  const [zoomLevel, setZoomLevel] = useState<number>(1.0);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Dynamic Biosignal Parameters for all 6 organs
  const [heartBPM, setHeartBPM] = useState<number>(72);
  const [brainWaveBand, setBrainWaveBand] = useState<'alpha' | 'beta' | 'gamma' | 'theta'>('beta');
  const [lungRespirationRate, setLungRespirationRate] = useState<number>(16);
  const [renalGFR, setRenalGFR] = useState<number>(104);
  const [liverPortalFlow, setLiverPortalFlow] = useState<number>(1100);
  const [spineAxialLoad, setSpineAxialLoad] = useState<number>(950);

  // Audio Auscultation State
  const [isAudioPlaying, setIsAudioPlaying] = useState<boolean>(false);

  useEffect(() => {
    const unsub = organAudioEngine.subscribe((state) => {
      setIsAudioPlaying(state.isPlaying);
    });
    return () => unsub();
  }, []);

  // Switch default selected structure when organ changes
  const handleOrganSwitch = (organ: OrganType) => {
    setSelectedOrgan(organ);
    organAudioEngine.playStructureProbeSound(organ);
    if (organAudioEngine.getState().isPlaying) {
      organAudioEngine.startSound(organ);
    }
    switch (organ) {
      case 'heart':
        setSelectedStructureId('aortic-arch');
        break;
      case 'brain':
        setSelectedStructureId('prefrontal-cortex');
        break;
      case 'lungs':
        setSelectedStructureId('trachea-carina');
        break;
      case 'kidneys':
        setSelectedStructureId('renal-cortex-glomerulus');
        break;
      case 'liver':
        setSelectedStructureId('right-hepatic-lobe');
        break;
      case 'spine':
        setSelectedStructureId('cervical-spine-lordosis');
        break;
    }
  };

  const getOrganStructures = (organ: OrganType): AnatomicalStructure[] => {
    switch (organ) {
      case 'heart': return HEART_STRUCTURES;
      case 'brain': return BRAIN_STRUCTURES;
      case 'lungs': return LUNGS_STRUCTURES;
      case 'kidneys': return KIDNEYS_STRUCTURES;
      case 'liver': return LIVER_STRUCTURES;
      case 'spine': return SPINE_STRUCTURES;
      default: return HEART_STRUCTURES;
    }
  };

  const currentStructures = getOrganStructures(selectedOrgan);
  const activeStructure =
    currentStructures.find((s) => s.id === selectedStructureId) ||
    currentStructures[0] ||
    HEART_STRUCTURES[0];

  // Filter structures by search query
  const filteredStructures = currentStructures.filter((s) =>
    s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.latinName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    s.functionSummary.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Determine current active image based on organ and perspective
  const getActiveImage = () => {
    switch (selectedOrgan) {
      case 'heart':
        return viewPerspective === 'cross-section' ? heartChambersImg : heart3DImg;
      case 'brain':
        return viewPerspective === 'cross-section' ? brainSagittalImg : brain3DImg;
      case 'lungs':
        return lungs3DImg;
      case 'kidneys':
        return kidney3DImg;
      case 'liver':
        return liver3DImg;
      case 'spine':
        return spine3DImg;
      default:
        return heart3DImg;
    }
  };

  const getOrganHeaderInfo = () => {
    switch (selectedOrgan) {
      case 'heart':
        return {
          title: 'Human Heart & Coronary Hemodynamics Model',
          desc: 'Explore myocardial chambers, coronary artery branches, cardiac conduction nodes, and hemodynamic shear stress.',
          icon: Heart,
          iconColor: 'text-rose-400 fill-rose-500/20',
          accentBorder: 'border-rose-500/30'
        };
      case 'brain':
        return {
          title: 'Human Brain & Cerebrovascular Neural Model',
          desc: 'Explore cerebral cortex gyri, synaptic tracts, limbic memory circuit, cerebellar balance, and brainstem arousal.',
          icon: Brain,
          iconColor: 'text-cyan-400',
          accentBorder: 'border-cyan-500/30'
        };
      case 'lungs':
        return {
          title: 'Human Lungs & Tracheobronchial Respiratory Tree',
          desc: 'Explore alveolar-capillary diffusion barriers, bronchial arborization, surfactant physics, and ventilation-perfusion mechanics.',
          icon: Wind,
          iconColor: 'text-teal-400',
          accentBorder: 'border-teal-500/30'
        };
      case 'kidneys':
        return {
          title: 'Human Kidneys & Glomerular Filtration Apparatus',
          desc: 'Explore nephron ultrafiltration units, medullary pyramids, countercurrent exchange, and RAAS endocrine autoregulation.',
          icon: Droplets,
          iconColor: 'text-emerald-400',
          accentBorder: 'border-emerald-500/30'
        };
      case 'liver':
        return {
          title: 'Human Liver & Hepatic Portal Vasculature Model',
          desc: 'Explore Couinaud surgical segments, portal triad inflow, biliary ductal drainage, and Kupffer reticuloendothelial grid.',
          icon: Layers,
          iconColor: 'text-amber-400',
          accentBorder: 'border-amber-500/30'
        };
      case 'spine':
        return {
          title: 'Human Spine & Vertebro-Spinal Column Model',
          desc: 'Explore lordotic & kyphotic curvatures, intervertebral hydraulic shock discs, cauda equina, and neuroforaminal root canals.',
          icon: Dna,
          iconColor: 'text-purple-400',
          accentBorder: 'border-purple-500/30'
        };
    }
  };

  const headerInfo = getOrganHeaderInfo();
  const HeaderIcon = headerInfo.icon;

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-[#060c18] via-[#09152a] to-[#060c18] border border-cyan-500/30 shadow-2xl relative overflow-hidden">
        <div className="absolute -right-12 -bottom-12 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -left-12 -top-12 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className="px-3 py-1 rounded-full text-xs font-mono font-semibold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
                HIGH-FIDELITY MEDICAL DIGITAL TWIN
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-mono font-semibold bg-blue-500/20 text-blue-300 border border-blue-500/40">
                8K MULTI-ORGAN ANATOMICAL ATLAS
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                6 ORGAN SYSTEMS
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-3">
              <HeaderIcon className={`w-8 h-8 ${headerInfo.iconColor} animate-pulse`} />
              <span>{headerInfo.title}</span>
            </h1>
            <p className="text-sm text-slate-300 max-w-3xl mt-1.5 leading-relaxed">
              {headerInfo.desc}
            </p>
          </div>

          {/* 6-Organ Switcher Tabs */}
          <div className="grid grid-cols-2 sm:grid-cols-3 xl:grid-cols-6 gap-2 bg-[#040812]/90 p-2 rounded-2xl border border-white/10 shadow-inner">
            {[
              { id: 'heart', label: 'Heart', icon: Heart, activeClass: 'bg-gradient-to-r from-rose-500 to-red-600 text-white shadow-rose-500/30' },
              { id: 'brain', label: 'Brain', icon: Brain, activeClass: 'bg-gradient-to-r from-cyan-500 to-blue-600 text-black font-bold shadow-cyan-500/30' },
              { id: 'lungs', label: 'Lungs', icon: Wind, activeClass: 'bg-gradient-to-r from-teal-500 to-emerald-600 text-white shadow-teal-500/30' },
              { id: 'kidneys', label: 'Kidneys', icon: Droplets, activeClass: 'bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-blue-500/30' },
              { id: 'liver', label: 'Liver', icon: Layers, activeClass: 'bg-gradient-to-r from-amber-500 to-orange-600 text-black font-bold shadow-amber-500/30' },
              { id: 'spine', label: 'Spine', icon: Dna, activeClass: 'bg-gradient-to-r from-purple-500 to-pink-600 text-white shadow-purple-500/30' },
            ].map((organItem) => {
              const OrganIcon = organItem.icon;
              const isSelected = selectedOrgan === organItem.id;
              return (
                <button
                  key={organItem.id}
                  onClick={() => handleOrganSwitch(organItem.id as OrganType)}
                  className={`flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                    isSelected
                      ? `${organItem.activeClass} shadow-lg scale-[1.02]`
                      : 'text-slate-400 hover:text-white hover:bg-white/5 border border-transparent'
                  }`}
                >
                  <OrganIcon className={`w-4 h-4 ${isSelected ? 'scale-110' : 'text-slate-400'}`} />
                  <span>{organItem.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Sub Navigation: Perspectives & Controls */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-5 mt-6 border-t border-white/10">
          {/* Perspectives */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-slate-400 mr-1 hidden sm:inline">ANATOMICAL VIEW:</span>
            {[
              { id: 'surface', label: '3D External Architecture' },
              { id: 'cross-section', label: 'Internal Cross-Section & Layers' },
              {
                id: 'conduction-neural',
                label:
                  selectedOrgan === 'heart'
                    ? 'Electrophysiology Conduction'
                    : selectedOrgan === 'brain'
                    ? 'Neural Synaptic Map'
                    : selectedOrgan === 'lungs'
                    ? 'Gas Diffusion Circuit'
                    : selectedOrgan === 'kidneys'
                    ? 'Nephron Glomerular Grid'
                    : selectedOrgan === 'liver'
                    ? 'Biliary & Sinusoidal Flow'
                    : 'Vertebro-Radicular Axis'
              }
            ].map((p) => (
              <button
                key={p.id}
                onClick={() => setViewPerspective(p.id as ViewPerspective)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-medium transition-all ${
                  viewPerspective === p.id
                    ? 'bg-white/20 text-white border border-white/40 shadow-sm'
                    : 'bg-[#040812]/60 text-slate-400 hover:text-slate-200 border border-white/5'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>

          {/* Dynamic Biosignal Parameter Simulator Controls */}
          <div className="flex items-center gap-3 text-xs flex-wrap">
            {selectedOrgan === 'heart' && (
              <div className="flex items-center gap-2 bg-[#040812] px-3 py-1.5 rounded-xl border border-rose-500/30 text-slate-300">
                <Activity className="w-4 h-4 text-rose-400 animate-pulse" />
                <span className="font-mono text-slate-400">PULSE RATE:</span>
                <span className="font-mono font-bold text-rose-300">{heartBPM} BPM</span>
                <input
                  type="range"
                  min="50"
                  max="140"
                  value={heartBPM}
                  onChange={(e) => {
                    const bpm = Number(e.target.value);
                    setHeartBPM(bpm);
                    organAudioEngine.updateParameters({ bpm });
                  }}
                  className="w-20 accent-rose-400 ml-1 cursor-pointer"
                />
              </div>
            )}

            {selectedOrgan === 'brain' && (
              <div className="flex items-center gap-2 bg-[#040812] px-3 py-1.5 rounded-xl border border-cyan-500/30 text-slate-300">
                <Zap className="w-4 h-4 text-cyan-400" />
                <span className="font-mono text-slate-400">EEG WAVE:</span>
                {(['alpha', 'beta', 'gamma'] as const).map((band) => (
                  <button
                    key={band}
                    onClick={() => {
                      setBrainWaveBand(band);
                      organAudioEngine.updateParameters({ brainwave: band });
                    }}
                    className={`px-2 py-0.5 rounded text-[11px] font-mono uppercase ${
                      brainWaveBand === band
                        ? 'bg-cyan-500 text-black font-bold'
                        : 'bg-white/5 text-slate-400 hover:text-white'
                    }`}
                  >
                    {band}
                  </button>
                ))}
              </div>
            )}

            {selectedOrgan === 'lungs' && (
              <div className="flex items-center gap-2 bg-[#040812] px-3 py-1.5 rounded-xl border border-teal-500/30 text-slate-300">
                <Wind className="w-4 h-4 text-teal-400" />
                <span className="font-mono text-slate-400">RESPIRATION:</span>
                <span className="font-mono font-bold text-teal-300">{lungRespirationRate} BPM</span>
                <input
                  type="range"
                  min="10"
                  max="30"
                  value={lungRespirationRate}
                  onChange={(e) => {
                    const rr = Number(e.target.value);
                    setLungRespirationRate(rr);
                    organAudioEngine.updateParameters({ respirationRate: rr });
                  }}
                  className="w-20 accent-teal-400 ml-1 cursor-pointer"
                />
              </div>
            )}

            {selectedOrgan === 'kidneys' && (
              <div className="flex items-center gap-2 bg-[#040812] px-3 py-1.5 rounded-xl border border-emerald-500/30 text-slate-300">
                <Droplets className="w-4 h-4 text-emerald-400" />
                <span className="font-mono text-slate-400">eGFR RATE:</span>
                <span className="font-mono font-bold text-emerald-300">{renalGFR} mL/min</span>
                <input
                  type="range"
                  min="30"
                  max="125"
                  value={renalGFR}
                  onChange={(e) => {
                    const gfr = Number(e.target.value);
                    setRenalGFR(gfr);
                    organAudioEngine.updateParameters({ gfr });
                  }}
                  className="w-20 accent-emerald-400 ml-1 cursor-pointer"
                />
              </div>
            )}

            {selectedOrgan === 'liver' && (
              <div className="flex items-center gap-2 bg-[#040812] px-3 py-1.5 rounded-xl border border-amber-500/30 text-slate-300">
                <Layers className="w-4 h-4 text-amber-400" />
                <span className="font-mono text-slate-400">PORTAL INFLOW:</span>
                <span className="font-mono font-bold text-amber-300">{liverPortalFlow} mL/min</span>
                <input
                  type="range"
                  min="700"
                  max="1500"
                  value={liverPortalFlow}
                  onChange={(e) => {
                    const flow = Number(e.target.value);
                    setLiverPortalFlow(flow);
                    organAudioEngine.updateParameters({ portalFlow: flow });
                  }}
                  className="w-20 accent-amber-400 ml-1 cursor-pointer"
                />
              </div>
            )}

            {selectedOrgan === 'spine' && (
              <div className="flex items-center gap-2 bg-[#040812] px-3 py-1.5 rounded-xl border border-purple-500/30 text-slate-300">
                <Dna className="w-4 h-4 text-purple-400" />
                <span className="font-mono text-slate-400">AXIAL LOAD:</span>
                <span className="font-mono font-bold text-purple-300">{spineAxialLoad} N</span>
                <input
                  type="range"
                  min="400"
                  max="2500"
                  value={spineAxialLoad}
                  onChange={(e) => {
                    const load = Number(e.target.value);
                    setSpineAxialLoad(load);
                    organAudioEngine.updateParameters({ axialLoad: load });
                  }}
                  className="w-20 accent-purple-400 ml-1 cursor-pointer"
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Clinical Workflow Stepper & Tab Navigation */}
      <div className="space-y-3">
        {/* Workflow Progress Steps */}
        <div className="p-3 rounded-2xl bg-[#060b17]/90 border border-white/10 shadow-lg backdrop-blur-md">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-2 px-1">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-cyan-400" />
              <span className="text-xs font-semibold text-slate-200">Multimodal Diagnostic Pathway</span>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => {
                  const steps: WorkspaceTab[] = ['3d-detailing', 'image-analysis', 'predictive-engine', 'diagnostic-report'];
                  const currentIndex = steps.indexOf(workspaceTab);
                  if (currentIndex > 0) setWorkspaceTab(steps[currentIndex - 1]);
                }}
                disabled={workspaceTab === '3d-detailing'}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium text-slate-400 hover:text-white bg-white/5 hover:bg-white/10 disabled:opacity-30 disabled:pointer-events-none transition-all"
              >
                <ArrowLeft className="w-3.5 h-3.5" /> Prev Step
              </button>
              <button
                onClick={() => {
                  const steps: WorkspaceTab[] = ['3d-detailing', 'image-analysis', 'predictive-engine', 'diagnostic-report'];
                  const currentIndex = steps.indexOf(workspaceTab);
                  if (currentIndex < steps.length - 1) setWorkspaceTab(steps[currentIndex + 1]);
                }}
                disabled={workspaceTab === 'diagnostic-report'}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium text-cyan-300 hover:text-white bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/30 disabled:opacity-30 disabled:pointer-events-none transition-all"
              >
                Next Step <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            {[
              { id: '3d-detailing', step: '01', title: '3D Anatomy', subtitle: 'Interactive 8K Atlas', icon: Eye, color: 'text-cyan-400', border: 'border-cyan-500/40' },
              { id: 'image-analysis', step: '02', title: 'Radiology Vision', subtitle: 'DICOM · HU Calipers', icon: Crosshair, color: 'text-emerald-400', border: 'border-emerald-500/40' },
              { id: 'predictive-engine', step: '03', title: 'Risk Predictor', subtitle: 'CAD-RADS · ASPECTS', icon: TrendingUp, color: 'text-purple-400', border: 'border-purple-500/40' },
              { id: 'diagnostic-report', step: '04', title: 'Clinical Report', subtitle: 'Physician & Patient View', icon: FileText, color: 'text-amber-400', border: 'border-amber-500/40' },
            ].map((stepItem) => {
              const StepIcon = stepItem.icon;
              const isCurrent = workspaceTab === stepItem.id;
              return (
                <button
                  key={stepItem.id}
                  onClick={() => setWorkspaceTab(stepItem.id as WorkspaceTab)}
                  className={`relative p-2.5 rounded-xl text-left transition-all border ${
                    isCurrent
                      ? `bg-white/10 ${stepItem.border} shadow-lg ring-1 ring-white/20`
                      : 'bg-[#040813]/60 border-white/5 hover:border-white/20 hover:bg-white/5 text-slate-400'
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className={`text-[10px] font-mono font-bold ${isCurrent ? stepItem.color : 'text-slate-500'}`}>
                      STEP {stepItem.step}
                    </span>
                    <StepIcon className={`w-3.5 h-3.5 ${isCurrent ? stepItem.color : 'text-slate-500'}`} />
                  </div>
                  <div className={`text-xs font-bold truncate ${isCurrent ? 'text-white' : 'text-slate-300'}`}>
                    {stepItem.title}
                  </div>
                  <div className="text-[10px] text-slate-500 truncate font-mono">
                    {stepItem.subtitle}
                  </div>
                  {isCurrent && (
                    <motion.div
                      layoutId="activeStepIndicator"
                      className="absolute bottom-0 left-2 right-2 h-0.5 bg-gradient-to-r from-cyan-400 via-emerald-400 to-purple-400 rounded-full"
                    />
                  )}
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Render Active Workspace Module with Fluid AnimatePresence Transition */}
      <AnimatePresence mode="wait">
        {workspaceTab === 'image-analysis' && (
          <motion.div
            key="image-analysis"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            <ImageAnalysisViewer
              organ={selectedOrgan}
              onOpenPredictor={() => setWorkspaceTab('predictive-engine')}
              onOpenReport={() => setWorkspaceTab('diagnostic-report')}
            />
          </motion.div>
        )}

        {workspaceTab === 'predictive-engine' && (
          <motion.div
            key="predictive-engine"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            <ClinicalPredictor
              organ={selectedOrgan}
              onOpenReport={() => setWorkspaceTab('diagnostic-report')}
            />
          </motion.div>
        )}

        {workspaceTab === 'diagnostic-report' && (
          <motion.div
            key="diagnostic-report"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            <ClinicalReportGenerator
              organ={selectedOrgan}
              onSwitchOrgan={handleOrganSwitch}
            />
          </motion.div>
        )}

        {workspaceTab === '3d-detailing' && (
          <motion.div
            key="3d-detailing"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {/* Real-Time Bioacoustic Organ Auscultation Bar */}
            <OrganAuscultationBar
              currentOrgan={selectedOrgan}
              selectedStructureName={activeStructure?.name}
              heartBPM={heartBPM}
              respirationRate={lungRespirationRate}
              brainWaveBand={brainWaveBand}
              renalGFR={renalGFR}
              liverPortalFlow={liverPortalFlow}
              spineAxialLoad={spineAxialLoad}
              className="mb-6"
            />

            {/* Main Workspace Layout */}
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-6">
            {/* LEFT / CENTER: Interactive Anatomical Stage (7 Columns) */}
            <div className="xl:col-span-7 space-y-4">
              <div className="p-4 sm:p-5 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl relative overflow-hidden">
            {/* Stage Toolbar */}
            <div className="flex items-center justify-between mb-3 text-xs flex-wrap gap-2">
              <div className="flex items-center gap-2">
                <span className="font-mono text-slate-400 uppercase">
                  {selectedOrgan.toUpperCase()} // {viewPerspective.replace('-', ' ').toUpperCase()}
                </span>
                <span className="text-slate-600">•</span>
                <span className="text-emerald-400 font-mono text-[11px] flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Calibrated High-Resolution
                </span>
              </div>

              {/* View, Auscultation & Zoom Controls */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => organAudioEngine.toggleSound(selectedOrgan)}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-xl text-xs font-medium border transition-all ${
                    isAudioPlaying
                      ? 'bg-rose-500/25 border-rose-500/60 text-rose-300 shadow-sm'
                      : 'bg-[#040812] border-white/10 text-slate-400 hover:text-white hover:bg-white/5'
                  }`}
                  title="Toggle real-time organ auscultation sound"
                >
                  <Stethoscope className={`w-3.5 h-3.5 ${isAudioPlaying ? 'text-rose-400 animate-pulse' : 'text-slate-400'}`} />
                  <span className="hidden sm:inline font-mono text-[11px]">
                    {isAudioPlaying ? 'Auscultating' : 'Auscultate'}
                  </span>
                </button>

                <div className="flex items-center gap-1 bg-[#040812] p-1 rounded-xl border border-white/10">
                  <button
                    onClick={() => setZoomLevel((prev) => Math.max(0.8, prev - 0.2))}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10"
                    title="Zoom Out"
                  >
                    <ZoomOut className="w-4 h-4" />
                  </button>
                  <span className="px-2 font-mono text-[11px] text-slate-300">
                    {Math.round(zoomLevel * 100)}%
                  </span>
                  <button
                    onClick={() => setZoomLevel((prev) => Math.min(2.0, prev + 0.2))}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10"
                    title="Zoom In"
                  >
                    <ZoomIn className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => setZoomLevel(1.0)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10"
                    title="Reset Zoom"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Interactive Image Canvas Box */}
            <div
              className="relative w-full aspect-[4/3] rounded-xl overflow-hidden bg-[#03060f] border border-white/10 flex items-center justify-center select-none"
              style={{
                boxShadow:
                  selectedOrgan === 'heart'
                    ? 'inset 0 0 60px rgba(225, 29, 72, 0.15)'
                    : 'inset 0 0 60px rgba(6, 182, 212, 0.15)'
              }}
            >
              {/* Scalable Container with Smooth Pulse Rate */}
              <div
                className="relative w-full h-full transition-transform duration-300 ease-out flex items-center justify-center"
                style={{
                  transform: `scale(${zoomLevel})`
                }}
              >
                {/* Anatomical Image */}
                <img
                  src={getActiveImage()}
                  alt={`High detail ${selectedOrgan} anatomical visualization`}
                  referrerPolicy="no-referrer"
                  className={`w-full h-full object-cover transition-transform duration-700 ${
                    selectedOrgan === 'heart' ? 'hover:scale-[1.02]' : ''
                  }`}
                  style={{
                    animation:
                      selectedOrgan === 'heart'
                        ? `pulseHeart ${60 / heartBPM}s ease-in-out infinite`
                        : undefined
                  }}
                />

                {/* Subdued Diagnostic Grid Overlay */}
                <div
                  className="absolute inset-0 pointer-events-none opacity-20 bg-[linear-gradient(to_right,#ffffff10_1px,transparent_1px),linear-gradient(to_bottom,#ffffff10_1px,transparent_1px)] bg-[size:32px_32px]"
                />

                {/* Simulated Vascular / Conduction Glowing Pathways Overlay */}
                {showElectrophysiology && (
                  <div
                    className="absolute inset-0 pointer-events-none mix-blend-screen opacity-40 transition-opacity"
                    style={{
                      background:
                        selectedOrgan === 'heart'
                          ? 'radial-gradient(circle at 45% 35%, rgba(244,63,94,0.4) 0%, transparent 45%)'
                          : 'radial-gradient(circle at 48% 45%, rgba(6,182,212,0.4) 0%, transparent 55%)'
                    }}
                  />
                )}

                {/* Simulated Stress Heatmap */}
                {showStressHeatmap && (
                  <div className="absolute inset-0 pointer-events-none mix-blend-color-dodge opacity-60 bg-gradient-to-tr from-amber-500/20 via-transparent to-rose-500/30" />
                )}

                {/* Interactive Hotspot Pins */}
                {showHotspotPins &&
                  currentStructures.map((struct) => {
                    const isSelected = struct.id === selectedStructureId;
                    return (
                      <div
                        key={struct.id}
                        onClick={() => {
                          setSelectedStructureId(struct.id);
                          organAudioEngine.playStructureProbeSound(selectedOrgan, struct.name);
                        }}
                        className="absolute cursor-pointer -translate-x-1/2 -translate-y-1/2 group z-20"
                        style={{
                          left: `${struct.xPercent}%`,
                          top: `${struct.yPercent}%`
                        }}
                      >
                        {/* Glowing Ring Animation */}
                        <div
                          className={`w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                            isSelected
                              ? selectedOrgan === 'heart'
                                ? 'bg-rose-500 text-white ring-4 ring-rose-500/40 scale-125'
                                : 'bg-cyan-400 text-black ring-4 ring-cyan-400/40 scale-125'
                              : 'bg-[#050b17]/90 text-white border border-white/40 hover:scale-110 hover:border-cyan-400'
                          }`}
                        >
                          <div
                            className={`w-2 h-2 rounded-full ${
                              isSelected
                                ? selectedOrgan === 'heart'
                                  ? 'bg-white'
                                  : 'bg-black'
                                : selectedOrgan === 'heart'
                                ? 'bg-rose-400'
                                : 'bg-cyan-400'
                            }`}
                          />
                        </div>

                        {/* Tooltip on Hover */}
                        <div className="absolute left-1/2 bottom-full -translate-x-1/2 mb-2 hidden group-hover:block z-30 pointer-events-none">
                          <div className="px-2.5 py-1 rounded-lg bg-[#040812]/95 border border-white/20 text-white text-[11px] font-sans font-medium whitespace-nowrap shadow-xl">
                            {struct.name}
                          </div>
                        </div>
                      </div>
                    );
                  })}
              </div>

              {/* Live Overlay Telemetry Badge */}
              <div className="absolute bottom-3 left-3 bg-[#050914]/90 backdrop-blur-md px-3 py-2 rounded-xl border border-white/10 text-xs font-mono space-y-1">
                <div className="text-[10px] text-slate-400">ACTIVE TARGET</div>
                <div className="text-white font-bold flex items-center gap-1.5">
                  <span
                    className={`w-2 h-2 rounded-full ${
                      selectedOrgan === 'heart' ? 'bg-rose-500' : 'bg-cyan-400'
                    }`}
                  />
                  {activeStructure.name}
                </div>
              </div>

              {/* Status Indicator */}
              <div className="absolute top-3 right-3 bg-[#050914]/80 backdrop-blur-md px-2.5 py-1 rounded-lg border border-white/10 text-[11px] font-mono text-slate-300">
                {selectedOrgan === 'heart' ? (
                  <span>Systolic Pressure Wave: 120 mmHg</span>
                ) : (
                  <span>Cerebral Perfusion: 52 mL/100g/min</span>
                )}
              </div>
            </div>

            {/* Layer Filter Toggles */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-white/10 mt-4 text-xs">
              <span className="text-slate-400 font-mono text-[11px]">DISPLAY LAYERS:</span>
              <div className="flex flex-wrap items-center gap-3">
                <label className="flex items-center gap-1.5 text-slate-300 cursor-pointer hover:text-white">
                  <input
                    type="checkbox"
                    checked={showHotspotPins}
                    onChange={(e) => setShowHotspotPins(e.target.checked)}
                    className="rounded accent-cyan-400"
                  />
                  <span>Hotspot Pins</span>
                </label>
                <label className="flex items-center gap-1.5 text-slate-300 cursor-pointer hover:text-white">
                  <input
                    type="checkbox"
                    checked={showElectrophysiology}
                    onChange={(e) => setShowElectrophysiology(e.target.checked)}
                    className="rounded accent-cyan-400"
                  />
                  <span>{selectedOrgan === 'heart' ? 'Cardiac Conduction' : 'Synaptic Axons'}</span>
                </label>
                <label className="flex items-center gap-1.5 text-slate-300 cursor-pointer hover:text-white">
                  <input
                    type="checkbox"
                    checked={showStressHeatmap}
                    onChange={(e) => setShowStressHeatmap(e.target.checked)}
                    className="rounded accent-cyan-400"
                  />
                  <span>Ischemia / Stress Heatmap</span>
                </label>
              </div>
            </div>
          </div>

          {/* Quick Structure Selector Grid */}
          <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-slate-300">
                Key Anatomical Structures ({currentStructures.length})
              </span>
              <div className="relative w-48">
                <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  placeholder="Search structures..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-8 pr-2.5 py-1 text-xs rounded-lg bg-[#040812] border border-white/10 text-slate-200 placeholder-slate-600 focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {filteredStructures.map((struct) => {
                const isSelected = struct.id === selectedStructureId;
                return (
                  <button
                    key={struct.id}
                    onClick={() => {
                      setSelectedStructureId(struct.id);
                      organAudioEngine.playStructureProbeSound(selectedOrgan, struct.name);
                    }}
                    className={`p-2.5 rounded-xl border text-left transition-all ${
                      isSelected
                        ? selectedOrgan === 'heart'
                          ? 'bg-rose-500/20 border-rose-500 text-white font-semibold'
                          : 'bg-cyan-500/20 border-cyan-500 text-white font-semibold'
                        : 'bg-[#040812] border-white/5 text-slate-400 hover:text-slate-200 hover:border-white/20'
                    }`}
                  >
                    <div className="text-xs truncate">{struct.name}</div>
                    <div className="text-[10px] font-mono text-slate-500 truncate italic">
                      {struct.latinName}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: Full Detail Card & Clinical Inspector (5 Columns) */}
        <div className="xl:col-span-5 space-y-4">
          <div className="p-5 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-5">
            {/* Header: Name, Latin nomenclature, and system */}
            <div className="border-b border-white/10 pb-4">
              <div className="flex items-center justify-between text-xs font-mono mb-1.5 flex-wrap gap-2">
                <span className="px-2 py-0.5 rounded bg-white/5 text-slate-400">
                  {activeStructure.system}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      organAudioEngine.playStructureProbeSound(selectedOrgan, activeStructure.name);
                    }}
                    className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-lg bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/30 text-cyan-300 text-[11px] font-mono transition-all"
                    title="Play acoustic bio-probe tone for this anatomical landmark"
                  >
                    <Stethoscope className="w-3 h-3 text-cyan-400" />
                    <span>Acoustic Probe</span>
                  </button>
                  <span className="text-emerald-400 flex items-center gap-1 text-[11px]">
                    <CheckCircle2 className="w-3 h-3" /> Normal Morphology
                  </span>
                </div>
              </div>
              <h2 className="text-xl font-bold text-white tracking-tight mt-1">
                {activeStructure.name}
              </h2>
              <div className="text-xs font-serif italic text-cyan-400 mt-0.5">
                {activeStructure.latinName}
              </div>
            </div>

            {/* Functional Anatomy Summary */}
            <div className="space-y-1.5">
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <Info className="w-4 h-4 text-cyan-400" />
                Functional Anatomy & Physiological Mechanism
              </div>
              <p className="text-xs text-slate-300 leading-relaxed bg-[#040812] p-3 rounded-xl border border-white/5">
                {activeStructure.functionSummary}
              </p>
            </div>

            {/* Real-Time Physiological & Morphometric Metrics */}
            <div className="space-y-2">
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-300 flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-emerald-400" />
                Standard Physiological Benchmarks
              </div>
              <div className="grid grid-cols-1 gap-2">
                {Object.entries(activeStructure.physiologicalMetrics).map(([metricKey, metricValue]) => (
                  <div
                    key={metricKey}
                    className="p-2.5 rounded-xl bg-[#040812] border border-white/5 flex items-center justify-between text-xs"
                  >
                    <span className="text-slate-400">{metricKey}</span>
                    <span className="font-mono font-bold text-white text-right ml-2">
                      {metricValue}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Clinical Pathology & High-Risk Anomalies */}
            <div className="space-y-2">
              <div className="text-xs font-semibold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-400" />
                Pathology & Clinical Vulnerabilities
              </div>
              <div className="p-3 rounded-xl bg-amber-950/15 border border-amber-500/30 text-xs space-y-1.5">
                <p className="text-slate-300 leading-relaxed">
                  {activeStructure.clinicalSignificance}
                </p>
                <div className="pt-2 border-t border-amber-500/20 text-[11px] font-mono text-amber-300">
                  <strong>Common Diagnoses:</strong> {activeStructure.commonPathology}
                </div>
              </div>
            </div>

            {/* Interventions & Surgical Procedures */}
            <div className="space-y-2">
              <div className="text-xs font-semibold uppercase tracking-wider text-purple-300 flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-purple-400" />
                Interventions & Clinical Therapeutics
              </div>
              <div className="p-3 rounded-xl bg-purple-950/15 border border-purple-500/30 text-xs text-slate-300 leading-relaxed">
                {activeStructure.interventions}
              </div>
            </div>

            {/* Vascular / Neural Innervation */}
            {activeStructure.bloodSupplyOrNerve && (
              <div className="p-3 rounded-xl bg-[#040812] border border-white/5 text-xs text-slate-400 space-y-1">
                <div className="font-mono text-[10px] text-slate-500 uppercase">
                  Vascular Perfusion / Innervation
                </div>
                <div className="text-slate-200">{activeStructure.bloodSupplyOrNerve}</div>
              </div>
            )}
          </div>
        </div>
      </div>
      </motion.div>
      )}
      </AnimatePresence>

      {/* Global CSS for Cardiac Pulsation Animation */}
      <style>{`
        @keyframes pulseHeart {
          0% {
            transform: scale(1);
          }
          15% {
            transform: scale(1.028);
          }
          28% {
            transform: scale(0.995);
          }
          40% {
            transform: scale(1.018);
          }
          100% {
            transform: scale(1);
          }
        }
      `}</style>
    </div>
  );
};
