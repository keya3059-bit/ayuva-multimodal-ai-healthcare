export interface AnatomicalStructure {
  id: string;
  name: string;
  latinName: string;
  system: string;
  xPercent: number;
  yPercent: number;
  functionSummary: string;
  physiologicalMetrics: { [key: string]: string };
  clinicalSignificance: string;
  commonPathology: string;
  interventions: string;
  bloodSupplyOrNerve?: string;
}

// -------------------------------------------------------------
// 1. HUMAN HEART & CORONARY ARTERY TREE
// -------------------------------------------------------------
export const HEART_STRUCTURES: AnatomicalStructure[] = [
  {
    id: 'aortic-arch',
    name: 'Aortic Arch & Ascending Aorta',
    latinName: 'Arcus aortae',
    system: 'Systemic High-Pressure Arterial Tree',
    xPercent: 50,
    yPercent: 17,
    functionSummary: 'Distributes oxygenated blood pumped from the left ventricle under pulsatile systolic pressure to the systemic arterial circulation. Baroreceptors in the aortic arch provide continuous vagal baroreflex blood pressure regulation.',
    physiologicalMetrics: {
      'Systolic / Diastolic Pressure': '120 / 80 mmHg',
      'Mean Arterial Pressure': '93.3 mmHg',
      'Ascending Diameter': '28 - 34 mm',
      'Pulse Wave Velocity': '6.2 m/s (healthy compliance)',
      'Cardiac Output Ejected': '5.0 - 5.5 L/min'
    },
    clinicalSignificance: 'Subject to intense hemodynamic shear stress. Atherosclerosis, ascending aortic aneurysm, or acute Stanford Type A dissection require emergency cardiovascular surgery.',
    commonPathology: 'Aortic Dissection, Thoracic Aortic Aneurysm, Coarctation of the Aorta, Atherosclerotic Calcification.',
    interventions: 'Endovascular Aortic Repair (TEVAR), Bentall procedure with prosthetic graft, valve-sparing aortic root replacement.',
    bloodSupplyOrNerve: 'Coronary ostia originate directly from left and right sinuses of Valsalva.'
  },
  {
    id: 'left-anterior-descending',
    name: 'Left Anterior Descending (LAD) Artery',
    latinName: 'Ramus interventricularis anterior',
    system: 'Coronary Arterial Perfusion Network',
    xPercent: 54,
    yPercent: 54,
    functionSummary: 'The anterior interventricular branch of the Left Coronary Artery, critically dubbed the "Widowmaker" artery. Supplies ~50% of the entire left ventricular myocardium, anterior 2/3 of the interventricular septum, and cardiac conduction bundle branches.',
    physiologicalMetrics: {
      'Coronary Perfusion Velocity': '35 - 45 cm/s (diastolic dominant)',
      'Lumen Diameter': '3.5 - 4.2 mm',
      'Fractional Flow Reserve (FFR)': '0.94 (Optimal > 0.80)',
      'Stenosis Risk Rating': '12% Nominal / No critical plaque',
      'Myocardial Territory Fed': 'Anterior LV Wall & Apical Cap'
    },
    clinicalSignificance: 'Acute thrombotic occlusion results in acute anterior STEMI with rapid risk of cardiogenic shock, ventricular fibrillation, or left ventricular free wall rupture.',
    commonPathology: 'Atherosclerotic CAD, Plaque Rupture, Acute STEMI, Spontaneous Coronary Artery Dissection (SCAD).',
    interventions: 'Percutaneous Coronary Intervention (PCI) with Drug-Eluting Stent (DES), Coronary Artery Bypass Graft (LIMA-to-LAD bypass).',
    bloodSupplyOrNerve: 'Originates from the Left Main Coronary Artery (LMCA).'
  },
  {
    id: 'left-ventricle',
    name: 'Left Ventricle (LV) & Myocardium',
    latinName: 'Ventriculus sinister cordis',
    system: 'High-Pressure Systemic Cardiac Pump',
    xPercent: 66,
    yPercent: 66,
    functionSummary: 'The thickest and most powerful muscular chamber of the heart. Forces oxygenated blood across the aortic valve into the systemic circuit against total peripheral resistance (SVR). Wall thickness is 3x that of the right ventricle.',
    physiologicalMetrics: {
      'Left Ventricular Ejection Fraction (LVEF)': '64% (Normal 55-70%)',
      'Stroke Volume (SV)': '72 mL / beat',
      'End-Diastolic Volume (LVEDV)': '118 mL',
      'End-Systolic Volume (LVESV)': '46 mL',
      'Myocardial Wall Thickness': '10.5 mm (Diastole)'
    },
    clinicalSignificance: 'Chronic hypertension causes left ventricular concentric hypertrophy. Ischemia or dilated cardiomyopathy triggers Heart Failure with Reduced Ejection Fraction (HFrEF).',
    commonPathology: 'Left Heart Failure, Hypertrophic Cardiomyopathy (HCM), Dilated Cardiomyopathy, Ischemic Apical Aneurysm.',
    interventions: 'ACE inhibitors/ARBs, SGLT2 inhibitors, CRT-D Cardiac Resynchronization, Left Ventricular Assist Device (LVAD).',
    bloodSupplyOrNerve: 'LAD artery and Left Circumflex (LCx) artery.'
  },
  {
    id: 'right-atrium-svc',
    name: 'Right Atrium & Superior Vena Cava',
    latinName: 'Atrium dextrum & Vena cava superior',
    system: 'Low-Pressure Venous Return Basin',
    xPercent: 32,
    yPercent: 28,
    functionSummary: 'Receives deoxygenated venous blood returning from the upper body (via SVC), lower body (via IVC), and the cardiac myocardium (via coronary sinus). Houses the sinoatrial node in its upper lateral wall.',
    physiologicalMetrics: {
      'Central Venous Pressure (CVP)': '5.5 mmHg (Normal 2-8 mmHg)',
      'Right Atrial Volume Index': '24 mL/m²',
      'Venous Return Saturation (SvO₂)': '73%',
      'Tricuspid Inflow Velocity': '0.55 m/s',
      'Intrinsic Pacing Rate': '60 - 100 action potentials/min'
    },
    clinicalSignificance: 'Right atrial dilatation occurs in pulmonary arterial hypertension, tricuspid regurgitation, or atrial septal defects (ASD). Susceptible to atrial flutter and fibrillation foci.',
    commonPathology: 'Atrial Flutter, Sinus Node Dysfunction, Atrial Septal Defect (Secundum ASD), Right Atrial Myxoma.',
    interventions: 'Catheter ablation of cavotricuspid isthmus (CTI), pacemaker lead implantation, percutaneous ASD closure occluder.',
    bloodSupplyOrNerve: 'Sinoatrial nodal branch off Right Coronary Artery (RCA).'
  },
  {
    id: 'right-ventricle',
    name: 'Right Ventricle (RV)',
    latinName: 'Ventriculus dexter cordis',
    system: 'Pulmonary Low-Pressure Circuit Pump',
    xPercent: 38,
    yPercent: 62,
    functionSummary: 'Crescent-shaped, thin-walled chamber designed to handle high compliance and low resistance in the pulmonary vascular tree. Pumps deoxygenated blood through the pulmonary valve into the pulmonary arteries.',
    physiologicalMetrics: {
      'Systolic RV Pressure': '23 mmHg',
      'Diastolic RV Pressure': '3 mmHg',
      'TAPSE (Tricuspid Annular Plane Excursion)': '22 mm (Normal > 17 mm)',
      'Myocardial Wall Thickness': '3.8 mm',
      'Pulmonary Vascular Resistance (PVR)': '1.2 Wood Units'
    },
    clinicalSignificance: 'Vulnerable to acute pressure overload in massive pulmonary embolism (causing acute cor pulmonale) and arrhythmogenic right ventricular cardiomyopathy (ARVC).',
    commonPathology: 'Cor Pulmonale, RV Infarction (proximal RCA occlusion), Tricuspid Insufficiency, Tetralogy of Fallot.',
    interventions: 'Pulmonary thrombectomy, right ventricular inotropic support (milrinone), inhaled nitric oxide for pulmonary hypertension.',
    bloodSupplyOrNerve: 'Right Marginal Branch and Posterior Descending Artery (PDA) from RCA.'
  },
  {
    id: 'mitral-valve',
    name: 'Mitral (Bicuspid) Valve & Chordae',
    latinName: 'Valva bicuspidalis / mitralis',
    system: 'Atrioventricular Regurgitation Barrier',
    xPercent: 60,
    yPercent: 46,
    functionSummary: 'Dual-leaflet valve (anterior and posterior leaflets) anchored by fibrous chordae tendineae to papillary muscles. Seals during ventricular systole to prevent backflow into the pulmonary venous circulation.',
    physiologicalMetrics: {
      'Mitral Orifice Area': '4.8 cm² (Normal 4.0-6.0 cm²)',
      'Transvalvular Mean Gradient': '1.8 mmHg',
      'Regurgitant Fraction': '< 5% (Trace/Physiologic)',
      'E/A Ratio': '1.3 (Normal diastolic filling)',
      'Closure Timing': 'Initiates First Heart Sound (S1 Lub)'
    },
    clinicalSignificance: 'Degeneration of chordae leads to mitral valve prolapse (MVP) or acute flail leaflet with pulmonary edema. Rheumatic fever classically causes mitral stenosis.',
    commonPathology: 'Mitral Regurgitation (MR), Mitral Valve Prolapse (Barlow syndrome), Mitral Stenosis, Infective Endocarditis.',
    interventions: 'Transcatheter Edge-to-Edge Repair (MitraClip), minimally invasive mitral annuloplasty ring repair, mechanical/bioprosthetic valve replacement.',
    bloodSupplyOrNerve: 'Papillary muscles receive blood from LAD, Circumflex, and PDA.'
  },
  {
    id: 'conduction-system',
    name: 'Cardiac Conduction Axis (SA & AV Nodes, Purkinje)',
    latinName: 'Systema conducens cordis',
    system: 'Intrinsic Cardiac Electrophysiology Network',
    xPercent: 44,
    yPercent: 36,
    functionSummary: 'The electrical wiring of the heart. Action potentials originate at the Sinoatrial (SA) node, propagate across internodal tracts to the AV node (0.12s physiological delay for ventricular filling), down the Bundle of His and Purkinje fibers to trigger coordinated ventricular systole.',
    physiologicalMetrics: {
      'SA Node Intrinsic Pacing': '72 BPM',
      'PR Interval': '158 ms (Normal 120-200 ms)',
      'QRS Complex Duration': '86 ms (Normal < 120 ms)',
      'Purkinje Conduction Velocity': '4.0 m/s (Fastest in body)',
      'QTc Interval': '412 ms (Bazzet corrected, normal < 440 ms)'
    },
    clinicalSignificance: 'Conduction block at the AV node produces 1st, 2nd, or 3rd degree heart block. Ectopic pacemakers can trigger re-entrant SVT, ventricular tachycardia (VT), or lethal VF.',
    commonPathology: 'Sick Sinus Syndrome, 3rd Degree Complete Heart Block, Wolff-Parkinson-White (WPW) bypass tract, Long QT Syndrome.',
    interventions: 'Permanent dual-chamber pacemaker (PPM), Implantable Cardioverter-Defibrillator (ICD), electrophysiology radiofrequency ablation.',
    bloodSupplyOrNerve: 'AV nodal artery arises from RCA in 90% of individuals (right dominant).'
  }
];

// -------------------------------------------------------------
// 2. HUMAN BRAIN & NEURAL LOBES
// -------------------------------------------------------------
export const BRAIN_STRUCTURES: AnatomicalStructure[] = [
  {
    id: 'prefrontal-cortex',
    name: 'Prefrontal Cortex (Frontal Lobe)',
    latinName: 'Cortex praefrontalis (Brodmann 9, 10, 11, 46)',
    system: 'Executive Cognitive & Neuromodulation Network',
    xPercent: 30,
    yPercent: 34,
    functionSummary: 'The seat of higher executive cognitive architecture: abstract reasoning, prospective memory, decision-making, emotional regulation, impulse suppression, and personality expression. Coordinates dorsal-lateral and orbitofrontal circuits.',
    physiologicalMetrics: {
      'Dopamine D1/D2 Receptor Density': 'High (Mesocortical pathway)',
      'Resting Glucose Utilization': '28% of total cerebral glucose pool',
      'EEG Dominant Activity': 'Beta (16-22 Hz) during analytical tasks',
      'Cortical Thickness': '3.2 - 4.1 mm',
      'Synaptic Spines per Neuron': '~7,000 synaptic inputs'
    },
    clinicalSignificance: 'Vulnerable to closed-head traumatic brain injury (TBI) contrecoup injuries. Hypofrontality is linked to major depressive disorder, ADHD, and frontotemporal dementia (FTD).',
    commonPathology: 'Frontotemporal Lobar Degeneration (Pick Disease), Prefrontal Syndrome, Chronic Traumatic Encephalopathy (CTE), Dysexecutive Syndrome.',
    interventions: 'Repetitive Transcranial Magnetic Stimulation (rTMS), cognitive remediation therapy, dopaminergic and noradrenergic pharmacotherapy.',
    bloodSupplyOrNerve: 'Anterior Cerebral Artery (ACA) and Anterior Division of Middle Cerebral Artery (MCA).'
  },
  {
    id: 'motor-somatosensory',
    name: 'Primary Motor & Somatosensory Strips',
    latinName: 'Gyrus praecentralis & postcentralis (BA 4 & 1, 2, 3)',
    system: 'Sensorimotor Pyramidal & Lemniscal Homunculus',
    xPercent: 50,
    yPercent: 26,
    functionSummary: 'Comprises the precentral gyrus (primary motor cortex sending corticospinal tract efferents via giant Betz cells) and postcentral gyrus (primary somatosensory cortex receiving spinothalamic and dorsal column touch/pain afferents). Mapped to the cortical homunculus.',
    physiologicalMetrics: {
      'Corticospinal Conduction Speed': '60 - 80 m/s',
      'Sensory Latency (SSEP)': '19.8 ms (N20 cortical response)',
      'Cortical Layer V Betz Cells': 'Largest pyramidal neurons in CNS (up to 100 µm)',
      'Spatial Tactile Acuity (Fingertips)': '1.5 mm two-point discrimination'
    },
    clinicalSignificance: 'Lesions or MCA ischemic stroke cause contralateral hemiparesis and hemisensory loss, predominantly sparing the leg (which is supplied medially by the ACA).',
    commonPathology: 'MCA Ischemic Infarction, Jacksonian March Focal Seizures, Cerebral Palsy, Primary Glioma.',
    interventions: 'Endovascular Thrombectomy (EVT), IV Alteplase (tPA) within 4.5 hr window, robotic neuro-rehabilitation therapy.',
    bloodSupplyOrNerve: 'Middle Cerebral Artery (MCA superior division).'
  },
  {
    id: 'temporal-wernicke',
    name: 'Temporal Lobe & Wernicke Speech Area',
    latinName: 'Lobus temporalis & Area Wernickensis (BA 22, 41, 42)',
    system: 'Receptive Language, Auditory & Semantic Network',
    xPercent: 40,
    yPercent: 54,
    functionSummary: 'Specialized for auditory perception, complex speech decoding, semantic memory, and emotional labeling. Houses Wernicke\'s area in the dominant left posterior superior temporal gyrus, connected to Broca\'s area via the arcuate fasciculus.',
    physiologicalMetrics: {
      'Phonetic Processing Latency': '100 - 200 ms (N100/P200 auditory potential)',
      'Primary Tonotopic Range': '20 Hz to 20,000 Hz',
      'Language Dominance': 'Left hemisphere in 96% of right-handed individuals',
      'Cerebral Blood Flow': '54 mL / 100g brain tissue / min'
    },
    clinicalSignificance: 'Damage causes fluent Wernicke\'s receptive aphasia ("word salad" with impaired comprehension but fluent syntax). Mesial temporal lobe is the most common focus of adult refractory epilepsy.',
    commonPathology: 'Wernicke Aphasia, Mesial Temporal Sclerosis (MTS), Complex Partial Seizures, Herpes Simplex Encephalitis.',
    interventions: 'Selective laser amygdalohippocampotomy, Responsive Neurostimulation (RNS), speech-language pathology.',
    bloodSupplyOrNerve: 'Inferior division of the Middle Cerebral Artery (MCA) and Posterior Cerebral Artery (PCA).'
  },
  {
    id: 'hippocampus-limbic',
    name: 'Hippocampus & Limbic Memory Circuit',
    latinName: 'Hippocampus (Cornu Ammonis CA1-CA4, Gyrus dentatus)',
    system: 'Episodic Memory Consolidation & Spatial Grid Architecture',
    xPercent: 50,
    yPercent: 62,
    functionSummary: 'Seahorse-shaped archicortex curled inside the medial temporal lobe. Fundamental for converting short-term working memory into long-term declarative memories via Long-Term Potentiation (LTP). Contains place cells for spatial navigation.',
    physiologicalMetrics: {
      'Adult Neurogenesis Rate': '~700 new granule cells/day in dentate gyrus',
      'Theta Oscillation Wave': '4 - 8 Hz (Memory encoding frequency)',
      'Synaptic Plasticity (LTP)': 'NMDA receptor dependent calcium influx',
      'Bilateral Volume': '3.8 - 4.4 cm³ per hemisphere'
    },
    clinicalSignificance: 'The earliest and most severely degraded structure in Alzheimer\'s disease, characterized by amyloid-beta plaques and hyperphosphorylated tau neurofibrillary tangles.',
    commonPathology: 'Alzheimer\'s Disease, Korsakoff Psychosis, Anoxic Hippocampal Sclerosis, Post-Traumatic Stress Disorder (PTSD).',
    interventions: 'Cholinesterase inhibitors (Donepezil), NMDA antagonists (Memantine), Anti-amyloid monoclonal antibodies (Lecanemab).',
    bloodSupplyOrNerve: 'Anterior choroidal artery and hippocampal branches of the Posterior Cerebral Artery (PCA).'
  },
  {
    id: 'cerebellum',
    name: 'Cerebellum & Purkinje Layer',
    latinName: 'Cerebellum (Arbor vitae & Nuclei cerebellares)',
    system: 'Motor Calibration, Vestibular Balance & Timing Loop',
    xPercent: 74,
    yPercent: 72,
    functionSummary: 'Although accounting for only 10% of total brain volume, the cerebellum contains over 50% of the entire brain\'s 86 billion neurons. Calculates real-time sensory-motor error corrections, procedural muscle memory, and vestibulocochlear equilibrium.',
    physiologicalMetrics: {
      'Total Neuron Count': '~50 billion neurons (predominantly granule cells)',
      'Purkinje Cell Dendritic Trees': 'Up to 200,000 synaptic spines each',
      'Firing Rate of Purkinje Cells': '50 - 100 Hz intrinsic pacemaker spikes',
      'Feedback Latency': '< 15 ms cerebellar loop correction'
    },
    clinicalSignificance: 'Lesions produce classic cerebellar ataxia: dysmetria (past-pointing), intention tremor, dysdiadochokinesia, and scanning dysarthric speech without muscular weakness.',
    commonPathology: 'Cerebellar Ataxia, Chiari Malformation, Spinocerebellar Ataxia (SCA), PICA cerebellar ischemic stroke.',
    interventions: 'Vestibular physical rehabilitation, suboccipital decompressive craniectomy for acute cerebellar swelling/edema.',
    bloodSupplyOrNerve: 'PICA (Posterior Inferior Cerebellar), AICA, and Superior Cerebellar Artery (SCA).'
  },
  {
    id: 'brainstem',
    name: 'Brainstem (Midbrain, Pons & Medulla Oblongata)',
    latinName: 'Truncus encephali',
    system: 'Autonomic Vital Reflex & Ascending Arousal Hub',
    xPercent: 52,
    yPercent: 82,
    functionSummary: 'The critical conduit connecting the cerebrum to the spinal cord. Houses the Reticular Activating System (RAS for consciousness) and cranial nerve nuclei III through XII. Houses medullary respiratory rhythm generators and cardiovascular vasopressor reflex centers.',
    physiologicalMetrics: {
      'Respiratory Drive Center': 'Pre-Bötzinger complex inspiratory rhythm generator',
      'Cardiovascular Baroreflex': 'Nucleus tractus solitarii (NTS) mediated vagal tone',
      'Ascending Reticular Drive': 'Maintains wakefulness and alert cortical state',
      'Cranial Nerve Nuclei': '10 of 12 cranial nerves originate directly here'
    },
    clinicalSignificance: 'Damage is rapidly fatal due to loss of spontaneous respiratory drive or acute neurogenic shock. Brainstem herniation (uncal or tonsillar) from elevated ICP is a neurosurgical emergency.',
    commonPathology: 'Locked-in Syndrome (Basilar artery thrombosis), Wallenberg Lateral Medullary Syndrome, Brainstem Glioma, Herniation.',
    interventions: 'Emergency hyperosmolar therapy (Mannitol / 3% hypertonic saline), emergent basilar artery stent-thrombectomy.',
    bloodSupplyOrNerve: 'Basilar artery, Vertebral arteries, and pontine perforating branches.'
  },
  {
    id: 'corpus-callosum',
    name: 'Corpus Callosum & Commissural Tracts',
    latinName: 'Corpus callosum (Rostrum, Genu, Truncus, Splenium)',
    system: 'Interhemispheric Transcortical Axonal Highway',
    xPercent: 48,
    yPercent: 42,
    functionSummary: 'The largest white matter fiber tract in the human brain, containing over 200 million heavily myelinated nerve fibers connecting homologous regions of the left and right cerebral hemispheres for unified bilateral perception and coordination.',
    physiologicalMetrics: {
      'Total Axonal Fiber Count': '200 to 250 million myelinated axons',
      'Axonal Conduction Velocity': '10 - 40 m/s',
      'Cross-Sectional Area': '5.5 - 7.0 cm²',
      'Myelination Maturation': 'Continues through early adulthood (~25 years)'
    },
    clinicalSignificance: 'Surgical transection (corpus callosotomy) for refractory intractable drop-attack epilepsy results in "split-brain" syndrome, revealing hemispheric specialization and alien hand phenomenon.',
    commonPathology: 'Agenesis of the Corpus Callosum (ACC), Marchiafava-Bignami Disease, Butterfly Glioblastoma, Diffuse Axonal Injury (DAI).',
    interventions: 'Corpus callosotomy for drop seizures, diffusion tensor tractography (DTI) MRI surgical trajectory planning.',
    bloodSupplyOrNerve: 'Pericallosal artery (branch of Anterior Cerebral Artery).'
  }
];

// -------------------------------------------------------------
// 3. HUMAN LUNGS & RESPIRATORY TREE
// -------------------------------------------------------------
export const LUNGS_STRUCTURES: AnatomicalStructure[] = [
  {
    id: 'trachea-carina',
    name: 'Trachea & Carina Bifurcation',
    latinName: 'Trachea & Carina tracheae',
    system: 'Primary Upper Airway Conduit',
    xPercent: 50,
    yPercent: 20,
    functionSummary: 'Fibrocartilaginous tube with 16-20 C-shaped hyaline cartilage rings keeping lumen patent under negative intrathoracic pressures. Bifurcates at the carina (T4/T5 level) with richly sensitive cough receptors.',
    physiologicalMetrics: {
      'Internal Diameter': '18 - 22 mm',
      'Ciliary Beat Frequency': '12 - 15 Hz (Mucociliary escalator)',
      'Anatomical Dead Space': '150 mL (conducting zone)',
      'Airflow Peak Velocity': '1.5 - 2.5 m/s tidal / > 25 m/s cough'
    },
    clinicalSignificance: 'Carinal widening on chest radiograph indicates subcarinal subcarinal lymphadenopathy (bronchogenic carcinoma). Aspiration typically lodges in right bronchus due to vertical angulation.',
    commonPathology: 'Tracheomalacia, Tracheal Stenosis (post-intubation), Foreign Body Aspiration, Tracheobronchitis.',
    interventions: 'Rigid bronchoscopic dilation, tracheal stent placement, surgical slide tracheoplasty.',
    bloodSupplyOrNerve: 'Inferior thyroid arteries; recurrent laryngeal nerves and pulmonary plexus.'
  },
  {
    id: 'right-lung-bronchial',
    name: 'Right Lung & Trilobed Bronchial Tree',
    latinName: 'Pulmo dexter (Lobus superior, medius, inferior)',
    system: 'Pulmonary Ventilation & Gas Exchange Reservoir',
    xPercent: 32,
    yPercent: 52,
    functionSummary: 'Heavier and broader than the left lung. Contains 3 distinct lobes (Superior, Middle, Inferior) divided by the horizontal and oblique fissures. Accommodates 55% of total pulmonary ventilatory volume.',
    physiologicalMetrics: {
      'Total Lung Capacity (TLC)': '3.2 L (Right lung alone)',
      'Ventilation-Perfusion (V/Q)': '0.82 mean ratio',
      'Pulmonary Arterial Pressure': '14 mmHg mean (systolic 22 / diastolic 8)',
      'Bronchopulmonary Segments': '10 distinct surgical segments'
    },
    clinicalSignificance: 'Right middle lobe syndrome occurs due to extrinsic lymph node compression of the long, narrow middle lobe bronchus. Lobar pneumonia frequently consolidates here.',
    commonPathology: 'Right Middle Lobe Syndrome, Aspiration Pneumonia, Pulmonary Embolism, Bronchiectasis.',
    interventions: 'Video-Assisted Thoracoscopic Surgery (VATS) lobectomy, high-frequency chest wall oscillation, targeted antibiotic nebulization.',
    bloodSupplyOrNerve: 'Single right bronchial artery from 3rd posterior intercostal artery.'
  },
  {
    id: 'left-lung-cardiac-notch',
    name: 'Left Lung & Lingula / Cardiac Notch',
    latinName: 'Pulmo sinister & Incisura cardiaca',
    system: 'Left Ventilatory Cavity & Mediastinal Interface',
    xPercent: 68,
    yPercent: 54,
    functionSummary: 'Composed of 2 lobes (Superior and Inferior) separated by the oblique fissure. Features the cardiac impression and lingula (homologue of right middle lobe). Shaped around cardiac silhouette.',
    physiologicalMetrics: {
      'Lung Volume': '~45% of total pulmonary capacity',
      'FEV1 Contribution': '1.8 L (in typical 3.8 L vital capacity)',
      'Alveolar Surface Area': '~65 m² surface area for diffusion',
      'Diffusion Capacity (DLCO)': '28 mL/min/mmHg (Normal > 80% pred)'
    },
    clinicalSignificance: 'Severe left ventricular enlargement can compress left lower lobe bronchus (Ortner syndrome variant), producing atelectasis. Pancoast tumors at apical sulcus invade brachial plexus.',
    commonPathology: 'Bronchogenic Carcinoma, Idiopathic Pulmonary Fibrosis (IPF), Pneumothorax, Bullous Emphysema.',
    interventions: 'Stereotactic Body Radiation Therapy (SBRT), pleurodesis for recurrent pneumothorax, pulmonary rehabilitation.',
    bloodSupplyOrNerve: 'Two left bronchial arteries arising directly from thoracic descending aorta.'
  },
  {
    id: 'alveolar-membrane',
    name: 'Alveolar-Capillary Gas Exchange Interface',
    latinName: 'Septum interalveolare & Membrana respiratoria',
    system: 'Microvascular Diffusive Blood-Gas Barrier',
    xPercent: 52,
    yPercent: 72,
    functionSummary: 'The ultra-thin biological interface (0.2 - 0.5 µm thickness) where alveolar oxygen diffuses into red blood cell hemoglobin and carbon dioxide is expelled. Lined by Type I pneumocytes (95% surface) and Type II pneumocytes producing dipalmitoylphosphatidylcholine surfactant.',
    physiologicalMetrics: {
      'Total Alveoli Count': '480 - 500 million alveoli',
      'Gas Barrier Thickness': '0.3 µm (allows 0.25s capillary transit saturation)',
      'Alveolar PO₂ (PAO₂)': '102 mmHg (at room air FiO₂ 21%)',
      'Surface Tension Reduction': 'From 70 mN/m down to < 5 mN/m via surfactant',
      'Capillary Transit Time': '0.75 s resting / 0.25 s exercise'
    },
    clinicalSignificance: 'Damage to the alveolar-capillary barrier causes non-cardiogenic pulmonary edema and Acute Respiratory Distress Syndrome (ARDS) with severe refractory shunt hypoxemia.',
    commonPathology: 'ARDS, COVID-19 Acute Lung Injury, Idiopathic Pulmonary Hemosiderosis, Neonatal RDS.',
    interventions: 'Lung-protective mechanical ventilation (6 mL/kg PBW, PEEP titration), prone positioning, inhaled epoprostenol, ECMO.',
    bloodSupplyOrNerve: 'Pulmonary capillary dense plexus fed by pulmonary arterioles.'
  },
  {
    id: 'pulmonary-vasculature',
    name: 'Pulmonary Arterial & Venous Network',
    latinName: 'Truncus pulmonalis & Venae pulmonales',
    system: 'Low-Pressure High-Capacitance Pulmonary Circuit',
    xPercent: 48,
    yPercent: 40,
    functionSummary: 'Carries entire right ventricular stroke volume through the pulmonary arterial bed for oxygenation, returning via 4 pulmonary veins (right/left superior/inferior) directly into the left atrium.',
    physiologicalMetrics: {
      'Pulmonary Blood Flow': '5.0 L/min (equivalent to total cardiac output)',
      'Pulmonary Capillary Wedge Pressure (PCWP)': '8 - 12 mmHg',
      'Pulmonary Artery Systolic': '20 - 25 mmHg',
      'Hypoxic Pulmonary Vasoconstriction (HPV)': 'Diverts blood away from unventilated zones'
    },
    clinicalSignificance: 'Obstruction by saddle embolus causes acute obstructive shock and RV strain (S1Q3T3). Chronic thromboembolic pulmonary hypertension (CTEPH) leads to fatal right heart failure.',
    commonPathology: 'Pulmonary Arterial Hypertension (PAH), Pulmonary Embolism (PE), Pulmonary Arteriovenous Malformation (PAVM).',
    interventions: 'Catheter-directed mechanical thrombectomy, pulmonary endarterectomy (PEA), phosphodiesterase-5 inhibitors (Sildenafil).',
    bloodSupplyOrNerve: 'Right and Left Pulmonary Arteries.'
  },
  {
    id: 'pleural-cavity',
    name: 'Visceral & Parietal Pleura / Costophrenic Angle',
    latinName: 'Cavitas pleuralis & Recessus costodiaphragmaticus',
    system: 'Intrathoracic Lubrication & Negative Pressure Seal',
    xPercent: 24,
    yPercent: 78,
    functionSummary: 'Double-layered serous membrane sealing lungs to the thoracic rib cage. Generates negative intrapleural pressure (-5 to -8 cmH₂O during inspiration) that mechanically expands lung parenchyma during diaphragmatic descent.',
    physiologicalMetrics: {
      'Pleural Fluid Volume': '10 - 15 mL physiological serous fluid',
      'Intrapleural Pressure': '-5 cmH₂O end-expiration / -8 cmH₂O end-inspiration',
      'Fluid Production / Clearance': '0.15 mL/kg/hour turnover',
      'Costophrenic Depth': '5 cm reserve space'
    },
    clinicalSignificance: 'Blunting of costophrenic angles on chest radiograph requires > 175 mL fluid accumulation. Tension pneumothorax collapses IVC return, precipitating cardiac arrest.',
    commonPathology: 'Pleural Effusion (Transudate vs Exudate Light\'s criteria), Empyema, Mesothelioma, Hemothorax.',
    interventions: 'Thoracentesis, intercostal chest tube (pig-tail 14Fr or large-bore 28Fr), intrapleural tPA/DNase.',
    bloodSupplyOrNerve: 'Intercostal and internal thoracic arteries; intercostal and phrenic nerves (pain sensitive).'
  }
];

// -------------------------------------------------------------
// 4. HUMAN KIDNEYS & RENAL FILTRATION
// -------------------------------------------------------------
export const KIDNEYS_STRUCTURES: AnatomicalStructure[] = [
  {
    id: 'renal-cortex-glomerulus',
    name: 'Renal Cortex & Glomerular Filtration Units',
    latinName: 'Cortex renalis & Corpuscula renalia',
    system: 'Primary Ultrafiltration Apparatus',
    xPercent: 32,
    yPercent: 38,
    functionSummary: 'Outer granular zone housing ~1.2 million nephrons per kidney. The glomerular capillary tuft and podocyte slit diaphragms filter 180 liters of primary filtrate per day, retaining albumin and cellular elements while passing water, electrolytes, and metabolic wastes.',
    physiologicalMetrics: {
      'Estimated GFR (eGFR)': '104 mL/min/1.73m² (Normal > 90)',
      'Filtration Fraction': '20% of total renal plasma flow',
      'Proteinuria Screening': '< 30 mg/g albumin-to-creatinine ratio',
      'Glomerular Capillary Pressure': '50 mmHg (Strict autoregulatory plateau 80-180 mmHg)'
    },
    clinicalSignificance: 'Diabetic nephropathy causes early glomerular hyperfiltration followed by nodular glomerulosclerosis (Kimmelstiel-Wilson lesions) and ESRD.',
    commonPathology: 'Glomerulonephritis, Diabetic Kidney Disease, Focal Segmental Glomerulosclerosis (FSGS), IgA Nephropathy.',
    interventions: 'SGLT2 inhibitors (Dapagliflozin/Empagliflozin), ACE inhibitors / ARBs, immunosuppressive steroids.',
    bloodSupplyOrNerve: 'Interlobular arteries branch into Afferent Arterioles.'
  },
  {
    id: 'renal-medulla-pyramids',
    name: 'Renal Medulla & Malpighian Pyramids',
    latinName: 'Medulla renalis & Pyramides renales',
    system: 'Countercurrent Osmotic Multiplier & Water Recovery',
    xPercent: 44,
    yPercent: 54,
    functionSummary: 'Composed of 8-18 striated triangular pyramids containing the Loops of Henle and Collecting Ducts. Establishes a steep hyperosmolar medullary gradient (from 300 mOsm/kg at cortex up to 1,200 mOsm/kg at papilla) driven by NKCC2 cotransporters for concentrated urine excretion.',
    physiologicalMetrics: {
      'Medullary Osmolality Gradient': '1,200 mOsm/kg H₂O at renal papilla',
      'Loop of Henle Na+ Reabsorption': '25% of filtered sodium load via NKCC2',
      'Vasa Recta Blood Flow': '< 10% of total renal flow (preserves gradient)',
      'Medullary Tissue PO₂': '10 - 20 mmHg (Physiologically hypoxic and vulnerable)'
    },
    clinicalSignificance: 'Extreme medullary hypoxia makes the ascending thick limb highly vulnerable to ischemic and nephrotoxic Acute Tubular Necrosis (ATN) and sickle cell medullary infarction.',
    commonPathology: 'Acute Tubular Necrosis (ATN), Renal Papillary Necrosis, Medullary Sponge Kidney.',
    interventions: 'Loop diuretics (Furosemide), IV volume expansion, prevention of radiocontrast-induced nephropathy.',
    bloodSupplyOrNerve: 'Vasa recta spuria descending from efferent arterioles of juxtamedullary nephrons.'
  },
  {
    id: 'renal-pelvis-calyces',
    name: 'Renal Pelvis & Major / Minor Calyces',
    latinName: 'Pelvis renalis & Calyces renales majores',
    system: 'Urine Collecting Basin & Peristaltic Funnel',
    xPercent: 58,
    yPercent: 48,
    functionSummary: 'Funnel-shaped expansion at the renal hilum receiving final concentrated urine dripping from papillary ducts of Bellini. Smooth muscle pacemaker cells in the minor calyces initiate rhythmic peristaltic contractions propagating down to the ureter.',
    physiologicalMetrics: {
      'Pelvic Capacity': '3 - 8 mL resting volume',
      'Pelvic Resting Pressure': '6 - 10 mmHg',
      'Peristaltic Wave Frequency': '2 - 6 contractions per minute',
      'Urinary Solute Clearance': 'Urea, Creatinine, Uric Acid concentration > 50x plasma'
    },
    clinicalSignificance: 'Obstruction by nephrolithiasis causes acute hydronephrosis, agonizing renal colic, backpressure parenchymal atrophy, and post-renal azotemia.',
    commonPathology: 'Nephrolithiasis (Calcium Oxalate / Struvite stones), Hydronephrosis, Pelviureteric Junction (PUJ) Obstruction, Pyelocaliceal Carcinoma.',
    interventions: 'Extracorporeal Shock Wave Lithotripsy (ESWL), percutaneous nephrolithotomy (PCNL), ureteral double-J (DJ) stenting.',
    bloodSupplyOrNerve: 'Renal artery branches; T10-L1 sympathetic plexus mediating visceral flank pain.'
  },
  {
    id: 'renal-artery-vein',
    name: 'Main Renal Artery & Renal Vein',
    latinName: 'Arteria renalis & Vena renalis',
    system: 'High-Volume Visceral Perfusion Conduit',
    xPercent: 72,
    yPercent: 52,
    functionSummary: 'Receives 20-25% of total resting cardiac output (~1.2 L/min) despite accounting for only 0.5% of body weight. The right renal artery is longer and passes posterior to the IVC; left renal vein crosses anterior to the aorta under the SMA.',
    physiologicalMetrics: {
      'Renal Blood Flow (RBF)': '1,200 mL/min (600 mL/min per kidney)',
      'Renal Vascular Resistance': '0.08 mmHg·min/mL (very low resistance)',
      'Peak Systolic Velocity (PSV)': '90 - 120 cm/s (Stenosis threshold > 200 cm/s)',
      'Renal-Aortic Ratio (RAR)': '< 3.5 normal'
    },
    clinicalSignificance: 'Atherosclerotic Renal Artery Stenosis (ARAS) or fibromuscular dysplasia activates persistent RAAS renin secretion, driving malignant renovascular hypertension.',
    commonPathology: 'Renal Artery Stenosis, Nutcracker Syndrome (Left renal vein compression), Renal Vein Thrombosis (Nephrotic syndrome).',
    interventions: 'Renal artery angioplasty with stenting, catheter-directed thrombectomy, ACEi contraindication in bilateral stenosis.',
    bloodSupplyOrNerve: 'Direct lateral branches of Abdominal Aorta at L1-L2.'
  },
  {
    id: 'juxtaglomerular-raas',
    name: 'Juxtaglomerular Apparatus (JGA) & RAAS Hub',
    latinName: 'Complexus juxtaglomerularis',
    system: 'Endocrine Systemic Hemodynamic Sensor',
    xPercent: 42,
    yPercent: 32,
    functionSummary: 'Specialized cellular complex comprising Macula Densa cells (sensing luminal NaCl delivery) and Juxtaglomerular granular cells in the afferent arteriole. Synthesizes and secretes Renin in response to hypotension, sympathetic tone, or low distal sodium.',
    physiologicalMetrics: {
      'Plasma Renin Activity (PRA)': '1.5 ng/mL/hr (Normal 0.6 - 4.3)',
      'Angiotensin II Sensitivity': 'Vasoconstricts efferent > afferent arteriole to maintain GFR',
      'Tubuloglomerular Feedback Delay': '5 - 10 seconds response time',
      'Erythropoietin (EPO) Production': '90% of circulating EPO synthesized by peritubular fibroblasts'
    },
    clinicalSignificance: 'Chronic kidney disease impairs EPO production, leading to normocytic normochromic anemia. Inappropriate RAAS overactivation drives refractory congestive hypertension and cardiac fibrosis.',
    commonPathology: 'Reninoma (Robertson-Kihara syndrome), Anemia of CKD, Secondary Hyperaldosteronism, Salt-Sensitive Hypertension.',
    interventions: 'Recombinant human erythropoietin (Darbepoetin alfa), Mineralocorticoid receptor antagonists (Spironolactone, Finerenone).',
    bloodSupplyOrNerve: 'Renal sympathetic nerve terminals (target of renal denervation catheter therapy).'
  },
  {
    id: 'ureter-conduit',
    name: 'Ureter & Pelviureteric Junction',
    latinName: 'Ureter',
    system: 'Muscular Peristaltic Urinary Conduit',
    xPercent: 62,
    yPercent: 78,
    functionSummary: 'Thick muscular tube (25-30 cm in length) lined by transitional urothelium. Moves urine drops from kidney to urinary bladder via active myogenic peristalsis, maintaining a unidirectional oblique valve at the ureterovesical junction (UVJ).',
    physiologicalMetrics: {
      'Peristaltic Pressure Wave': '20 - 60 cmH₂O',
      'Internal Lumen Diameter': '3 - 4 mm (Constrictions at PUJ, Iliac crossing, UVJ)',
      'Bolus Propulsion Speed': '2 - 3 cm/second',
      'Intravesical Reflux Prevention': 'Detrusor muscle tunnel compresses terminal ureter during micturition'
    },
    clinicalSignificance: 'Kidney stones frequently impinge at the 3 physiological narrowings (PUJ, pelvic brim, and UVJ). Vesicoureteral reflux (VUR) in children causes recurrent pyelonephritis and renal scarring.',
    commonPathology: 'Urolithiasis, Vesicoureteral Reflux, Retroperitoneal Fibrosis (Ormond disease), Ureteral Stricture.',
    interventions: 'Ureteroscopy (URS) with holmium laser lithotripsy, ureteroneocystostomy, JJ stent placement.',
    bloodSupplyOrNerve: 'Branches from renal, testicular/ovarian, and internal iliac arteries.'
  }
];

// -------------------------------------------------------------
// 5. HUMAN LIVER & HEPATIC ARCHITECTURE
// -------------------------------------------------------------
export const LIVER_STRUCTURES: AnatomicalStructure[] = [
  {
    id: 'right-hepatic-lobe',
    name: 'Right Hepatic Lobe & Couinaud Segments V-VIII',
    latinName: 'Lobus hepatis dexter (Segmenta V, VI, VII, VIII)',
    system: 'Primary Metabolic, Glycogen & Synthetic Factory',
    xPercent: 62,
    yPercent: 44,
    functionSummary: 'The largest anatomical division of the liver (~70% of total liver mass). Divided surgically into Couinaud segments V, VI, VII, and VIII, each possessing autonomous vascular inflow, venous outflow, and biliary drainage branches.',
    physiologicalMetrics: {
      'Total Liver Mass': '1.4 - 1.6 kg (~2.5% of adult body mass)',
      'Albumin Synthesis Rate': '12 - 15 grams per day (Serum albumin 4.2 g/dL)',
      'Glycogen Storage Capacity': '100 - 120 grams (Maintains 24-hr fasting euglycemia)',
      'Clotting Factor Synthesis': 'Synthesizes Factors I, II, V, VII, IX, X, Protein C & S'
    },
    clinicalSignificance: 'Right lobe resections (Right Hemihepatectomy) require preserving at least 25% Future Liver Remnant (FLR) to prevent fatal Post-Hepatectomy Liver Failure (PHLF).',
    commonPathology: 'Hepatocellular Carcinoma (HCC), Non-Alcoholic Fatty Liver Disease (NAFLD/NASH), Hepatic Steatosis, Echinococcal Hydatid Cyst.',
    interventions: 'Transarterial Chemoembolization (TACE), Radiofrequency Ablation (RFA), Anatomical segmentectomy.',
    bloodSupplyOrNerve: 'Right Hepatic Artery and Right Portal Vein branch.'
  },
  {
    id: 'left-hepatic-lobe',
    name: 'Left Hepatic Lobe & Couinaud Segments II-IV',
    latinName: 'Lobus hepatis sinister (Segmenta II, III, IVa, IVb)',
    system: 'Visceral Metabolic & Detoxification Center',
    xPercent: 32,
    yPercent: 48,
    functionSummary: 'Flatter, thinner lobe extending across the epigastrium into the left hypochondrium. Comprises the lateral segments (II, III) and medial segment (IV, quadrate lobe). Demarcated from right lobe by Cantlie line and middle hepatic vein.',
    physiologicalMetrics: {
      'Liver Mass Share': '~30% of hepatic volume',
      'Cytochrome P450 Enzymes': 'Phase I oxidation/hydroxylation (CYP3A4, CYP2D6)',
      'Glucuronidation (Phase II)': 'Conjugates bilirubin, acetaminophen, and lipophilic toxins',
      'Urea Cycle Flux': 'Converts neurotoxic ammonia (NH₃) to excretable urea'
    },
    clinicalSignificance: 'Cirrhotic architectural distortion impairs ammonia detoxification, causing hepatic encephalopathy with asterixis ("liver flap") and cerebral edema.',
    commonPathology: 'Focal Nodular Hyperplasia (FNH), Hepatic Hemangioma, Left Lobe Atrophy in Biliary Obstruction.',
    interventions: 'Lactulose & Rifaximin for encephalopathy, living-donor left lateral sectionectomy for pediatric transplantation.',
    bloodSupplyOrNerve: 'Left Hepatic Artery and Left Branch of Portal Vein.'
  },
  {
    id: 'portal-vein-triad',
    name: 'Hepatic Portal Vein & Portal Triad',
    latinName: 'Vena portae hepatis & Trias hepatica',
    system: 'Splanchnic Venous Sieve & First-Pass Perfusion',
    xPercent: 50,
    yPercent: 62,
    functionSummary: 'Formed by the confluence of the Superior Mesenteric Vein (SMV) and Splenic Vein behind the pancreatic neck. Delivers 75% of total hepatic blood flow rich in absorbed gastrointestinal nutrients, antigens, bacterial endotoxins, and pancreatic hormones (insulin/glucagon).',
    physiologicalMetrics: {
      'Portal Blood Flow': '1,000 - 1,200 mL/min (75% of hepatic inflow)',
      'Portal Venous Pressure': '5 - 8 mmHg (Normal gradient < 5 mmHg)',
      'Hepatic Venous Pressure Gradient (HVPG)': '< 5 mmHg normal / > 10 mmHg clinically significant portal HTN',
      'Oxygen Delivery Contribution': '50% of hepatic oxygen supply (despite venous nature)'
    },
    clinicalSignificance: 'Cirrhosis causes sinusoidal fibrosis and hyperdynamic circulation, triggering HVPG > 12 mmHg, bleeding esophageal varices, and life-threatening ascites.',
    commonPathology: 'Portal Hypertension, Portal Vein Thrombosis (PVT), Esophageal Variceal Hemorrhage, Pylephlebitis.',
    interventions: 'Transjugular Intrahepatic Portosystemic Shunt (TIPS), endoscopic variceal band ligation, Non-selective beta-blockers (Propranolol, Carvedilol).',
    bloodSupplyOrNerve: 'Formed by SMV + Splenic Vein; surrounded by Glisson capsule.'
  },
  {
    id: 'gallbladder-cystic-duct',
    name: 'Gallbladder & Cystic Duct',
    latinName: 'Vesica biliaris & Ductus cysticus',
    system: 'Bile Storage & Concentrating Reservoir',
    xPercent: 54,
    yPercent: 78,
    functionSummary: 'Pear-shaped muscular sac nestled in a fossa on the visceral surface of right hepatic lobe. Concentrates hepatic bile 5-10 fold by reabsorbing water and electrolytes. Contracts in response to Cholecystokinin (CCK) released by duodenal I-cells during fatty meals.',
    physiologicalMetrics: {
      'Bile Storage Volume': '30 - 50 mL concentrated bile',
      'Ejection Fraction (GB-EF)': '> 35% at 45 min after fatty meal / CCK-HIDA scan',
      'Bile Concentration Factor': 'Concentrates bile salts and cholesterol 10x',
      'Biliary Ph': '6.8 - 7.6'
    },
    clinicalSignificance: 'Supersaturation of cholesterol or bile stasis forms gallstones (cholelithiasis). Impacted stones in cystic duct cause acute calculous cholecystitis with positive Murphy sign.',
    commonPathology: 'Acute Cholecystitis, Cholelithiasis, Biliary Colic, Gallbladder Adenomyomatosis, Cholangiocarcinoma.',
    interventions: 'Laparoscopic Cholecystectomy, endoscopic retrograde cholangiopancreatography (ERCP), Ursodeoxycholic acid.',
    bloodSupplyOrNerve: 'Cystic artery (classically located in Calot\'s triangle originating from Right Hepatic Artery).'
  },
  {
    id: 'common-bile-duct',
    name: 'Common Bile Duct & Ampulla of Vater',
    latinName: 'Ductus choledochus & Ampulla hepatopancreatica',
    system: 'Extrahepatic Biliary Drainage Conduit',
    xPercent: 46,
    yPercent: 84,
    functionSummary: 'Formed by junction of common hepatic duct and cystic duct. Descends within the free edge of lesser omentum, runs behind the 1st part of duodenum and pancreatic head, joining main pancreatic duct of Wirsung to enter 2nd part of duodenum through the Sphincter of Oddi.',
    physiologicalMetrics: {
      'Normal Lumen Diameter': '4 - 6 mm (expands up to 8-10 mm post-cholecystectomy)',
      'Daily Bile Output': '600 - 1,000 mL bile produced per 24 hours',
      'Bile Composition': 'Bile acids (Cholic, Chenodeoxycholic), Phospholipids, Conjugated Bilirubin, Cholesterol',
      'Intraductal Pressure': '10 - 15 cmH₂O'
    },
    clinicalSignificance: 'Choledocholithiasis (common duct stone) causes obstructive jaundice, pruritus, acholic pale stools, and life-threatening acute ascending cholangitis (Charcot triad & Reynolds pentad).',
    commonPathology: 'Choledocholithiasis, Ascending Cholangitis, Klatskin Tumor (Hilar Cholangiocarcinoma), Biliary Atresia.',
    interventions: 'ERCP with endoscopic sphincterotomy and balloon stone extraction, biliary plastic/metallic stenting.',
    bloodSupplyOrNerve: 'Axial vascular arcade fed by retroduodenal and cystic arteries.'
  },
  {
    id: 'hepatic-sinusoids-kupffer',
    name: 'Hepatic Sinusoids & Kupffer Reticuloendothelial Grid',
    latinName: 'Vasa sinusoidea hepatica & Macrophagocyti stellati',
    system: 'Microvascular Immune Surveillance & Sinusoidal Barrier',
    xPercent: 40,
    yPercent: 36,
    functionSummary: 'Specialized low-shear capillaries lined by discontinuous fenestrated endothelial cells lacking a continuous basement membrane. Houses Kupffer cells (accounting for 80-90% of all resident tissue macrophages in the human body) which clear gut-derived bacterial endotoxins.',
    physiologicalMetrics: {
      'Kupffer Cell Population': '80 - 90% of total body tissue macrophages',
      'Endotoxin Clearance Rate': '> 99% clearance on single portal passage',
      'Space of Disse': 'Narrow extracellular cleft containing Hepatic Stellate cells (store 80% of body Vitamin A)',
      'Sinusoidal Transit Time': '3 - 5 seconds'
    },
    clinicalSignificance: 'Chronic alcohol or lipotoxic insult activates quiescent Hepatic Stellate cells into collagen-producing myofibroblasts, causing sinusoidal capillarization and irreversible liver cirrhosis.',
    commonPathology: 'Hepatic Fibrosis, Cirrhotic Capillarization, Sepsis-Induced Cholestasis, Hepatosplenomegaly.',
    interventions: 'Antifibrotic therapeutics, GLP-1/GIP agonists (Tirzepatide) for NASH, liver transplantation for Model for End-Stage Liver Disease (MELD-Na) > 15.',
    bloodSupplyOrNerve: 'Dual mixed arterial and portal venous blood in sinusoids.'
  }
];

// -------------------------------------------------------------
// 6. HUMAN VERTEBRAL SPINE & SPINAL CORD
// -------------------------------------------------------------
export const SPINE_STRUCTURES: AnatomicalStructure[] = [
  {
    id: 'cervical-spine-lordosis',
    name: 'Cervical Spine (C1-C7) & Craniovertebral Junction',
    latinName: 'Vertebrae cervicales (C1 Atlas & C2 Axis ad C7)',
    system: 'High-Mobility Cephalic Support & Vertebral Artery Conduit',
    xPercent: 50,
    yPercent: 18,
    functionSummary: 'Seven cervical vertebrae arranged in a lordotic curve supporting the 5 kg human head. C1 (Atlas) and C2 (Axis / Dens) allow 50% of all cervical flexion-extension and axial rotation. Transverse foramina transmit the vertebral arteries to form the basilar artery.',
    physiologicalMetrics: {
      'Cervical Range of Motion': '80° rotation / 60° flexion / 75° extension',
      'Cervical Canal Diameter': '17 mm normal (Absolute stenosis < 10 mm)',
      'Vertebral Artery Inflow': '200 mL/min posterior cerebral circulation',
      'Lordotic Angle': '30° - 40° physiological lordosis'
    },
    clinicalSignificance: 'Cervical spondylotic myelopathy causes progressive spastic quadriparesis, gait ataxia, and hyperreflexia (Hoffmann & Babinski signs). Odontoid fracture from hyperextension risks fatal brainstem transection.',
    commonPathology: 'Cervical Spondylotic Myelopathy, Odontoid Process Fracture, Cervical Radiculopathy, Whiplash Injury.',
    interventions: 'Anterior Cervical Discectomy and Fusion (ACDF), Cervical Artificial Disc Replacement (ADR), Posterior Laminectomy.',
    bloodSupplyOrNerve: 'Vertebral arteries and ascending cervical arteries; C1-C8 cervical nerve roots.'
  },
  {
    id: 'thoracic-spine-kyphosis',
    name: 'Thoracic Spine (T1-T12) & Rib Cage Articulations',
    latinName: 'Vertebrae thoracicae & Columna kyphotica',
    system: 'Rigid Cardiopulmonary Protection & Axial Pillar',
    xPercent: 50,
    yPercent: 44,
    functionSummary: 'Twelve vertebrae exhibiting physiological kyphosis, articulated with the 12 pairs of ribs via costovertebral and costotransverse synovial joints. Provides high mechanical rigidity to protect thoracic viscera and maintain negative intrapleural breathing mechanics.',
    physiologicalMetrics: {
      'Thoracic Kyphosis Angle': '20° - 45° (Normal range via Cobb method)',
      'Canal Diameter': '13 - 15 mm (Narrowest segment of spinal canal)',
      'Critical Vascular Watershed': 'T4-T9 (Vulnerable watershed zone of spinal cord)',
      'Artery of Adamkiewicz': 'Enters classically between T9-T12 (supplies 75% of lower cord)'
    },
    clinicalSignificance: 'The narrow thoracic canal makes disc herniation rare (<1%) but catastrophically myelopathic. Cross-clamping during thoracic aortic aneurysm repair risks spinal cord infarction and paraplegia.',
    commonPathology: 'Thoracic Kyphoscoliosis, Osteoporotic Vertebral Compression Fractures (VCF), Scheuermann Disease, Pott Disease (TB spine).',
    interventions: 'Balloon Kyphoplasty, Percutaneous Vertebroplasty, Posterior Thoracic Pedicle Screw Instrument Navigation.',
    bloodSupplyOrNerve: 'Posterior intercostal arteries and anterior spinal artery; T1-T12 thoracic spinal nerves.'
  },
  {
    id: 'lumbar-spine-lordosis',
    name: 'Lumbar Spine (L1-L5) & Weight-Bearing Bodies',
    latinName: 'Vertebrae lumbales (L1-L5)',
    system: 'High-Load Axial Support & Dynamic Bending Pivot',
    xPercent: 50,
    yPercent: 68,
    functionSummary: 'Five massive, kidney-shaped vertebral bodies designed for heavy axial compressive load-bearing and sagittal flexion/extension. Absorbs up to 2-3x body weight during standing and up to 10x body weight during improper lifting.',
    physiologicalMetrics: {
      'Axial Compressive Load (Standing)': '1,000 N / Up to 4,000 N during heavy lifting',
      'Lumbar Lordosis (LL)': '40° - 60° (Matches Pelvic Incidence within ±10°)',
      'Canal Midsagittal Diameter': '15 - 25 mm (Stenosis threshold < 10 mm)',
      'Facet Joint Load Bearing': '15 - 20% of total axial load in erect posture'
    },
    clinicalSignificance: 'L4-L5 and L5-S1 represent 95% of all clinical disc herniations. Degenerative lumbar spinal stenosis causes neurogenic claudication relieved by lumbar flexion ("shopping cart sign").',
    commonPathology: 'Lumbar Disc Herniation, Lumbar Spinal Stenosis, Spondylolisthesis (Isthmic & Degenerative), Lumbar Radiculopathy (Sciatica).',
    interventions: 'Microdiscectomy, Minimally Invasive Transforaminal Lumbar Interbody Fusion (MIS-TLIF), Epidural steroid injections.',
    bloodSupplyOrNerve: 'Lumbar segmental arteries from abdominal aorta; L1-L5 nerve roots forming lumbar plexus.'
  },
  {
    id: 'intervertebral-discs',
    name: 'Intervertebral Disc & Annulus / Nucleus Pulposus',
    latinName: 'Discus intervertebralis (Nucleus pulposus & Anulus fibrosus)',
    system: 'Hydraulic Shock Absorber & Hydrostatic Spring',
    xPercent: 50,
    yPercent: 56,
    functionSummary: 'Avascular fibrocartilaginous cushion consisting of an outer concentric fibrous ring (Annulus Fibrosus with type I collagen) constraining a gelatinous inner core (Nucleus Pulposus with 80% water and proteoglycans). Hydrostatic pressure evenly disperses spinal stresses.',
    physiologicalMetrics: {
      'Water Content (Youth)': '80 - 85% in nucleus pulposus / Declines to < 70% in elderly',
      'Proteoglycan Concentration': 'High aggrecan content binding osmotic water',
      'Diurnal Height Variation': 'Discs lose 15-20 mm in height during daytime upright activity',
      'Nutrient Diffusion Distance': 'Up to 8 mm diffusion from vertebral endplate capillary beds'
    },
    clinicalSignificance: 'Radial tears in the posterolateral annulus allow nucleus pulposus extrusion, mechanically compressing the exiting or traversing nerve root and triggering intense inflammatory sciatica via TNF-alpha.',
    commonPathology: 'Degenerative Disc Disease (DDD), Disc Protrusion & Extrusion, Annular Tear, Modic Endplate Changes.',
    interventions: 'Endoscopic lumbar discectomy, intradiscal biologic therapies, dynamic stabilization, nucleus pulposus augmentation.',
    bloodSupplyOrNerve: 'Avascular in adult interior; outer 1/3 of annulus innervated by sinuvertebral nerve.'
  },
  {
    id: 'spinal-cord-cauda-equina',
    name: 'Spinal Cord & Conus Medullaris / Cauda Equina',
    latinName: 'Medulla spinalis, Conus medullaris & Cauda equina',
    system: 'Central Nervous Conduit & Lower Motor Root Assembly',
    xPercent: 50,
    yPercent: 78,
    functionSummary: 'The spinal cord terminates at the L1-L2 intervertebral level as the tapered Conus Medullaris. Below this, the lumbar, sacral, and coccygeal nerve roots form the horse-tail-like Cauda Equina within the CSF-filled thecal sac, permitting safe lumbar puncture at L3-L4 or L4-L5.',
    physiologicalMetrics: {
      'Cord Termination Level': 'L1-L2 interspace in 94% of adults',
      'CSF Pressure in Thecal Sac': '10 - 20 cmH₂O in lateral decubitus',
      'Nerve Root Conduction': '50 - 70 m/s in A-alpha motor fibers',
      'Total Nerve Root Pairs': '31 pairs (8C, 12T, 5L, 5S, 1Co)'
    },
    clinicalSignificance: 'Acute compression of the cauda equina by a massive central disc herniation causes Cauda Equina Syndrome: saddle anesthesia, bladder urinary retention with overflow incontinence, and bilateral foot drop. Emergency surgical decompression is mandatory within 24-48 hours.',
    commonPathology: 'Cauda Equina Syndrome, Conus Medullaris Syndrome, Spinal Cord Ependymoma, Tethered Cord Syndrome.',
    interventions: 'Emergency emergency decompressive laminectomy, intrathecal baclofen pump, lumbar puncture CSF analysis.',
    bloodSupplyOrNerve: 'Single Anterior Spinal Artery and paired Posterior Spinal Arteries.'
  },
  {
    id: 'spinal-nerve-roots-foramina',
    name: 'Spinal Nerve Roots & Intervertebral Foramina',
    latinName: 'Radices nervorum spinalium & Foramina intervertebralia',
    system: 'Peripheral Nervous Sensorimotor Conduit Gates',
    xPercent: 42,
    yPercent: 62,
    functionSummary: 'Bilateral bony exits formed between the pedicles of adjacent vertebrae. Each neural foramen transmits a dorsal sensory root (with its dorsal root ganglion), a ventral motor root, radicular arteries, and sinuvertebral nerves.',
    physiologicalMetrics: {
      'Foraminal Height': '15 - 20 mm / Width 8 - 10 mm',
      'Nerve Root Occupancy': 'Nerve occupies 25 - 35% of foraminal cross-section',
      'Foraminal Patency in Flexion': 'Increases by 12 - 24% in flexion / Decreases in extension',
      'Dorsal Root Ganglion (DRG)': 'Houses primary pseudounipolar sensory neuron cell bodies'
    },
    clinicalSignificance: 'Facet joint hypertrophy, osteophyte overgrowth, and lateral disc herniations cause severe foraminal stenosis, trapping the exiting nerve root and producing unremitting dermatomal radiculopathy.',
    commonPathology: 'Foraminal Stenosis, Cervical/Lumbar Radiculopathy, Herpes Zoster (Shingles reactivation in DRG), Neurofibroma.',
    interventions: 'Foraminotomy, transforaminal selective nerve root block (SNRB), pulsed radiofrequency ablation of dorsal root ganglion.',
    bloodSupplyOrNerve: 'Radicular arteries entering through foramina accompanying nerve root dural sleeves.'
  }
];
