import React from 'react';
import {
  Activity,
  Bell,
  Sun,
  Moon,
  Shield,
  User,
  AlertTriangle,
  Menu,
  X,
  Stethoscope,
  Building2,
  Lock,
  Terminal,
  Heart,
  UserCheck
} from 'lucide-react';
import { UserRole, AppSection } from '../../types';
import { motion } from 'motion/react';
import { AnimatedECGStrip } from '../common/AnimatedECGStrip';

interface NavbarProps {
  currentRole: UserRole;
  currentSection: AppSection;
  onSelectRole: (role: UserRole) => void;
  onNavigate: (section: AppSection) => void;
  onOpenAuth: () => void;
  isLoggedIn: boolean;
  onLogout: () => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentRole,
  currentSection,
  onSelectRole,
  onNavigate,
  onOpenAuth,
  isLoggedIn,
  onLogout,
  mobileMenuOpen,
  setMobileMenuOpen,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-white/10 bg-[#040813]/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Logo & Platform Name */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-xl text-slate-400 hover:text-white bg-white/[0.04]"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>

          <div
            onClick={() => onNavigate(isLoggedIn ? `${currentRole}-dashboard` as any : 'landing')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#00d4b4] to-[#4f8cff] flex items-center justify-center text-black font-black shadow-lg shadow-[#00d4b4]/20 group-hover:scale-105 transition-transform">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <div className="font-extrabold text-base tracking-tight text-white flex items-center gap-1.5">
                <span>AYUVA</span>
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#00d4b4]/20 text-[#00d4b4] border border-[#00d4b4]/30 font-normal">
                  AI HEALTH
                </span>
              </div>
              <div className="text-[9px] font-mono text-slate-400 hidden sm:block">
                MULTIMODAL INTELLIGENCE PLATFORM
              </div>
            </div>
          </div>

          {/* Real-time Miniature ECG Waveform Monitor (Visible on desktop) */}
          <div className="hidden xl:flex items-center gap-2 ml-2 pl-3 border-l border-white/10">
            <div className="w-20">
              <AnimatedECGStrip bpm={72} height={22} color="#00d4b4" showGrid={false} />
            </div>
            <div className="flex items-center gap-1 text-[10px] font-mono text-emerald-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
              <span>72 BPM</span>
            </div>
          </div>
        </div>

        {/* Role Switcher (Patient / Doctor / Admin) */}
        <div className="hidden lg:flex items-center bg-[#080e1c] p-1 rounded-xl border border-white/10">
          <button
            onClick={() => onSelectRole('patient')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              currentRole === 'patient'
                ? 'bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>Patient Portal</span>
          </button>

          <button
            onClick={() => onSelectRole('doctor')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              currentRole === 'doctor'
                ? 'bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Stethoscope className="w-3.5 h-3.5" />
            <span>Physician Cockpit</span>
          </button>

          <button
            onClick={() => onSelectRole('admin')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              currentRole === 'admin'
                ? 'bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black shadow-md'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Regional Command</span>
          </button>
        </div>

        {/* Right Actions: Emergency SOS, Python Hub, 3D Models & Auth */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* 6 3D Organs Quick Button */}
          <button
            onClick={() => onNavigate('anatomical-models')}
            className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
              currentSection === 'anatomical-models'
                ? 'bg-gradient-to-r from-rose-500 to-cyan-500 text-white border-white/20 font-bold shadow-md shadow-cyan-500/20'
                : 'bg-[#080e1c] hover:bg-rose-500/10 text-slate-300 hover:text-rose-400 border-white/10'
            }`}
          >
            <Heart className="w-3.5 h-3.5 text-rose-400 fill-rose-500/30 animate-pulse" />
            <span className="hidden md:inline">6 3D Organs</span>
          </button>

          {/* Python & Hugging Face Hub Quick Button */}
          <button
            onClick={() => onNavigate('python-hub')}
            className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
              currentSection === 'python-hub'
                ? 'bg-[#00d4b4] text-black border-[#00d4b4] font-bold shadow-md shadow-[#00d4b4]/20'
                : 'bg-[#080e1c] hover:bg-[#00d4b4]/10 text-slate-300 hover:text-[#00d4b4] border-white/10'
            }`}
          >
            <Terminal className="w-3.5 h-3.5 text-[#00d4b4]" />
            <span className="hidden md:inline">Python & HF Hub</span>
          </button>

          {/* Digital Twin Quick Button */}
          <button
            onClick={() => onNavigate('digital-twin')}
            className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all ${
              currentSection === 'digital-twin'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-black border-emerald-400 font-bold shadow-md shadow-emerald-500/20'
                : 'bg-[#080e1c] hover:bg-emerald-500/10 text-emerald-300 hover:text-emerald-200 border-emerald-500/30'
            }`}
          >
            <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden md:inline">Digital Twin</span>
          </button>

          {/* Emergency SOS Quick Button */}
          <button
            onClick={() => onNavigate('emergency-sos')}
            className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-bold transition-colors animate-pulse"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
            <span className="hidden sm:inline">108 SOS</span>
          </button>

          {isLoggedIn ? (
            <div className="flex items-center gap-2">
              <div
                onClick={() => onNavigate(`${currentRole}-dashboard` as any)}
                className="flex items-center gap-2 p-1.5 rounded-xl bg-white/[0.04] border border-white/10 cursor-pointer hover:bg-white/[0.08]"
              >
                <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-[#00d4b4] to-[#4f8cff] text-black font-bold flex items-center justify-center text-xs">
                  {currentRole === 'patient' ? 'AR' : currentRole === 'doctor' ? 'RK' : 'AD'}
                </div>
                <div className="text-left hidden sm:block pr-2">
                  <div className="text-xs font-bold text-slate-200 leading-none">
                    {currentRole === 'patient' ? 'Arjun Reddy' : currentRole === 'doctor' ? 'Dr. Rajesh' : 'Admin'}
                  </div>
                  <div className="text-[10px] font-mono text-emerald-400 uppercase mt-0.5">
                    {currentRole}
                  </div>
                </div>
              </div>

              <button
                onClick={onLogout}
                className="text-xs text-slate-400 hover:text-rose-400 font-medium px-2 py-1"
              >
                Exit
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs shadow-md hover:opacity-90 transition-opacity"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Login / ABHA</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
