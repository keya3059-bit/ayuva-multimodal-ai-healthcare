import React from 'react';
import {
  LayoutDashboard,
  Stethoscope,
  Activity,
  Layers,
  MessageSquare,
  Truck,
  FileText,
  FlaskConical,
  TrendingUp,
  Calendar,
  Pill,
  UserCheck,
  Users,
  AlertTriangle,
  Smile,
  Hospital,
  Watch,
  Building2,
  Cpu,
  Video,
  Ambulance,
  BarChart3,
  Terminal,
  Heart,
  Sparkles
} from 'lucide-react';
import { UserRole, AppSection } from '../../types';

interface SidebarProps {
  currentRole: UserRole;
  currentSection: AppSection;
  onNavigate: (sec: AppSection) => void;
  mobileMenuOpen: boolean;
  setMobileMenuOpen: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentRole,
  currentSection,
  onNavigate,
  mobileMenuOpen,
  setMobileMenuOpen,
}) => {
  const patientNav = [
    { id: 'patient-dashboard', label: 'Telemetry & Vitals', icon: LayoutDashboard },
    { id: 'digital-twin', label: 'Multi-Organ Digital Twin', icon: UserCheck, badge: 'BIO-TWIN' },
    { id: 'anatomical-models', label: '3D Anatomy & Organ Models', icon: Heart, badge: '6 ORGANS' },
    { id: 'ai-intelligence-stack', label: 'AYUVA AI & Vision Stack', icon: Sparkles, badge: 'ML · MONAI' },
    { id: 'python-hub', label: 'Python & Hugging Face', icon: Terminal, badge: 'PY 3.10' },
    { id: 'symptom-checker', label: 'AI Symptom Checker', icon: Stethoscope, badge: 'GEMINI' },
    { id: 'random-forest', label: '100-Tree Forest Sim', icon: Activity },
    { id: 'multimodal-hub', label: 'Multimodal Hub', icon: Layers },
    { id: 'ai-chat', label: 'Clinical AI Assistant', icon: MessageSquare },
    { id: 'lab-analyzer', label: 'Biomarker Lab Vision', icon: FlaskConical },
    { id: 'health-records', label: 'EHR / ABHA Vault', icon: FileText },
    { id: 'health-trends', label: 'Longitudinal Trends', icon: TrendingUp },
    { id: 'appointments', label: 'Book Consultations', icon: Calendar },
    { id: 'medication-reminders', label: 'Medication Adherence', icon: Pill },
    { id: 'medicine-delivery', label: 'Fleet Rx Delivery', icon: Truck },
    { id: 'family-care', label: 'Family Care Circle', icon: Users },
    { id: 'mental-health', label: 'Cognitive Resilience', icon: Smile },
    { id: 'hospitals-near-me', label: 'Hospitals & Trauma', icon: Hospital },
    { id: 'wearables', label: 'IoT Biosensors', icon: Watch },
    { id: 'emergency-sos', label: 'Emergency 108 SOS', icon: AlertTriangle, urgent: true },
  ];

  const doctorNav = [
    { id: 'doctor-dashboard', label: 'Physician Cockpit', icon: LayoutDashboard },
    { id: 'digital-twin', label: 'Multi-Organ Digital Twin', icon: UserCheck, badge: 'BIO-TWIN' },
    { id: 'anatomical-models', label: '3D Anatomy & Organ Models', icon: Heart, badge: '6 ORGANS' },
    { id: 'ai-intelligence-stack', label: 'AYUVA AI & Vision Stack', icon: Sparkles, badge: 'ML · MONAI' },
    { id: 'python-hub', label: 'Python & Hugging Face ML', icon: Terminal, badge: 'PY 3.10' },
    { id: 'doctor-patients', label: 'Patient Directory', icon: Users },
    { id: 'soap-generator', label: 'AI SOAP Drafter', icon: FileText, badge: 'GEMINI' },
    { id: 'teleconsultation', label: 'Telehealth Room', icon: Video },
    { id: 'admin-capacity', label: 'Facility Bed Board', icon: Hospital },
    { id: 'emergency-sos', label: '108 Priority Dispatch', icon: AlertTriangle, urgent: true },
  ];

  const adminNav = [
    { id: 'admin-dashboard', label: 'Command Overview', icon: LayoutDashboard },
    { id: 'digital-twin', label: 'Multi-Organ Digital Twin', icon: UserCheck, badge: 'BIO-TWIN' },
    { id: 'anatomical-models', label: '3D Anatomy & Organ Models', icon: Heart, badge: '6 ORGANS' },
    { id: 'ai-intelligence-stack', label: 'AYUVA AI & Vision Stack', icon: Sparkles, badge: 'OPS · ML' },
    { id: 'python-hub', label: 'Python Backend & HF Hub', icon: Terminal, badge: 'PY 3.10' },
    { id: 'admin-fleet', label: 'Autonomous Fleet', icon: Ambulance },
    { id: 'admin-capacity', label: 'Hospital Capacity', icon: Building2 },
    { id: 'admin-models', label: 'AI Observability', icon: Cpu, badge: 'OPS' },
    { id: 'emergency-sos', label: 'District SOS Log', icon: AlertTriangle, urgent: true },
  ];

  const navItems =
    currentRole === 'patient'
      ? patientNav
      : currentRole === 'doctor'
      ? doctorNav
      : adminNav;

  const handleItemClick = (id: string) => {
    onNavigate(id as AppSection);
    setMobileMenuOpen(false);
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {mobileMenuOpen && (
        <div
          onClick={() => setMobileMenuOpen(false)}
          className="fixed inset-0 bg-black/70 backdrop-blur-sm z-40 md:hidden"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed top-16 bottom-0 left-0 z-40 w-64 bg-[#050914] border-r border-white/10 p-3 flex flex-col justify-between transition-transform duration-300 md:translate-x-0 ${
          mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'
        }`}
      >
        <div className="flex-1 overflow-y-auto space-y-1 pr-1 custom-scrollbar">
          <div className="text-[10px] font-mono uppercase tracking-wider text-slate-500 px-3 py-2">
            {currentRole} Workflows
          </div>

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentSection === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleItemClick(item.id)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-[#00d4b4]/15 to-[#4f8cff]/15 text-[#00d4b4] border border-[#00d4b4]/30 font-semibold'
                    : item.urgent
                    ? 'text-rose-400 hover:bg-rose-500/10'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-white/[0.04]'
                }`}
              >
                <div className="flex items-center gap-2.5 truncate">
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive
                        ? 'text-[#00d4b4]'
                        : item.urgent
                        ? 'text-rose-400'
                        : 'text-slate-400'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                </div>

                {item.badge && (
                  <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-[#00d4b4]/10 text-[#00d4b4] border border-[#00d4b4]/20">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Bottom Engine Specs */}
        <div className="pt-3 border-t border-white/10 px-2 space-y-2">
          <div className="p-2.5 rounded-xl bg-[#080e1c] border border-white/5 text-[11px] font-mono text-slate-400 space-y-1">
            <div className="flex items-center justify-between text-slate-300">
              <span>SYSTEM</span>
              <span className="text-emerald-400">ONLINE</span>
            </div>
            <div className="text-[10px] text-slate-500">
              SVIMS / AIIMS Tirupati Link
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
