import React from 'react';
import {
  Activity,
  Stethoscope,
  Building2,
  User,
  ShieldCheck,
  Zap,
  ArrowRight,
  Sparkles,
  AlertTriangle,
  Layers,
  Heart,
  Truck,
  CheckCircle2,
  Radio,
  Cpu,
  Brain,
  Timer
} from 'lucide-react';
import { motion } from 'motion/react';
import { UserRole, AppSection } from '../types';
import { MedicalParticleNetwork } from './common/MedicalParticleNetwork';
import { AnimatedECGStrip } from './common/AnimatedECGStrip';
import { AnimatedCounter } from './common/AnimatedCounter';

interface LandingPageProps {
  onSelectRole: (role: UserRole) => void;
  onNavigate: (sec: AppSection) => void;
  onOpenAuth: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onSelectRole,
  onNavigate,
  onOpenAuth,
}) => {
  // Stagger variants for motion
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.12,
        delayChildren: 0.05,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 24 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { type: 'spring', damping: 22, stiffness: 120 },
    },
  };

  return (
    <div className="relative space-y-16 pb-16 overflow-hidden">
      {/* Interactive Medical Particle Network Background */}
      <MedicalParticleNetwork density={40} glowColor="#00d4b4" className="absolute inset-0 pointer-events-none z-0" />

      {/* Floating Medical Decorative Hologram Rings */}
      <div className="absolute top-10 left-1/2 -translate-x-1/2 w-[700px] h-[350px] bg-gradient-to-tr from-[#00d4b4]/10 via-[#4f8cff]/10 to-transparent blur-3xl pointer-events-none rounded-full" />
      <div className="absolute top-80 -left-20 w-72 h-72 bg-rose-500/10 blur-3xl pointer-events-none rounded-full" />
      <div className="absolute top-96 -right-20 w-80 h-80 bg-cyan-500/10 blur-3xl pointer-events-none rounded-full" />

      {/* Hero Section */}
      <motion.div
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="relative z-10 pt-6 sm:pt-14 text-center max-w-4xl mx-auto space-y-6 px-4"
      >
        {/* Floating live status pill with pulsing beacon */}
        <motion.div variants={itemVariants} className="inline-block">
          <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-[#00d4b4]/10 border border-[#00d4b4]/30 text-xs font-mono text-[#00d4b4] shadow-lg shadow-[#00d4b4]/10 backdrop-blur-md">
            <span className="relative flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#00d4b4] opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-[#00d4b4]" />
            </span>
            <span className="font-semibold tracking-wide">
              GEMINI 3.8 FLASH · IN SILICO PHYSIOLOGICAL TWINS ACTIVE
            </span>
            <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#00d4b4]/20 border border-[#00d4b4]/30 text-white font-bold">
              LIVE
            </span>
          </div>
        </motion.div>

        {/* Animated Main Headline */}
        <motion.h1
          variants={itemVariants}
          className="text-4xl sm:text-6xl lg:text-7xl font-black tracking-tight text-white leading-[1.08]"
        >
          Next-Generation{' '}
          <span className="bg-gradient-to-r from-[#00d4b4] via-[#4f8cff] to-cyan-300 bg-clip-text text-transparent drop-shadow-sm">
            Multimodal AI
          </span>{' '}
          Healthcare
        </motion.h1>

        {/* Descriptive Subtext */}
        <motion.p
          variants={itemVariants}
          className="text-base sm:text-lg text-slate-300 max-w-2xl mx-auto leading-relaxed"
        >
          Unifying physiological digital twins, 100-tree decision forests, real-time biometric telemetry, and autonomous emergency dispatch across patients, clinicians, and regional networks.
        </motion.p>

        {/* Live Synchronized Electrocardiogram Rhythm Bar */}
        <motion.div variants={itemVariants} className="max-w-md mx-auto pt-1">
          <div className="p-3 rounded-2xl bg-[#080e1c]/80 border border-white/10 backdrop-blur-md shadow-xl flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs font-mono text-slate-300 shrink-0">
              <Heart className="w-4 h-4 text-rose-500 animate-heartbeat" />
              <span className="text-white font-bold">72 BPM</span>
              <span className="text-[10px] text-emerald-400">SINUS RHYTHM</span>
            </div>
            <div className="flex-1 max-w-[200px]">
              <AnimatedECGStrip bpm={72} height={28} color="#00d4b4" showGrid={false} />
            </div>
            <div className="text-[10px] font-mono text-cyan-400 border border-cyan-500/30 px-2 py-0.5 rounded bg-cyan-500/10 shrink-0">
              STABLE
            </div>
          </div>
        </motion.div>

        {/* Action Buttons with Spring Micro-Interactions */}
        <motion.div
          variants={itemVariants}
          className="flex flex-wrap items-center justify-center gap-3 pt-2"
        >
          <motion.button
            whileHover={{ scale: 1.04, y: -2 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => {
              onSelectRole('patient');
              onNavigate('patient-dashboard');
            }}
            className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-[#00d4b4] via-[#4f8cff] to-cyan-300 text-black font-extrabold text-sm shadow-xl shadow-[#00d4b4]/20 flex items-center gap-2 transition-shadow hover:shadow-cyan-400/40"
          >
            <User className="w-4 h-4" />
            <span>Launch Patient Portal</span>
            <ArrowRight className="w-4 h-4" />
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.04, y: -2 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => {
              onSelectRole('doctor');
              onNavigate('doctor-dashboard');
            }}
            className="px-6 py-3.5 rounded-xl bg-[#080e1c] hover:bg-white/[0.08] border border-white/15 text-white font-bold text-sm transition-all flex items-center gap-2 shadow-lg"
          >
            <Stethoscope className="w-4 h-4 text-[#00d4b4]" />
            <span>Physician Cockpit</span>
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.04, y: -2 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => {
              onSelectRole('admin');
              onNavigate('admin-dashboard');
            }}
            className="px-6 py-3.5 rounded-xl bg-[#080e1c] hover:bg-white/[0.08] border border-white/15 text-white font-bold text-sm transition-all flex items-center gap-2 shadow-lg"
          >
            <Building2 className="w-4 h-4 text-[#4f8cff]" />
            <span>District Command</span>
          </motion.button>

          <motion.button
            whileHover={{ scale: 1.04, y: -2 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => onNavigate('anatomical-models')}
            className="px-5 py-3.5 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/40 text-rose-300 font-bold text-sm transition-all flex items-center gap-2 shadow-lg"
          >
            <Heart className="w-4 h-4 text-rose-400 animate-pulse" />
            <span>6 3D Anatomical Organs</span>
          </motion.button>
        </motion.div>
      </motion.div>

      {/* Real-time Telemetry Stats Ticker */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="max-w-6xl mx-auto px-4"
      >
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-5 sm:p-6 rounded-3xl bg-[#080e1c]/90 border border-white/10 backdrop-blur-md shadow-2xl">
          <div className="space-y-1 text-center sm:text-left border-r border-white/10 pr-2">
            <div className="flex items-center justify-center sm:justify-start gap-1.5 text-xs text-slate-400 font-mono">
              <Activity className="w-3.5 h-3.5 text-[#00d4b4]" />
              <span>PATIENTS MONITORED</span>
            </div>
            <div className="text-2xl sm:text-3xl font-black text-white font-mono">
              <AnimatedCounter value={14820} duration={1400} suffix="+" />
            </div>
            <div className="text-[10px] text-emerald-400">Continuous telemetry sync</div>
          </div>

          <div className="space-y-1 text-center sm:text-left sm:border-r border-white/10 pr-2">
            <div className="flex items-center justify-center sm:justify-start gap-1.5 text-xs text-slate-400 font-mono">
              <Brain className="w-3.5 h-3.5 text-cyan-400" />
              <span>DIAGNOSTIC ACCURACY</span>
            </div>
            <div className="text-2xl sm:text-3xl font-black text-[#00d4b4] font-mono">
              <AnimatedCounter value={99.4} decimals={1} duration={1200} suffix="%" />
            </div>
            <div className="text-[10px] text-slate-400">Validated against MIMIC-IV</div>
          </div>

          <div className="space-y-1 text-center sm:text-left border-r border-white/10 pr-2">
            <div className="flex items-center justify-center sm:justify-start gap-1.5 text-xs text-slate-400 font-mono">
              <Timer className="w-3.5 h-3.5 text-purple-400" />
              <span>INFERENCE LATENCY</span>
            </div>
            <div className="text-2xl sm:text-3xl font-black text-purple-300 font-mono">
              <AnimatedCounter value={42} duration={900} suffix=" ms" />
            </div>
            <div className="text-[10px] text-slate-400">Gemini 3.8 Flash Engine</div>
          </div>

          <div className="space-y-1 text-center sm:text-left">
            <div className="flex items-center justify-center sm:justify-start gap-1.5 text-xs text-slate-400 font-mono">
              <Heart className="w-3.5 h-3.5 text-rose-400" />
              <span>3D DIGITAL TWINS</span>
            </div>
            <div className="text-2xl sm:text-3xl font-black text-rose-400 font-mono">
              <AnimatedCounter value={6} duration={800} suffix=" ORGANS" />
            </div>
            <div className="text-[10px] text-rose-300">Coronary, Neuro, Renal+</div>
          </div>
        </div>
      </motion.div>

      {/* Three Main Portals Bento Grid with 3D Perspective Hover Motion */}
      <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-3 gap-6 relative z-10">
        {/* Patient Portal Card */}
        <motion.div
          whileHover={{ y: -8, scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          transition={{ type: 'spring', stiffness: 300, damping: 20 }}
          onClick={() => {
            onSelectRole('patient');
            onNavigate('patient-dashboard');
          }}
          className="p-6 rounded-3xl bg-[#080e1c] border border-white/10 hover:border-[#00d4b4]/60 transition-all cursor-pointer group shadow-xl hover:shadow-[#00d4b4]/20 space-y-4 relative overflow-hidden"
        >
          {/* Subtle Corner Glow Accent */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#00d4b4]/10 rounded-full blur-2xl group-hover:bg-[#00d4b4]/25 transition-colors pointer-events-none" />

          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-[#00d4b4]/20 to-[#4f8cff]/20 text-[#00d4b4] border border-[#00d4b4]/30 flex items-center justify-center group-hover:scale-110 group-hover:rotate-3 transition-transform shadow-md">
            <User className="w-6 h-6" />
          </div>

          <div>
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-slate-100 group-hover:text-[#00d4b4] transition-colors">
                Patient Care Portal
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#00d4b4]/10 border border-[#00d4b4]/30 text-[#00d4b4]">
                ACTIVE
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Real-time physiological telemetry, 100-tree cardiovascular forest predictor, AI lab vision, and autonomous medicine deliveries.
            </p>
          </div>

          <div className="space-y-2 pt-2 border-t border-white/5 text-xs text-slate-300">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#00d4b4]" />
              <span>Continuous PPG/ECG &amp; CGM Sync</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#00d4b4]" />
              <span>Full-Body In Silico Digital Twin</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#00d4b4]" />
              <span>108 Rapid SOS Response</span>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs font-bold text-[#00d4b4] pt-2">
            <span>Access Patient Suite</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1.5 transition-transform" />
          </div>
        </motion.div>

        {/* Doctor Portal Card */}
        <motion.div
          whileHover={{ y: -8, scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          transition={{ type: 'spring', stiffness: 300, damping: 20 }}
          onClick={() => {
            onSelectRole('doctor');
            onNavigate('doctor-dashboard');
          }}
          className="p-6 rounded-3xl bg-[#080e1c] border border-white/10 hover:border-[#4f8cff]/60 transition-all cursor-pointer group shadow-xl hover:shadow-[#4f8cff]/20 space-y-4 relative overflow-hidden"
        >
          {/* Corner Glow */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-[#4f8cff]/10 rounded-full blur-2xl group-hover:bg-[#4f8cff]/25 transition-colors pointer-events-none" />

          <div className="w-12 h-12 rounded-2xl bg-[#4f8cff]/10 text-[#4f8cff] border border-[#4f8cff]/30 flex items-center justify-center group-hover:scale-110 group-hover:-rotate-3 transition-transform shadow-md">
            <Stethoscope className="w-6 h-6" />
          </div>

          <div>
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-slate-100 group-hover:text-[#4f8cff] transition-colors">
                Doctor Clinical Cockpit
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#4f8cff]/10 border border-[#4f8cff]/30 text-[#4f8cff]">
                FHIR R4
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              AI SOAP note drafting with Gemini 3.8 Flash, live WebRTC teleconsultation, continuous patient telemetry, and digital Rx dispatch.
            </p>
          </div>

          <div className="space-y-2 pt-2 border-t border-white/5 text-xs text-slate-300">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#4f8cff]" />
              <span>FHIR Structured AI SOAP Drafter</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#4f8cff]" />
              <span>HD Video Telehealth with Live HUD</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-[#4f8cff]" />
              <span>Allergy &amp; Interaction Guardrails</span>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs font-bold text-[#4f8cff] pt-2">
            <span>Access Physician Cockpit</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1.5 transition-transform" />
          </div>
        </motion.div>

        {/* Admin Command Center Card */}
        <motion.div
          whileHover={{ y: -8, scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          transition={{ type: 'spring', stiffness: 300, damping: 20 }}
          onClick={() => {
            onSelectRole('admin');
            onNavigate('admin-dashboard');
          }}
          className="p-6 rounded-3xl bg-[#080e1c] border border-white/10 hover:border-emerald-500/60 transition-all cursor-pointer group shadow-xl hover:shadow-emerald-500/20 space-y-4 relative overflow-hidden"
        >
          {/* Corner Glow */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-2xl group-hover:bg-emerald-500/25 transition-colors pointer-events-none" />

          <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center justify-center group-hover:scale-110 group-hover:rotate-3 transition-transform shadow-md">
            <Building2 className="w-6 h-6" />
          </div>

          <div>
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-bold text-slate-100 group-hover:text-emerald-400 transition-colors">
                Regional Health Command
              </h3>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
                DISTRICT 108
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              District-wide bed balancing, 108 autonomous ambulance telemetry, liquid oxygen levels, and AI model inference metrics.
            </p>
          </div>

          <div className="space-y-2 pt-2 border-t border-white/5 text-xs text-slate-300">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>SVIMS &amp; Regional Bed Census</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Autonomous GPS Fleet Dispatch</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>Inference Latency &amp; Token Ops</span>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs font-bold text-emerald-400 pt-2">
            <span>Access District Command</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1.5 transition-transform" />
          </div>
        </motion.div>
      </div>

      {/* Featured 3D Anatomical Twin Interactive Callout */}
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="max-w-6xl mx-auto px-4"
      >
        <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-rose-950/40 via-[#0a152d] to-cyan-950/40 border border-cyan-500/30 shadow-2xl relative overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="absolute -top-10 -right-10 w-60 h-60 bg-cyan-500/10 blur-3xl pointer-events-none rounded-full" />
          <div className="flex items-center gap-4 relative z-10">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-rose-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-cyan-500/20 shrink-0 animate-pulse-slow">
              <Heart className="w-7 h-7 text-white fill-white/40" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-black text-white">
                  6 Multi-Organ 3D Anatomical Digital Twins
                </h3>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-bold">
                  HIGH-FIDELITY
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl">
                Explore Heart, Brain, Lungs, Kidneys, Liver, and Spine in interactive 3D with multiplanar cross-sections, real-time hemodynamic simulators, and AI DICOM pathology detectors.
              </p>
            </div>
          </div>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onNavigate('anatomical-models')}
            className="w-full md:w-auto px-6 py-3.5 rounded-2xl bg-gradient-to-r from-rose-500 via-purple-600 to-cyan-500 hover:opacity-90 text-white text-xs font-bold transition-all shadow-xl shadow-purple-600/30 flex items-center justify-center gap-2 shrink-0 z-10"
          >
            <span>Launch 3D Anatomy Suite</span>
            <ArrowRight className="w-4 h-4" />
          </motion.button>
        </div>
      </motion.div>

      {/* District Telemetry Highlight Banner */}
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6 }}
        className="max-w-6xl mx-auto px-4"
      >
        <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-r from-[#080e1c] via-[#0b1425] to-[#080e1c] border border-white/10 shadow-2xl flex flex-col md:flex-row md:items-center justify-between gap-6 relative overflow-hidden">
          <div className="space-y-2">
            <span className="text-[10px] font-mono uppercase px-2.5 py-0.5 rounded bg-rose-500/20 text-rose-400 border border-rose-500/30 inline-flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
              DISTRICT 108 EMERGENCY NETWORK
            </span>
            <h3 className="text-2xl font-bold text-white">
              Tirupati Healthcare Interconnect
            </h3>
            <p className="text-xs text-slate-400 max-w-xl">
              Connected across Sri Venkateswara Institute of Medical Sciences (SVIMS), AIIMS Regional Node, Ruia Government General Hospital, Apollo, and Amara Hospitals.
            </p>
          </div>

          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => onNavigate('emergency-sos')}
            className="px-6 py-3.5 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-xl shadow-rose-600/30 flex items-center gap-2 shrink-0 self-start md:self-auto"
          >
            <AlertTriangle className="w-4 h-4 animate-bounce" />
            <span>Simulate 108 Emergency Dispatch</span>
          </motion.button>
        </div>
      </motion.div>
    </div>
  );
};
