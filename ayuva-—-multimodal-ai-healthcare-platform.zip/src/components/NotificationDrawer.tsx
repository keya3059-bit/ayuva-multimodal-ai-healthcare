import React from 'react';
import { X, Pill, CalendarCheck, FileText, Truck, Bell } from 'lucide-react';
import { NotificationItem } from '../types';

interface NotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: NotificationItem[];
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({
  isOpen,
  onClose,
  notifications,
}) => {
  if (!isOpen) return null;

  return (
    <>
      <div
        className="fixed inset-0 bg-black/50 backdrop-blur-xs z-40"
        onClick={onClose}
      />
      <div className="fixed top-0 right-0 bottom-0 w-84 sm:w-96 bg-[#080e1c] border-l border-white/10 z-50 flex flex-col shadow-2xl animate-in slide-in-from-right duration-300">
        <div className="p-4 border-b border-white/10 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-4 h-4 text-[#00d4b4]" />
            <h3 className="font-bold text-sm text-slate-100">Notifications</h3>
            <span className="text-[10px] font-mono px-1.5 py-0.5 rounded-full bg-[#00d4b4]/15 text-[#00d4b4] border border-[#00d4b4]/30">
              {notifications.length} NEW
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-2.5">
          {notifications.map((item) => (
            <div
              key={item.id}
              className={`p-3 rounded-xl border flex items-start gap-3 transition-all ${
                item.type === 'urgent'
                  ? 'bg-rose-950/20 border-rose-500/30'
                  : item.type === 'ok'
                  ? 'bg-emerald-950/20 border-emerald-500/30'
                  : 'bg-cyan-950/20 border-cyan-500/30'
              }`}
            >
              <div
                className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                  item.type === 'urgent'
                    ? 'bg-rose-500/20 text-rose-400'
                    : item.type === 'ok'
                    ? 'bg-emerald-500/20 text-emerald-400'
                    : 'bg-cyan-500/20 text-cyan-400'
                }`}
              >
                {item.title.includes('Medication') && <Pill className="w-4 h-4" />}
                {item.title.includes('Appointment') && <CalendarCheck className="w-4 h-4" />}
                {item.title.includes('Lab') && <FileText className="w-4 h-4" />}
                {item.title.includes('Dispatched') && <Truck className="w-4 h-4" />}
                {!item.title.match(/Medication|Appointment|Lab|Dispatched/) && (
                  <Bell className="w-4 h-4" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1">
                  <div className="text-xs font-semibold text-slate-200 truncate">
                    {item.title}
                  </div>
                  <span className="text-[10px] font-mono text-slate-400 shrink-0">
                    {item.time}
                  </span>
                </div>
                <div className="text-[11px] text-slate-400 leading-relaxed mt-0.5">
                  {item.subtitle}
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="p-3 border-t border-white/10 text-center">
          <button
            onClick={onClose}
            className="w-full py-2 rounded-lg bg-white/5 hover:bg-white/10 text-xs font-medium text-slate-300 transition-colors"
          >
            Close Notifications
          </button>
        </div>
      </div>
    </>
  );
};
