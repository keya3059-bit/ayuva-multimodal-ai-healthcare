import React, { useState, useEffect, useRef } from 'react';
import { Watch, Radio, Battery, Wifi, RefreshCw, CheckCircle2, AlertCircle } from 'lucide-react';

interface WearableDevice {
  id: string;
  name: string;
  type: string;
  battery: number;
  status: 'connected' | 'syncing' | 'offline';
  lastSync: string;
}

export const WearablesManager: React.FC = () => {
  const [devices, setDevices] = useState<WearableDevice[]>([
    {
      id: 'DEV-WATCH-01',
      name: 'Ayuva BioWatch Ultra',
      type: 'Wrist PPG + 1-Lead ECG',
      battery: 86,
      status: 'connected',
      lastSync: '10s ago',
    },
    {
      id: 'DEV-CGM-02',
      name: 'Dexcom G7 Continuous Glucose Sensor',
      type: 'Subcutaneous Interstitial Biosensor',
      battery: 64,
      status: 'connected',
      lastSync: '1m ago',
    },
    {
      id: 'DEV-DISP-03',
      name: 'Ayuva Smart Pill Dispenser',
      type: 'NFC Blister & Weighing Cell',
      battery: 92,
      status: 'connected',
      lastSync: '12m ago',
    },
    {
      id: 'DEV-RING-04',
      name: 'Oura Heritage Smart Ring Gen 4',
      type: 'Pulse Oximetry & Dermal Temp',
      battery: 78,
      status: 'connected',
      lastSync: '30s ago',
    },
  ]);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Live 60-second PPG Waveform
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frame = 0;
    let animId: number;

    const render = () => {
      frame++;
      const W = canvas.width;
      const H = canvas.height;

      ctx.fillStyle = '#060c18';
      ctx.fillRect(0, 0, W, H);

      // Grid
      ctx.strokeStyle = 'rgba(0, 212, 180, 0.05)';
      ctx.lineWidth = 1;
      for (let x = 0; x < W; x += 30) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, H);
        ctx.stroke();
      }
      for (let y = 0; y < H; y += 30) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(W, y);
        ctx.stroke();
      }

      // ECG / PPG Wave
      ctx.beginPath();
      ctx.strokeStyle = '#00d4b4';
      ctx.lineWidth = 2;
      ctx.shadowColor = '#00d4b4';
      ctx.shadowBlur = 8;

      for (let x = 0; x < W; x++) {
        const t = (x + frame * 3) % 180;
        let yOffset = 0;

        if (t > 40 && t < 48) {
          // P wave
          yOffset = -8 * Math.sin(((t - 40) / 8) * Math.PI);
        } else if (t > 68 && t < 72) {
          // Q dip
          yOffset = 6;
        } else if (t >= 72 && t <= 78) {
          // R peak
          yOffset = -50 * Math.sin(((t - 72) / 6) * Math.PI);
        } else if (t > 78 && t < 82) {
          // S dip
          yOffset = 12;
        } else if (t > 105 && t < 125) {
          // T wave
          yOffset = -14 * Math.sin(((t - 105) / 20) * Math.PI);
        }

        const y = H / 2 + yOffset;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.shadowBlur = 0;

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            Connected <span>IoT Devices</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // BLE 5.4 · END-TO-END CRYPTOGRAPHIC KEY EXCHANGE · TELEMETRY INGESTION
          </div>
        </div>

        <button
          onClick={() => {
            alert('Broadcasting BLE scan for Ayuva-compatible medical peripherals…');
          }}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs shadow-md hover:opacity-90 self-start sm:self-auto"
        >
          <Radio className="w-4 h-4" />
          <span>Pair New Peripheral</span>
        </button>
      </div>

      {/* Live Waveform Stream */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-[#00d4b4]" />
            <h3 className="font-bold text-sm text-slate-100">Live 1-Lead PPG/ECG Stream</h3>
          </div>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 animate-pulse">
            250 Hz SAMPLE RATE
          </span>
        </div>

        <div className="rounded-xl overflow-hidden border border-white/10">
          <canvas ref={canvasRef} width={720} height={160} className="w-full h-auto" />
        </div>
      </div>

      {/* Devices Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {devices.map((d) => (
          <div
            key={d.id}
            className="p-4 sm:p-5 rounded-2xl bg-[#080e1c] border border-white/10 hover:border-white/20 transition-all shadow-xl flex items-start justify-between gap-4"
          >
            <div className="flex items-start gap-3.5">
              <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-[#00d4b4]/10 to-[#4f8cff]/10 text-[#00d4b4] border border-[#00d4b4]/20 flex items-center justify-center shrink-0">
                <Watch className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-bold text-sm text-slate-100">{d.name}</h4>
                <div className="text-xs text-slate-400 font-mono mt-0.5">{d.type}</div>
                <div className="text-[10px] font-mono text-[#00d4b4] mt-1.5 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>Synced {d.lastSync}</span>
                </div>
              </div>
            </div>

            <div className="text-right shrink-0">
              <div className="flex items-center gap-1.5 justify-end font-mono text-xs text-slate-300">
                <Battery className="w-3.5 h-3.5 text-emerald-400" />
                <span>{d.battery}%</span>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 inline-block mt-2">
                ACTIVE
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
