import React, { useState } from 'react';
import { Pill, CheckCircle2, Clock, Plus, Bell, Flame, Calendar as CalendarIcon, AlertCircle } from 'lucide-react';
import { Medication } from '../../types';
import { MEDICATIONS } from '../../data/mockData';

export const MedicationReminders: React.FC = () => {
  const [meds, setMeds] = useState<Medication[]>(MEDICATIONS);
  const [streak, setStreak] = useState(14);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newMedName, setNewMedName] = useState('');
  const [newMedDosage, setNewMedDosage] = useState('');
  const [newMedTime, setNewMedTime] = useState('08:00 AM');

  const toggleTake = (id: string) => {
    setMeds((prev) =>
      prev.map((m) => {
        if (m.id === id) {
          const updated = !m.taken;
          return { ...m, taken: updated };
        }
        return m;
      })
    );
  };

  const handleAddMed = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMedName) return;
    const newMed: Medication = {
      id: `med-${Date.now()}`,
      name: newMedName,
      dosage: newMedDosage || '1 tablet',
      frequency: 'Once daily',
      time: newMedTime,
      taken: false,
      remaining: 30,
    };
    setMeds([...meds, newMed]);
    setNewMedName('');
    setNewMedDosage('');
    setShowAddModal(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            Medication <span>Smart Schedule</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // NFC BLISTER PACK SYNC · SMART DISPENSER ACTIVE · 100% ADHERENCE
          </div>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs shadow-md hover:opacity-90 transition-opacity self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Medication</span>
        </button>
      </div>

      {/* Streak and Summary Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center shrink-0">
            <Flame className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-bold font-mono text-amber-300">{streak} Days</div>
            <div className="text-[11px] text-slate-400 font-mono">Consecutive Adherence Streak</div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#00d4b4]/15 text-[#00d4b4] flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-bold font-mono text-[#00d4b4]">
              {meds.filter((m) => m.taken).length} / {meds.length}
            </div>
            <div className="text-[11px] text-slate-400 font-mono">Doses Completed Today</div>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[#4f8cff]/15 text-[#4f8cff] flex items-center justify-center shrink-0">
            <Bell className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-bold font-mono text-[#4f8cff]">Next: 08:00 PM</div>
            <div className="text-[11px] text-slate-400 font-mono">Evening Doses Standby</div>
          </div>
        </div>
      </div>

      {/* Today's Schedule Cards */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
        <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
          <Clock className="w-4 h-4 text-[#00d4b4]" />
          <span>Today's Prescribed Regimen</span>
        </h3>

        <div className="space-y-3">
          {meds.map((m) => (
            <div
              key={m.id}
              className={`p-4 rounded-xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                m.taken
                  ? 'bg-[#00d4b4]/5 border-[#00d4b4]/30'
                  : 'bg-[#0b1425] border-white/5'
              }`}
            >
              <div className="flex items-start gap-3.5">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                    m.taken
                      ? 'bg-[#00d4b4]/20 text-[#00d4b4]'
                      : 'bg-white/[0.05] text-slate-400'
                  }`}
                >
                  <Pill className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h4
                      className={`font-bold text-sm ${
                        m.taken ? 'text-slate-300 line-through' : 'text-slate-100'
                      }`}
                    >
                      {m.name}
                    </h4>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/[0.04] text-slate-400 border border-white/5">
                      {m.dosage}
                    </span>
                  </div>
                  <div className="text-xs text-slate-400 font-mono mt-0.5">
                    {m.frequency} · Scheduled for {m.time}
                  </div>
                  <div className="text-[11px] text-[#00d4b4] font-mono mt-1">
                    {m.remaining} pills left in smart dispenser
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2 self-end sm:self-center">
                <button
                  onClick={() => toggleTake(m.id)}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                    m.taken
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/40'
                      : 'bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black shadow-md'
                  }`}
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{m.taken ? 'Marked Taken' : 'Take Dose'}</span>
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Add Medication Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="max-w-md w-full rounded-2xl bg-[#080e1c] border border-white/10 p-6 space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-100">Add New Medication</h3>
                <div className="text-xs text-slate-400 font-mono">Syncs with smart dispenser</div>
              </div>
              <button
                onClick={() => setShowAddModal(false)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddMed} className="space-y-3">
              <div>
                <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
                  Medication Name
                </label>
                <input
                  type="text"
                  required
                  value={newMedName}
                  onChange={(e) => setNewMedName(e.target.value)}
                  placeholder="e.g. Lisinopril"
                  className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-[#00d4b4]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
                  Dosage / Strength
                </label>
                <input
                  type="text"
                  required
                  value={newMedDosage}
                  onChange={(e) => setNewMedDosage(e.target.value)}
                  placeholder="e.g. 10mg once daily"
                  className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-[#00d4b4]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
                  Scheduled Time
                </label>
                <input
                  type="text"
                  value={newMedTime}
                  onChange={(e) => setNewMedTime(e.target.value)}
                  placeholder="08:00 AM"
                  className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-[#00d4b4]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 rounded-xl bg-white/[0.05] text-xs font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs"
                >
                  Save Schedule
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
