import React, { useState, useEffect, useRef } from 'react';
import { Brain, Video, Wifi, Building2, Play, RotateCcw, AlertTriangle, Upload, CheckCircle2 } from 'lucide-react';

interface IoTDevice {
  id: string;
  name: string;
  val: number;
  unit: string;
  status: 'ok' | 'warn' | 'danger';
}

export const MultimodalHub: React.FC = () => {
  const [devices, setDevices] = useState<IoTDevice[]>([
    { id: 'IOT-HR-01', name: 'Chest ECG Patch', val: 72, unit: 'BPM', status: 'ok' },
    { id: 'IOT-SPO2-02', name: 'Continuous Pulse Ox', val: 98, unit: '%', status: 'ok' },
    { id: 'IOT-TEMP-03', name: 'Dermal Thermistor', val: 36.8, unit: '°C', status: 'ok' },
    { id: 'IOT-GLU-04', name: 'CGM Sensor G7', val: 114, unit: 'mg/dL', status: 'warn' },
    { id: 'IOT-BP-05', name: 'Cuffless BP Watch', val: 124, unit: 'mmHg', status: 'ok' },
    { id: 'IOT-RESP-06', name: 'Thoracic Strain Gauge', val: 14, unit: '/min', status: 'ok' },
    { id: 'IOT-ACT-07', name: 'Accelerometer 6-Axis', val: 8240, unit: 'steps', status: 'ok' },
    { id: 'IOT-HRV-08', name: 'Autonomic HRV', val: 54, unit: 'ms', status: 'ok' },
  ]);

  const [fusionState, setFusionState] = useState<'idle' | 'running' | 'complete'>('idle');
  const [confidence, setConfidence] = useState('94.8%');
  const [latency, setLatency] = useState('184 ms');
  const [reportNote, setReportNote] = useState<string | null>(null);

  const cameraCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const fusionCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Live telemetry pulse
  useEffect(() => {
    const interval = setInterval(() => {
      setDevices((prev) =>
        prev.map((d) => {
          const delta = (Math.random() - 0.5) * (d.unit === 'steps' ? 40 : d.unit === 'mg/dL' ? 3 : 1.2);
          const newVal = +(d.val + delta).toFixed(d.unit === '°C' ? 1 : 0);
          return {
            ...d,
            val: newVal,
            status: d.id.includes('GLU') && newVal > 130 ? 'danger' : d.id.includes('GLU') && newVal > 110 ? 'warn' : 'ok',
          };
        })
      );
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  // Camera feed canvas animation (scanline + bounding boxes)
  useEffect(() => {
    const canvas = cameraCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frame = 0;
    let animId: number;

    const render = () => {
      frame++;
      const W = canvas.width;
      const H = canvas.height;

      // Dark clinical canvas
      ctx.fillStyle = '#060c18';
      ctx.fillRect(0, 0, W, H);

      // Simulated skin texture / silhouette
      const grd = ctx.createRadialGradient(W * 0.5, H * 0.52, 20, W * 0.5, H * 0.52, 130);
      grd.addColorStop(0, 'rgba(180, 110, 95, 0.45)');
      grd.addColorStop(1, 'rgba(25, 30, 45, 0.2)');
      ctx.fillStyle = grd;
      ctx.beginPath();
      ctx.ellipse(W * 0.5, H * 0.52, 110, 75, 0, 0, Math.PI * 2);
      ctx.fill();

      // Bounding box ROI
      const bX = W * 0.32;
      const bY = H * 0.28;
      const bW = 85;
      const bH = 65;

      ctx.strokeStyle = '#00d4b4';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 3]);
      ctx.strokeRect(bX, bY, bW, bH);
      ctx.setLineDash([]);

      ctx.fillStyle = 'rgba(0, 212, 180, 0.2)';
      ctx.fillRect(bX, bY - 14, bW, 14);
      ctx.fillStyle = '#00d4b4';
      ctx.font = '9px JetBrains Mono, monospace';
      ctx.fillText('Derm ROI 94%', bX + 4, bY - 3);

      // Moving scanline
      const scanY = (frame * 1.8) % H;
      ctx.strokeStyle = 'rgba(0, 212, 180, 0.35)';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(0, scanY);
      ctx.lineTo(W, scanY);
      ctx.stroke();

      // Tracking landmarks
      for (let i = 0; i < 6; i++) {
        const px = W * 0.35 + Math.sin(frame * 0.04 + i) * 30 + i * 14;
        const py = H * 0.4 + Math.cos(frame * 0.03 + i) * 15;
        ctx.beginPath();
        ctx.arc(px, py, 2.5, 0, Math.PI * 2);
        ctx.fillStyle = '#4f8cff';
        ctx.fill();
      }

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, []);

  // Fusion canvas architecture diagram
  useEffect(() => {
    const canvas = fusionCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    const modalities = [
      { name: 'Vision', color: '#ff6b9d', x: 50 },
      { name: 'IoT Streams', color: '#00d4b4', x: 140 },
      { name: 'HL7 Machines', color: '#4f8cff', x: 230 },
      { name: 'Lab Reports', color: '#fbbf24', x: 320 },
    ];

    const fuseX = W - 60;
    const fuseY = H / 2;

    modalities.forEach((m) => {
      ctx.beginPath();
      ctx.arc(m.x, H / 2, 16, 0, Math.PI * 2);
      ctx.fillStyle = m.color;
      ctx.fill();

      ctx.fillStyle = 'rgba(232, 240, 254, 0.8)';
      ctx.font = '10px JetBrains Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(m.name, m.x, H / 2 + 28);

      // Connection lines
      ctx.beginPath();
      ctx.moveTo(m.x + 16, H / 2);
      ctx.lineTo(fuseX - 20, fuseY);
      ctx.strokeStyle = fusionState === 'complete' ? m.color : 'rgba(255, 255, 255, 0.1)';
      ctx.lineWidth = fusionState === 'complete' ? 2 : 1;
      ctx.stroke();
    });

    // Central Fusion Hub
    ctx.beginPath();
    ctx.arc(fuseX, fuseY, 20, 0, Math.PI * 2);
    ctx.fillStyle = fusionState === 'complete' ? '#00d4b4' : '#1e293b';
    ctx.fill();
    ctx.strokeStyle = '#00d4b4';
    ctx.lineWidth = 2;
    ctx.stroke();

    ctx.fillStyle = fusionState === 'complete' ? '#000' : '#e8f0fe';
    ctx.font = 'bold 9px JetBrains Mono, monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText('FUSE', fuseX, fuseY);
  }, [fusionState]);

  const handleRunInference = () => {
    setFusionState('running');
    setTimeout(() => {
      setFusionState('complete');
      setConfidence((92 + Math.random() * 6).toFixed(1) + '%');
      setLatency((160 + Math.random() * 50).toFixed(0) + ' ms');
    }, 1200);
  };

  const handleReportUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setReportNote(`Ingested ${file.name} (OCR extracted 12 clinical entities). Cross-modal attention mapped to glycemic cluster.`);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            Multimodal <span>Neural Network Hub</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // REAL-TIME FUSION · CLINICAL CAMERA · IoT WEARABLES · HL7 HOSPITAL MACHINES · 2030
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleRunInference}
            disabled={fusionState === 'running'}
            className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs shadow-lg shadow-[#00d4b4]/20 hover:opacity-90 transition-opacity"
          >
            <Play className="w-3.5 h-3.5 fill-black" />
            <span>{fusionState === 'running' ? 'Fusing Modalities…' : 'Run Multimodal Fusion'}</span>
          </button>
          <button
            onClick={() => setFusionState('idle')}
            className="p-1.5 rounded-xl bg-white/[0.04] border border-white/10 text-slate-400 hover:text-white"
            title="Reset Streams"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Tri-Column Modality Ingestion Feeds */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Modality 1: Clinical Camera */}
        <div className="p-5 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-xs text-slate-100 flex items-center gap-1.5">
              <Video className="w-4 h-4 text-rose-400" />
              <span>Clinical Camera Feed</span>
            </h3>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-rose-500/15 text-rose-400 border border-rose-500/30 animate-pulse">
              LIVE 30FPS
            </span>
          </div>

          <div className="relative rounded-xl overflow-hidden border border-white/10 bg-black">
            <canvas ref={cameraCanvasRef} width={320} height={200} className="w-full h-auto" />
            <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/70 text-[9px] font-mono text-rose-300">
              CAM-01 · AI DERM / POSTURE
            </div>
            <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-black/70 text-[9px] font-mono text-slate-300">
              Vision Transformer ON
            </div>
          </div>
          <div className="text-[11px] text-slate-400 font-mono">
            Spatial attention: 0.34 · Edge gradient nominal
          </div>
        </div>

        {/* Modality 2: IoT Telemetry Streams */}
        <div className="p-5 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-xs text-slate-100 flex items-center gap-1.5">
              <Wifi className="w-4 h-4 text-[#00d4b4]" />
              <span>Live IoT Sensor Grid</span>
            </h3>
            <span className="text-[10px] font-mono text-slate-400">{devices.length} NODES</span>
          </div>

          <div className="space-y-1.5 max-h-[200px] overflow-y-auto pr-1">
            {devices.map((d) => (
              <div
                key={d.id}
                className="p-2 rounded-lg bg-[#0b1425] border border-white/5 flex items-center justify-between text-xs"
              >
                <div className="truncate pr-2">
                  <div className="font-semibold text-slate-200 text-[11px]">{d.name}</div>
                  <div className="text-[9px] font-mono text-slate-500">{d.id}</div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <span className="font-mono text-[#00d4b4] font-bold text-[11px]">
                    {d.val} {d.unit}
                  </span>
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      d.status === 'ok' ? 'bg-emerald-400' : 'bg-amber-400 animate-pulse'
                    }`}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Modality 3: Hospital Machine HL7 / FHIR */}
        <div className="p-5 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-xs text-slate-100 flex items-center gap-1.5">
              <Building2 className="w-4 h-4 text-[#4f8cff]" />
              <span>Hospital Machine Feeds</span>
            </h3>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#4f8cff]/15 text-[#4f8cff] border border-[#4f8cff]/30">
              HL7 / FHIR
            </span>
          </div>

          <div className="space-y-2">
            <div className="p-2.5 rounded-xl bg-[#0b1425] border border-white/5 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-[#4f8cff]/15 flex items-center justify-center text-[#4f8cff] shrink-0">
                🫀
              </div>
              <div className="min-w-0 flex-1 text-xs">
                <div className="font-bold text-slate-200">ICU Bedside Holter Monitor</div>
                <div className="text-[10px] font-mono text-slate-400">NSR · QTc 410ms · ST Seg 0mm</div>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 font-bold">NORMAL</span>
            </div>

            <div className="p-2.5 rounded-xl bg-[#0b1425] border border-white/5 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-[#00d4b4]/15 flex items-center justify-center text-[#00d4b4] shrink-0">
                🫁
              </div>
              <div className="min-w-0 flex-1 text-xs">
                <div className="font-bold text-slate-200">Ventilator Telemetry</div>
                <div className="text-[10px] font-mono text-slate-400">FiO2 0.35 · PEEP 5cmH2O · P/F 380</div>
              </div>
              <span className="text-[10px] font-mono text-emerald-400 font-bold">STABLE</span>
            </div>

            <div className="p-2.5 rounded-xl bg-[#0b1425] border border-white/5 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-amber-500/15 flex items-center justify-center text-amber-400 shrink-0">
                🧪
              </div>
              <div className="min-w-0 flex-1 text-xs">
                <div className="font-bold text-slate-200">Point-of-Care Blood Gas</div>
                <div className="text-[10px] font-mono text-slate-400">pH 7.39 · pCO2 38 · HCO3 24</div>
              </div>
              <span className="text-[10px] font-mono text-amber-400 font-bold">REVIEW</span>
            </div>
          </div>
        </div>
      </div>

      {/* Fusion Engine Architecture & Live Anomaly Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Fusion Architecture Canvas */}
        <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <Brain className="w-4 h-4 text-[#00d4b4]" />
              <span>Cross-Attention Transformer Fusion</span>
            </h3>
            <span
              className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                fusionState === 'complete'
                  ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                  : 'bg-slate-800 text-slate-400 border-slate-700'
              }`}
            >
              STATUS: {fusionState.toUpperCase()}
            </span>
          </div>

          <div className="rounded-xl bg-[#0b1425] p-3 border border-white/5">
            <canvas ref={fusionCanvasRef} width={420} height={100} className="w-full" />
          </div>

          <div className="grid grid-cols-2 gap-3 pt-1">
            <div className="p-3 rounded-xl bg-[#0b1425] border border-white/5 text-center">
              <div className="text-xl font-bold font-mono text-[#00d4b4]">{confidence}</div>
              <div className="text-[10px] font-mono uppercase text-slate-400 mt-0.5">
                Cross-Modal Alignment
              </div>
            </div>
            <div className="p-3 rounded-xl bg-[#0b1425] border border-white/5 text-center">
              <div className="text-xl font-bold font-mono text-[#4f8cff]">{latency}</div>
              <div className="text-[10px] font-mono uppercase text-slate-400 mt-0.5">
                Inference Latency
              </div>
            </div>
          </div>
        </div>

        {/* Real-Time Cross-Modal Anomalies */}
        <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-3">
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-400" />
              <span>Real-Time Anomaly Detection</span>
            </h3>
            <span className="text-[10px] font-mono text-emerald-400">ACTIVE MONITOR</span>
          </div>

          <div className="space-y-2.5">
            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-slate-200">
              <div className="flex items-center justify-between font-bold text-amber-300 mb-1">
                <span>Post-Meal Glycemic Elevation</span>
                <span className="font-mono text-[10px]">CGM + TIME FUSION</span>
              </div>
              <p className="text-slate-400 leading-relaxed text-[11px]">
                Continuous glucose monitor registered a +28 mg/dL delta post-lunch. Cross-referenced with food diary log. Recommend 15-min walk.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-xs text-slate-200">
              <div className="flex items-center justify-between font-bold text-cyan-300 mb-1">
                <span>Dermal Lesion Texture Invariant</span>
                <span className="font-mono text-[10px]">VISION TRANSFORMER</span>
              </div>
              <p className="text-slate-400 leading-relaxed text-[11px]">
                Dermal camera ROI confirms stable symmetry and color distribution compared with baseline reference (Mar 22). No progression detected.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-slate-200">
              <div className="flex items-center justify-between font-bold text-emerald-300 mb-1">
                <span>Cardiopulmonary Coupling Normal</span>
                <span className="font-mono text-[10px]">ECG + RESP STRAIN</span>
              </div>
              <p className="text-slate-400 leading-relaxed text-[11px]">
                Respiratory sinus arrhythmia confirms intact autonomic balance (HRV 54ms). Heart rate response to deep breathing is optimal.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Report Ingestion Dropzone */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl">
        <h3 className="font-bold text-sm text-slate-100 mb-3 flex items-center gap-2">
          <Upload className="w-4 h-4 text-[#00d4b4]" />
          <span>Real-Time Medical Document Ingestion (OCR + Multimodal Embedding)</span>
        </h3>

        <div className="border-2 border-dashed border-white/15 rounded-xl p-6 text-center hover:border-[#00d4b4] transition-colors cursor-pointer relative bg-white/[0.01]">
          <input
            type="file"
            accept=".pdf,image/*"
            onChange={handleReportUpload}
            className="absolute inset-0 opacity-0 cursor-pointer"
          />
          <div className="w-10 h-10 rounded-full bg-[#00d4b4]/10 text-[#00d4b4] mx-auto flex items-center justify-center mb-2">
            <Upload className="w-5 h-5" />
          </div>
          <div className="text-xs font-semibold text-slate-200">
            Click or drag &amp; drop medical reports (DICOM, PDF, PNG)
          </div>
          <div className="text-[11px] text-slate-500 font-mono mt-0.5">
            Auto-parsed into clinical vector space &amp; fused with live IoT streams
          </div>
        </div>

        {reportNote && (
          <div className="p-3 rounded-xl bg-[#00d4b4]/10 border border-[#00d4b4]/30 mt-3 text-xs text-slate-200 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-[#00d4b4] shrink-0" />
            <span>{reportNote}</span>
          </div>
        )}
      </div>
    </div>
  );
};
