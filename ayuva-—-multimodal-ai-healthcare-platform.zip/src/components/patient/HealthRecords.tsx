import React, { useState } from 'react';
import { FileText, Download, Eye, Plus, ShieldCheck, Search, Filter, Calendar } from 'lucide-react';
import { HEALTH_RECORDS } from '../../data/mockData';
import { HealthRecord } from '../../types';

export const HealthRecords: React.FC = () => {
  const [records, setRecords] = useState<HealthRecord[]>(HEALTH_RECORDS);
  const [filterType, setFilterType] = useState('ALL');
  const [search, setSearch] = useState('');
  const [selectedRecord, setSelectedRecord] = useState<HealthRecord | null>(null);

  const filtered = records.filter((r) => {
    const matchesFilter = filterType === 'ALL' || r.type === filterType;
    const matchesSearch =
      r.title.toLowerCase().includes(search.toLowerCase()) ||
      r.doctor.toLowerCase().includes(search.toLowerCase()) ||
      r.summary.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            Electronic <span>Health Records (EHR)</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // FHIR R4 COMPLIANT · END-TO-END ENCRYPTED · ABHA INTEGRATED
          </div>
        </div>
        <button
          onClick={() => {
            const newRec: HealthRecord = {
              id: `rec-${Date.now()}`,
              title: 'Self-Logged Biomarker Assessment',
              date: new Date().toISOString().split('T')[0],
              type: 'LAB',
              doctor: 'Patient Self-Entry',
              summary: 'Continuous glucose profile export & wearable sync report.',
              fileSize: '1.2 MB',
            };
            setRecords([newRec, ...records]);
          }}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs shadow-md hover:opacity-90 transition-opacity self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Upload Record</span>
        </button>
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search documents, doctor name, clinical findings…"
            className="w-full bg-[#080e1c] border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-[#00d4b4]"
          />
        </div>

        <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
          {['ALL', 'LAB', 'PRESCRIPTION', 'IMAGING', 'SUMMARY'].map((t) => (
            <button
              key={t}
              onClick={() => setFilterType(t)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors border ${
                filterType === t
                  ? 'bg-[#00d4b4]/20 border-[#00d4b4] text-[#00d4b4]'
                  : 'bg-[#080e1c] border-white/10 text-slate-400 hover:text-white'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Document List */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((r) => (
          <div
            key={r.id}
            className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 hover:border-[#00d4b4]/40 transition-all flex flex-col justify-between space-y-3 group"
          >
            <div>
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[#00d4b4]/10 to-[#4f8cff]/10 text-[#00d4b4] border border-[#00d4b4]/20 flex items-center justify-center">
                  <FileText className="w-4 h-4" />
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-white/[0.04] text-slate-400 border border-white/5">
                  {r.type}
                </span>
              </div>

              <h4 className="font-bold text-sm text-slate-200 group-hover:text-[#00d4b4] transition-colors line-clamp-1">
                {r.title}
              </h4>
              <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                {r.doctor} · {r.date}
              </div>
              <p className="text-xs text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                {r.summary}
              </p>
            </div>

            <div className="pt-2 border-t border-white/5 flex items-center justify-between text-xs">
              <span className="text-[10px] font-mono text-slate-500">{r.fileSize}</span>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSelectedRecord(r)}
                  className="p-1.5 rounded-lg bg-white/[0.04] hover:bg-white/[0.08] text-slate-300 hover:text-white"
                  title="View Record"
                >
                  <Eye className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => alert(`Downloading FHIR encrypted bundle for ${r.title}…`)}
                  className="p-1.5 rounded-lg bg-[#00d4b4]/10 hover:bg-[#00d4b4]/20 text-[#00d4b4]"
                  title="Download PDF"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal View */}
      {selectedRecord && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="max-w-lg w-full rounded-2xl bg-[#080e1c] border border-white/10 p-6 space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-mono text-[#00d4b4] uppercase">
                  {selectedRecord.type} RECORD
                </span>
                <h3 className="text-lg font-bold text-slate-100">{selectedRecord.title}</h3>
                <div className="text-xs text-slate-400 font-mono mt-0.5">
                  Issued by {selectedRecord.doctor} on {selectedRecord.date}
                </div>
              </div>
              <button
                onClick={() => setSelectedRecord(null)}
                className="text-slate-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="p-3.5 rounded-xl bg-[#0b1425] border border-white/5 text-xs text-slate-300 leading-relaxed">
              <div className="font-mono text-[11px] text-[#00d4b4] mb-1 font-bold">
                // CLINICAL SUMMARY
              </div>
              {selectedRecord.summary}
            </div>

            <div className="text-[11px] text-slate-400 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Cryptographically verified on Ayuva Medi-Ledger (SHA-256)</span>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-white/10">
              <button
                onClick={() => setSelectedRecord(null)}
                className="px-4 py-2 rounded-xl bg-white/[0.05] text-xs font-semibold text-slate-300 hover:bg-white/[0.1]"
              >
                Close
              </button>
              <button
                onClick={() => {
                  alert(`Downloading ${selectedRecord.title}`);
                  setSelectedRecord(null);
                }}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black text-xs font-bold"
              >
                Download Official PDF
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
