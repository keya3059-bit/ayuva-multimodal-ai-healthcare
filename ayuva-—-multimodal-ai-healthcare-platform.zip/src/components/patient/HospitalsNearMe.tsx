import React, { useState } from 'react';
import { Hospital as HospitalIcon, MapPin, Phone, Clock, Search, Filter, Calendar } from 'lucide-react';
import { HOSPITALS } from '../../data/mockData';
import { Hospital } from '../../types';

interface HospitalsNearMeProps {
  onBookAtHospital: (hosp: Hospital) => void;
}

export const HospitalsNearMe: React.FC<HospitalsNearMeProps> = ({ onBookAtHospital }) => {
  const [search, setSearch] = useState('');
  const [specialtyFilter, setSpecialtyFilter] = useState('ALL');

  const filtered = HOSPITALS.filter((h) => {
    const matchesSearch =
      h.name.toLowerCase().includes(search.toLowerCase()) ||
      h.address.toLowerCase().includes(search.toLowerCase()) ||
      h.specialties.some((s) => s.toLowerCase().includes(search.toLowerCase()));

    const matchesSpecialty =
      specialtyFilter === 'ALL' || h.specialties.includes(specialtyFilter);

    return matchesSearch && matchesSpecialty;
  });

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            Hospitals &amp; <span>Trauma Centers</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // LIVE BED OCCUPANCY · TIRUPATI REGIONAL HEALTH NETWORK · 108 INTERCONNECT
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search hospitals by name, area, or specialty…"
            className="w-full bg-[#080e1c] border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-[#00d4b4]"
          />
        </div>

        <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
          {['ALL', 'Cardiology', 'Neurology', 'Oncology', 'Orthopedics', 'Emergency'].map((s) => (
            <button
              key={s}
              onClick={() => setSpecialtyFilter(s)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors border ${
                specialtyFilter === s
                  ? 'bg-[#00d4b4]/20 border-[#00d4b4] text-[#00d4b4]'
                  : 'bg-[#080e1c] border-white/10 text-slate-400 hover:text-white'
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Hospital Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {filtered.map((h) => (
          <div
            key={h.id}
            className="p-5 rounded-2xl bg-[#080e1c] border border-white/10 hover:border-white/20 transition-all shadow-xl space-y-4 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#00d4b4]/15 to-[#4f8cff]/15 text-[#00d4b4] border border-[#00d4b4]/30 flex items-center justify-center shrink-0">
                    <HospitalIcon className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="font-bold text-sm text-slate-100">{h.name}</h3>
                    <div className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                      <span className="truncate">{h.address}</span>
                    </div>
                  </div>
                </div>

                <span className="font-mono text-xs text-[#00d4b4] font-bold bg-[#00d4b4]/10 px-2 py-0.5 rounded-full border border-[#00d4b4]/30 shrink-0">
                  {h.distance}
                </span>
              </div>

              {/* Bed Availability Bar */}
              <div className="mt-4 p-3 rounded-xl bg-[#0b1425] border border-white/5 space-y-2">
                <div className="flex items-center justify-between text-xs font-semibold">
                  <span className="text-slate-300">Live Bed Availability</span>
                  <span className="font-mono text-emerald-400">
                    {h.availableBeds} / {h.totalBeds} ({h.availPercent}%)
                  </span>
                </div>
                <div className="h-2 w-full bg-black/40 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-[#00d4b4] to-emerald-400 rounded-full transition-all duration-500"
                    style={{ width: `${h.availPercent}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono pt-0.5">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3 h-3 text-slate-500" /> Wait: {h.waitTime}
                  </span>
                  <span>Trauma Level: 1</span>
                </div>
              </div>

              {/* Specialties */}
              <div className="flex flex-wrap gap-1.5 mt-3">
                {h.specialties.map((spec, idx) => (
                  <span
                    key={idx}
                    className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-white/[0.04] text-slate-300 border border-white/5"
                  >
                    {spec}
                  </span>
                ))}
              </div>
            </div>

            {/* Actions */}
            <div className="pt-3 border-t border-white/5 flex items-center justify-between gap-2">
              <a
                href={`tel:${h.phone}`}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] text-xs font-semibold text-slate-300"
              >
                <Phone className="w-3.5 h-3.5 text-[#00d4b4]" />
                <span>Call Center</span>
              </a>

              <button
                onClick={() => onBookAtHospital(h)}
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs shadow-md hover:opacity-90"
              >
                <Calendar className="w-3.5 h-3.5" />
                <span>Book Consultation</span>
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
