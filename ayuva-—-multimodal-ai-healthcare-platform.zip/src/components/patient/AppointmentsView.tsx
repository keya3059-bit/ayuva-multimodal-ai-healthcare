import React, { useState } from 'react';
import { Calendar, Clock, MapPin, User, CheckCircle2, AlertCircle, Plus, Hospital as HospitalIcon } from 'lucide-react';
import { Appointment, Hospital } from '../../types';
import { INITIAL_APPOINTMENTS, HOSPITALS } from '../../data/mockData';

interface AppointmentsViewProps {
  appointments?: Appointment[];
  hospitals?: Hospital[];
  onBookAppointment?: (newAppt: Appointment) => void;
  onSelectHospital?: (hosp: Hospital) => void;
}

export const AppointmentsView: React.FC<AppointmentsViewProps> = ({
  appointments = INITIAL_APPOINTMENTS,
  hospitals = HOSPITALS,
  onBookAppointment = (_newAppt: Appointment) => {},
  onSelectHospital = (_hosp: Hospital) => {},
}) => {
  const [doctor, setDoctor] = useState('Dr. Rajesh Kumar — Cardiologist');
  const [date, setDate] = useState('2030-04-22');
  const [time, setTime] = useState('10:00 AM');
  const [type, setType] = useState<'In-Person' | 'Telemedicine' | 'AI-Assisted'>('In-Person');
  const [symptoms, setSymptoms] = useState('');
  const [hospital, setHospital] = useState('SVIMS Super Specialty Hospital');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const docName = doctor.split('—')[0].trim();
    const specialty = doctor.split('—')[1]?.trim() || 'General';

    const newAppt: Appointment = {
      id: `apt-${Date.now()}`,
      doctorName: docName,
      specialty,
      date,
      time,
      type,
      status: 'Confirmed',
      hospital,
      symptoms: symptoms || 'General follow-up consultation',
    };

    onBookAppointment(newAppt);
    setSymptoms('');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            Book <span>Appointment</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // SMART SCHEDULING · AI TRIAGE ENABLED
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Booking Form */}
        <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl">
          <div className="flex items-center gap-2 mb-4 pb-3 border-b border-white/10">
            <Plus className="w-4 h-4 text-[#00d4b4]" />
            <h3 className="font-bold text-sm text-slate-100">Schedule Consultation</h3>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
                Select Physician
              </label>
              <select
                value={doctor}
                onChange={(e) => setDoctor(e.target.value)}
                className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-[#00d4b4]"
              >
                <option>Dr. Rajesh Kumar — Cardiologist</option>
                <option>Dr. Meera Nair — Neurologist</option>
                <option>Dr. Sanjay Patel — Orthopedic Surgeon</option>
                <option>Dr. Priya Sharma — Pediatrician</option>
                <option>Dr. Sarah Chen — Medical Oncologist</option>
                <option>Dr. Arjun Reddy — General Physician</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
                  Preferred Date
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-[#00d4b4]"
                />
              </div>
              <div>
                <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
                  Time Slot
                </label>
                <select
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-[#00d4b4]"
                >
                  <option>09:00 AM</option>
                  <option>10:00 AM</option>
                  <option>11:30 AM</option>
                  <option>02:00 PM</option>
                  <option>04:30 PM</option>
                  <option>07:00 PM (Telehealth)</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
                  Consultation Mode
                </label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value as any)}
                  className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-[#00d4b4]"
                >
                  <option value="In-Person">In-Person Visit</option>
                  <option value="Telemedicine">Telemedicine Video</option>
                  <option value="AI-Assisted">AI-Assisted Rapid Triage</option>
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
                  Hospital / Center
                </label>
                <select
                  value={hospital}
                  onChange={(e) => setHospital(e.target.value)}
                  className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-[#00d4b4]"
                >
                  {hospitals.map((h) => (
                    <option key={h.id} value={h.name}>
                      {h.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
                Symptoms or Concerns
              </label>
              <textarea
                rows={3}
                value={symptoms}
                onChange={(e) => setSymptoms(e.target.value)}
                placeholder="Describe your primary symptoms, duration, and any recent changes in medication or vitals…"
                className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-[#00d4b4]"
              />
            </div>

            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs hover:opacity-90 transition-opacity shadow-lg shadow-[#00d4b4]/20 flex items-center justify-center gap-2"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Confirm Appointment</span>
            </button>
          </form>
        </div>

        {/* Existing Appointments & Hospital Load */}
        <div className="space-y-6">
          <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl">
            <h3 className="font-bold text-sm text-slate-100 mb-3 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#4f8cff]" />
              <span>Your Scheduled Appointments</span>
            </h3>

            <div className="space-y-2.5">
              {appointments.map((appt) => (
                <div
                  key={appt.id}
                  className="p-3.5 rounded-xl bg-[#0b1425] border border-white/5 flex items-center gap-3.5 hover:border-white/10 transition-colors"
                >
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#00d4b4] to-[#4f8cff] flex flex-col items-center justify-center text-black font-extrabold shrink-0">
                    <span className="text-sm leading-none">
                      {new Date(appt.date).getDate() || 18}
                    </span>
                    <span className="text-[9px] uppercase tracking-wider font-mono">
                      {new Date(appt.date).toLocaleString('default', { month: 'short' }) || 'APR'}
                    </span>
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-1">
                      <div className="font-bold text-xs text-slate-200 truncate">
                        {appt.doctorName}
                      </div>
                      <span
                        className={`text-[10px] font-mono px-2 py-0.5 rounded-full border shrink-0 ${
                          appt.status === 'Confirmed'
                            ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                            : appt.status === 'Pending'
                            ? 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                            : 'bg-slate-500/15 text-slate-400 border-slate-500/30'
                        }`}
                      >
                        {appt.status}
                      </span>
                    </div>

                    <div className="text-[11px] text-[#00d4b4] font-medium mt-0.5">
                      {appt.specialty} · {appt.time}
                    </div>

                    <div className="text-[10px] text-slate-400 flex items-center gap-2 mt-1 truncate">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-500" />
                        {appt.hospital || 'Medi-City Central'}
                      </span>
                      <span>•</span>
                      <span>{appt.type}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Hospital Bed Availability Snapshot */}
          <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl">
            <h3 className="font-bold text-sm text-slate-100 mb-3 flex items-center gap-2">
              <HospitalIcon className="w-4 h-4 text-emerald-400" />
              <span>Real-Time Bed Availability</span>
            </h3>

            <div className="space-y-3">
              {hospitals.slice(0, 3).map((h) => (
                <div
                  key={h.id}
                  onClick={() => onSelectHospital(h)}
                  className="p-3 rounded-xl bg-[#0b1425] border border-white/5 hover:border-[#00d4b4]/30 cursor-pointer transition-colors"
                >
                  <div className="flex items-center justify-between text-xs font-semibold text-slate-200">
                    <span className="truncate">{h.name}</span>
                    <span className="font-mono text-emerald-400 shrink-0 ml-2">
                      {h.availPercent}% Avail
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-black/40 rounded-full mt-2 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#00d4b4] to-emerald-400 rounded-full transition-all duration-500"
                      style={{ width: `${h.availPercent}%` }}
                    />
                  </div>
                  <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono mt-1.5">
                    <span>{h.totalBeds} total beds</span>
                    <span>{h.waitTime}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
