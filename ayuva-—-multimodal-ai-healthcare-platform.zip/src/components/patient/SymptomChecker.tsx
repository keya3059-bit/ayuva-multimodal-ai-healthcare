import React, { useState, useEffect, useRef } from 'react';
import { Stethoscope, Brain, AlertCircle, ShieldAlert, Sparkles } from 'lucide-react';
import { diagnoseSymptoms } from '../../services/api';

interface SymptomCheckerProps {
  patientAge: number;
}

const AVAILABLE_SYMPTOMS = [
  { id: 'fever', label: '🌡️ Fever' },
  { id: 'cough', label: '😷 Cough' },
  { id: 'headache', label: '🤯 Headache' },
  { id: 'chest_pain', label: '💔 Chest Pain' },
  { id: 'shortness_of_breath', label: '😮‍💨 Breathlessness' },
  { id: 'fatigue', label: '😴 Fatigue' },
  { id: 'nausea', label: '🤢 Nausea' },
  { id: 'dizziness', label: '💫 Dizziness' },
  { id: 'joint_pain', label: '🦴 Joint Pain' },
  { id: 'rash', label: '🔴 Skin Rash' },
  { id: 'sweats', label: '💧 Night Sweats' },
  { id: 'palpitations', label: '💓 Palpitations' },
];

export const SymptomChecker: React.FC<SymptomCheckerProps> = ({ patientAge }) => {
  const [selected, setSelected] = useState<string[]>(['fever', 'cough']);
  const [age, setAge] = useState<number>(patientAge || 34);
  const [severity, setSeverity] = useState<number>(6);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<{
    diagnoses: { condition: string; probability: number; urgency: string }[];
    recommendation: string;
  } | null>({
    diagnoses: [
      { condition: 'Viral Influenza / Upper Respiratory', probability: 88, urgency: 'Low' },
      { condition: 'Acute Bronchial Hyperresponsiveness', probability: 64, urgency: 'Moderate' },
      { condition: 'Atypical Bacterial Respiratory Infection', probability: 42, urgency: 'Moderate' },
    ],
    recommendation: 'Rest, maintain fluid hydration, and monitor resting oxygen saturation. If temperature exceeds 38.5°C or chest pain manifests, consult Dr. Rajesh Kumar immediately.',
  });

  const radarCanvasRef = useRef<HTMLCanvasElement | null>(null);

  const toggleSymptom = (id: string) => {
    if (selected.includes(id)) {
      setSelected(selected.filter((s) => s !== id));
    } else {
      setSelected([...selected, id]);
    }
  };

  const handleRunDiagnosis = async () => {
    if (selected.length === 0) return;
    setLoading(true);
    try {
      const res = await diagnoseSymptoms(selected, age, severity);
      setResults(res);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  // Draw 5-axis Radar Chart on Canvas
  useEffect(() => {
    const canvas = radarCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    const cx = W / 2;
    const cy = H / 2;
    const r = Math.min(cx, cy) - 28;

    const labels = ['Cardio', 'Metabolic', 'Resp', 'Neuro', 'Immune'];
    // Dynamic values based on selected symptoms
    const vals = [
      selected.includes('chest_pain') || selected.includes('palpitations') ? 78 : 32,
      selected.includes('fatigue') || selected.includes('dizziness') ? 68 : 40,
      selected.includes('shortness_of_breath') || selected.includes('cough') ? 85 : 25,
      selected.includes('headache') || selected.includes('dizziness') ? 74 : 30,
      selected.includes('fever') || selected.includes('sweats') ? 82 : 45,
    ];

    const n = labels.length;
    const angles = labels.map((_, i) => (Math.PI * 2 * i) / n - Math.PI / 2);

    ctx.clearRect(0, 0, W, H);

    // Spiderweb concentric rings
    [0.25, 0.5, 0.75, 1.0].forEach((level) => {
      ctx.beginPath();
      angles.forEach((a, i) => {
        const x = cx + Math.cos(a) * r * level;
        const y = cy + Math.sin(a) * r * level;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.closePath();
      ctx.strokeStyle = 'rgba(0, 212, 180, 0.12)';
      ctx.lineWidth = 1;
      ctx.stroke();
    });

    // Radial spokes
    angles.forEach((a) => {
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.stroke();
    });

    // Filled polygon
    ctx.beginPath();
    vals.forEach((v, i) => {
      const p = v / 100;
      const x = cx + Math.cos(angles[i]) * r * p;
      const y = cy + Math.sin(angles[i]) * r * p;
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.closePath();
    ctx.fillStyle = 'rgba(0, 212, 180, 0.25)';
    ctx.fill();
    ctx.strokeStyle = '#00d4b4';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Data points & Labels
    vals.forEach((v, i) => {
      const p = v / 100;
      const x = cx + Math.cos(angles[i]) * r * p;
      const y = cy + Math.sin(angles[i]) * r * p;
      ctx.beginPath();
      ctx.arc(x, y, 4, 0, Math.PI * 2);
      ctx.fillStyle = '#4f8cff';
      ctx.fill();
      ctx.strokeStyle = '#00d4b4';
      ctx.stroke();

      // Label text
      const lx = cx + Math.cos(angles[i]) * (r + 18);
      const ly = cy + Math.sin(angles[i]) * (r + 18);
      ctx.fillStyle = 'rgba(232, 240, 254, 0.7)';
      ctx.font = '10px JetBrains Mono, monospace';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(labels[i], lx, ly);
    });
  }, [selected]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            AI <span>Symptom Analyzer</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // ENSEMBLE ML · RandomForest + SVM + NaiveBayes · 96.1% CLINICAL TRIAGE ACCURACY
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Symptom Selection Panel */}
        <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Stethoscope className="w-4 h-4 text-[#00d4b4]" />
              <h3 className="font-bold text-sm text-slate-100">Select Presenting Symptoms</h3>
            </div>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#00d4b4]/10 text-[#00d4b4] border border-[#00d4b4]/30">
              {selected.length} SELECTED
            </span>
          </div>

          <div className="flex flex-wrap gap-2">
            {AVAILABLE_SYMPTOMS.map((sym) => {
              const isSelected = selected.includes(sym.id);
              return (
                <button
                  key={sym.id}
                  onClick={() => toggleSymptom(sym.id)}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all flex items-center gap-1.5 border ${
                    isSelected
                      ? 'bg-[#00d4b4]/20 border-[#00d4b4] text-[#00d4b4] shadow-sm shadow-[#00d4b4]/20 font-semibold'
                      : 'bg-[#0b1425] border-white/10 text-slate-400 hover:border-white/20'
                  }`}
                >
                  <span>{sym.label}</span>
                  {isSelected && <span className="text-[10px] opacity-70">✕</span>}
                </button>
              );
            })}
          </div>

          {/* Age and Severity Controls */}
          <div className="grid grid-cols-2 gap-4 pt-2 border-t border-white/10">
            <div>
              <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
                Patient Age: <span className="text-slate-200 font-bold">{age}</span>
              </label>
              <input
                type="range"
                min="1"
                max="100"
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="w-full accent-[#00d4b4] cursor-pointer"
              />
            </div>
            <div>
              <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
                Severity Index: <span className="text-amber-400 font-bold">{severity} / 10</span>
              </label>
              <input
                type="range"
                min="1"
                max="100"
                value={severity * 10}
                onChange={(e) => setSeverity(Math.round(Number(e.target.value) / 10))}
                className="w-full accent-amber-400 cursor-pointer"
              />
            </div>
          </div>

          <button
            onClick={handleRunDiagnosis}
            disabled={loading || selected.length === 0}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#00d4b4] via-[#4f8cff] to-cyan-300 text-black font-bold text-xs hover:opacity-95 transition-opacity shadow-lg shadow-[#00d4b4]/20 flex items-center justify-center gap-2 disabled:opacity-50"
          >
            <Brain className="w-4 h-4" />
            <span>{loading ? 'Running Multi-Model Inference…' : 'Execute AI Triage Analysis'}</span>
          </button>
        </div>

        {/* Results & Radar Chart */}
        <div className="space-y-6">
          {results && (
            <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-emerald-400" />
                  <h3 className="font-bold text-sm text-slate-100">Differential Triage Output</h3>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  ENSEMBLE CONVERGED
                </span>
              </div>

              <div className="space-y-3">
                {results.diagnoses.map((item, idx) => (
                  <div key={idx} className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-slate-200">{item.condition}</span>
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[9px] font-mono uppercase px-1.5 py-0.2 rounded border ${
                            item.urgency === 'High' || item.urgency === 'Emergency'
                              ? 'bg-rose-500/20 text-rose-400 border-rose-500/30'
                              : item.urgency === 'Moderate'
                              ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                              : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                          }`}
                        >
                          {item.urgency}
                        </span>
                        <span className="font-mono text-[#00d4b4] font-bold">
                          {item.probability}%
                        </span>
                      </div>
                    </div>
                    <div className="h-1.5 w-full bg-black/40 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] rounded-full transition-all duration-700"
                        style={{ width: `${item.probability}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>

              <div className="p-3 rounded-xl bg-[#0b1425] border border-white/5 text-xs text-slate-300 leading-relaxed">
                <div className="text-[10px] font-mono uppercase text-[#00d4b4] font-bold mb-1">
                  // CLINICAL RECOMMENDATION
                </div>
                {results.recommendation}
              </div>

              <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-[11px] text-rose-300 flex items-start gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>
                  AI assessment is for clinical triage support and is not a definitive diagnosis. In case of acute chest pain, shortness of breath, or numbness, call 108 immediately.
                </span>
              </div>
            </div>
          )}

          {/* 5-Axis Radar Canvas */}
          <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl flex flex-col items-center">
            <div className="w-full flex items-center justify-between mb-2">
              <h3 className="font-bold text-xs text-slate-200">Systemic Risk Radar</h3>
              <span className="text-[10px] font-mono text-slate-400">PHYSIO 5-AXIS</span>
            </div>
            <canvas
              ref={radarCanvasRef}
              width={260}
              height={220}
              className="max-w-full"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
