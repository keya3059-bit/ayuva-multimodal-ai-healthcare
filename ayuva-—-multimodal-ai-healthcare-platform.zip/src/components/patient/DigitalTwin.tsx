import React, { useState, useEffect, useRef } from 'react';
import { UserCheck, Sparkles, AlertCircle, Heart, Zap, Activity, Brain, ArrowRight, Stethoscope, Volume2, VolumeX } from 'lucide-react';
import { VitalsState } from '../../types';
import { organAudioEngine, OrganSoundType } from '../../utils/organAudioEngine';

interface DigitalTwinProps {
  vitals: VitalsState;
  onNavigate?: (section: any) => void;
}

interface OrganRisk {
  name: string;
  icon: string;
  score: number;
  status: 'optimal' | 'moderate' | 'elevated';
  note: string;
}

export const DigitalTwin: React.FC<DigitalTwinProps> = ({ vitals, onNavigate }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [selectedOrgan, setSelectedOrgan] = useState<string>('Heart & Coronary');
  const [activeSoundOrgan, setActiveSoundOrgan] = useState<OrganSoundType | null>(null);
  const [isAudioPlaying, setIsAudioPlaying] = useState<boolean>(false);

  useEffect(() => {
    const unsub = organAudioEngine.subscribe((state) => {
      setIsAudioPlaying(state.isPlaying);
      setActiveSoundOrgan(state.activeOrgan);
    });
    // sync vitals with organ audio engine
    organAudioEngine.updateParameters({
      bpm: vitals.heartRate || 72,
      respirationRate: 16
    });
    return () => unsub();
  }, [vitals.heartRate]);

  const getOrganSoundType = (name: string): OrganSoundType | null => {
    if (name.includes('Heart')) return 'heart';
    if (name.includes('Pulmonary') || name.includes('Lungs')) return 'lungs';
    if (name.includes('Hepatic') || name.includes('Liver')) return 'liver';
    if (name.includes('Renal') || name.includes('Glomerular')) return 'kidneys';
    if (name.includes('Cerebrovascular') || name.includes('Neuro')) return 'brain';
    if (name.includes('Vertebral') || name.includes('Spine')) return 'spine';
    return null;
  };

  const organs: OrganRisk[] = [
    {
      name: 'Heart & Coronary',
      icon: '🫀',
      score: 88,
      status: 'optimal',
      note: `Sinus rhythm stable (Resting HR ${vitals.heartRate} BPM). QTc interval normal. Left ventricular workload nominal.`,
    },
    {
      name: 'Endocrine & Pancreas',
      icon: '🩸',
      score: 72,
      status: 'moderate',
      note: `Fasting glucose elevated (${vitals.bloodGlucose} mg/dL). Mild postprandial insulin resistance indicated.`,
    },
    {
      name: 'Pulmonary / Lungs',
      icon: '🫁',
      score: 96,
      status: 'optimal',
      note: `Oxygen saturation optimal (${vitals.spo2}%). Minute ventilation and alveolar diffusion barrier capacity normal.`,
    },
    {
      name: 'Hepatic & Portal System',
      icon: '🧪',
      score: 92,
      status: 'optimal',
      note: 'Normal transaminase enzymes, active albumin synthesis, and normal portal venous hemodynamics.',
    },
    {
      name: 'Renal & Glomerular',
      icon: '🫘',
      score: 91,
      status: 'optimal',
      note: 'Estimated GFR > 100 mL/min. Creatinine clearance and electrolyte countercurrent gradients balanced.',
    },
    {
      name: 'Cerebrovascular & Neuro',
      icon: '🧠',
      score: 94,
      status: 'optimal',
      note: 'Autonomic nervous balance (HRV 54ms) indicates intact parasympathetic recovery and low allostatic load.',
    },
    {
      name: 'Vertebral Spine & Musculoskeletal',
      icon: '🦴',
      score: 87,
      status: 'optimal',
      note: 'Preserved cervical and lumbar lordosis, normal intervertebral disk hydraulic cushioning, and axial alignment.',
    },
  ];

  // Draw 2D Anatomical Map on Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frame = 0;
    let animId: number;

    const render = () => {
      frame++;
      const W = canvas.width;
      const H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      const cx = W / 2;

      // Silhouette wireframe (Head, Torso, Limbs)
      ctx.strokeStyle = 'rgba(0, 212, 180, 0.2)';
      ctx.lineWidth = 1.5;

      // Head
      ctx.beginPath();
      ctx.ellipse(cx, 45, 22, 28, 0, 0, Math.PI * 2);
      ctx.stroke();

      // Neck & Torso
      ctx.beginPath();
      ctx.moveTo(cx - 10, 72);
      ctx.lineTo(cx - 38, 95); // L Shoulder
      ctx.lineTo(cx - 30, 190); // L Waist
      ctx.lineTo(cx - 40, 240); // L Hip
      ctx.lineTo(cx - 24, 340); // L Leg
      ctx.lineTo(cx - 12, 340);
      ctx.lineTo(cx - 8, 240);
      ctx.lineTo(cx + 8, 240);
      ctx.lineTo(cx + 12, 340);
      ctx.lineTo(cx + 24, 340);
      ctx.lineTo(cx + 40, 240); // R Hip
      ctx.lineTo(cx + 30, 190); // R Waist
      ctx.lineTo(cx + 38, 95); // R Shoulder
      ctx.lineTo(cx + 10, 72);
      ctx.closePath();
      ctx.fillStyle = 'rgba(11, 20, 37, 0.6)';
      ctx.fill();
      ctx.stroke();

      // Arms
      ctx.beginPath();
      ctx.moveTo(cx - 38, 95);
      ctx.lineTo(cx - 52, 180);
      ctx.lineTo(cx - 58, 250);
      ctx.moveTo(cx + 38, 95);
      ctx.lineTo(cx + 52, 180);
      ctx.lineTo(cx + 58, 250);
      ctx.stroke();

      // Vertebral Spine Axis Line
      ctx.beginPath();
      ctx.setLineDash([2, 3]);
      ctx.moveTo(cx, 68);
      ctx.lineTo(cx, 240);
      ctx.strokeStyle = 'rgba(192, 132, 252, 0.4)';
      ctx.stroke();
      ctx.setLineDash([]);

      // Organ Nodes with pulsating rings
      const nodes = [
        { name: 'Brain', x: cx, y: 45, r: 8, color: '#4f8cff' },
        { name: 'Spine', x: cx, y: 92, r: 6, color: '#c084fc' },
        { name: 'Heart', x: cx - 10, y: 130, r: 9, color: '#ff6b9d' },
        { name: 'Lungs', x: cx + 12, y: 125, r: 8, color: '#00d4b4' },
        { name: 'Liver', x: cx + 14, y: 156, r: 7, color: '#f59e0b' },
        { name: 'Pancreas', x: cx - 6, y: 165, r: 7, color: '#fbbf24' },
        { name: 'Kidneys', x: cx - 12, y: 185, r: 7, color: '#34d399' },
        { name: 'Renal (R)', x: cx + 12, y: 185, r: 7, color: '#34d399' },
      ];

      nodes.forEach((n) => {
        const pulse = (Math.sin(frame * 0.05 + n.x) + 1) * 4;

        // Outer pulse ring
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r + pulse, 0, Math.PI * 2);
        ctx.strokeStyle = n.color;
        ctx.lineWidth = 1;
        ctx.stroke();

        // Core dot
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
        ctx.fillStyle = n.color;
        ctx.shadowColor = n.color;
        ctx.shadowBlur = 10;
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            Physiological <span>Digital Twin</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // IN SILICO MULTISCALE BIOPHYSICAL REPLICA · CELLULAR &amp; ORGAN TRAJECTORY
          </div>
        </div>
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono">
          <Sparkles className="w-3.5 h-3.5" />
          <span>BIOLOGICAL AGE: 31.8 YRS (-2.2 YRS)</span>
        </div>
      </div>

      {/* Featured 3D Anatomical Twin Callout */}
      {onNavigate && (
        <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-rose-950/40 via-[#0a152d] to-cyan-950/40 border border-cyan-500/30 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-500 to-cyan-400 flex items-center justify-center shadow-lg shadow-cyan-500/20 shrink-0">
              <Heart className="w-5 h-5 text-white fill-white/40" />
            </div>
            <div>
              <div className="text-sm font-bold text-white flex items-center gap-2">
                <span>6 Multi-Organ 3D Anatomical Digital Twins</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  EXPANDED
                </span>
              </div>
              <div className="text-xs text-slate-300">
                High-fidelity 3D models for Heart, Brain, Lungs, Kidneys, Liver, and Spine with cross-sections, biometrics & clinical insights.
              </div>
            </div>
          </div>
          <button
            onClick={() => onNavigate('anatomical-models')}
            className="w-full sm:w-auto px-4 py-2.5 rounded-xl bg-gradient-to-r from-rose-500 via-purple-600 to-cyan-500 hover:opacity-90 text-white text-xs font-bold transition-all shadow-md flex items-center justify-center gap-2 shrink-0"
          >
            <span>Open 3D Models & Detailing</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        {/* Anatomical Canvas */}
        <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl flex flex-col items-center justify-center relative">
          <div className="w-full flex items-center justify-between mb-4">
            <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <UserCheck className="w-4 h-4 text-[#00d4b4]" />
              <span>Full-Body In Silico Projection</span>
            </h3>
            <span className="text-[10px] font-mono text-[#00d4b4] px-2 py-0.5 rounded bg-[#00d4b4]/10 border border-[#00d4b4]/30">
              SYNCHRONIZED
            </span>
          </div>

          <div className="p-2 rounded-2xl bg-[#0b1425] border border-white/5 w-full flex justify-center">
            <canvas ref={canvasRef} width={280} height={380} className="max-w-full" />
          </div>

          <div className="text-[11px] text-slate-400 font-mono mt-3">
            Simulating hemodynamics, glycemic flux, and tissue oxidation.
          </div>
        </div>

        {/* Organ Risk Breakdown Cards */}
        <div className="space-y-4">
          <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
            <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2 pb-2 border-b border-white/10">
              <Activity className="w-4 h-4 text-[#4f8cff]" />
              <span>Organ System Health Scores</span>
            </h3>

            <div className="space-y-3">
              {organs.map((o) => {
                const soundType = getOrganSoundType(o.name);
                const isThisOrganPlaying = isAudioPlaying && activeSoundOrgan === soundType;

                return (
                  <div
                    key={o.name}
                    onClick={() => setSelectedOrgan(o.name)}
                    className={`p-3.5 rounded-xl border cursor-pointer transition-all ${
                      selectedOrgan === o.name
                        ? 'bg-[#0b1425] border-[#00d4b4] shadow-md shadow-[#00d4b4]/10'
                        : 'bg-[#0b1425]/50 border-white/5 hover:border-white/15'
                    }`}
                  >
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <div className="flex items-center gap-2">
                        <span className="text-base">{o.icon}</span>
                        <span className="font-bold text-slate-200">{o.name}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {soundType && selectedOrgan === o.name && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              organAudioEngine.toggleSound(soundType);
                            }}
                            className={`flex items-center gap-1 px-2 py-0.5 rounded-lg text-[10px] font-mono transition-all ${
                              isThisOrganPlaying
                                ? 'bg-rose-500 text-white font-bold animate-pulse'
                                : 'bg-white/10 hover:bg-white/20 text-slate-300'
                            }`}
                            title={isThisOrganPlaying ? 'Stop Organ Sound' : 'Play Organ Auscultation Sound'}
                          >
                            <Stethoscope className="w-3 h-3" />
                            <span>{isThisOrganPlaying ? 'Auscultating...' : 'Listen Sound'}</span>
                          </button>
                        )}
                        <span
                          className={`font-mono font-bold ${
                            o.score >= 85
                              ? 'text-emerald-400'
                              : o.score >= 70
                              ? 'text-amber-400'
                              : 'text-rose-400'
                          }`}
                        >
                          {o.score} / 100
                        </span>
                      </div>
                    </div>

                    <div className="h-1.5 w-full bg-black/40 rounded-full overflow-hidden mb-2">
                      <div
                        className={`h-full rounded-full transition-all duration-700 ${
                          o.score >= 85
                            ? 'bg-gradient-to-r from-[#00d4b4] to-emerald-400'
                            : o.score >= 70
                            ? 'bg-gradient-to-r from-amber-400 to-yellow-500'
                            : 'bg-gradient-to-r from-rose-500 to-red-600'
                        }`}
                        style={{ width: `${o.score}%` }}
                      />
                    </div>

                    <p className="text-[11px] text-slate-400 leading-relaxed">{o.note}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
