import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, User, Sparkles, AlertCircle, RefreshCw } from 'lucide-react';
import { ChatMessage, UserProfile, VitalsState } from '../../types';
import { sendChatMessage } from '../../services/api';

interface AIChatProps {
  user?: UserProfile;
  vitals: VitalsState;
}

export const AIChat: React.FC<AIChatProps> = ({ user, vitals }) => {
  const firstName = user?.name ? user.name.split(' ')[0] : 'Alex';
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-1',
      role: 'assistant',
      content: `Hello ${firstName}! I am your Ayuva AI Health Assistant. I have live access to your current vitals (Heart Rate: ${vitals.heartRate} BPM, Blood Glucose: ${vitals.bloodGlucose} mg/dL, SpO₂: ${vitals.spo2}%) and your active care plan. How can I assist with your health today?`,
      timestamp: 'Just now',
    },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = async (textToSend?: string) => {
    const text = textToSend || input.trim();
    if (!text || loading) return;

    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const historyPayload = messages.map((m) => ({
        role: m.role,
        content: m.content,
      }));

      const res = await sendChatMessage(text, historyPayload, {
        name: user?.name || 'Alex Morgan',
        age: user?.age || 34,
        vitals: {
          hr: vitals.heartRate,
          bg: vitals.bloodGlucose,
          spo2: vitals.spo2,
          temp: vitals.temperature,
        },
        medications: 'Metformin 500mg BID, Atorvastatin 10mg HS, Telmisartan 40mg',
        condition: 'Pre-diabetes, Mild Hypertension',
      });

      const aiMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        role: 'assistant',
        content: res.reply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, aiMsg]);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const quickPrompts = [
    '📊 What do my recent vitals mean?',
    '🩸 How can I reverse pre-diabetes?',
    '💊 Metformin timing and side effects',
    '😴 Tips to improve deep sleep score',
  ];

  return (
    <div className="space-y-4 max-w-4xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100 flex items-center gap-2">
            <span>Ayuva AI</span>
            <span className="bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] bg-clip-text text-transparent">
              Health Assistant
            </span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // GEMINI 3.8 FLASH · REAL-TIME CLINICAL CONTEXT AWARENESS · HIPAA PROTOCOL
          </div>
        </div>
        <div className="flex items-center gap-1.5 text-xs font-mono text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/30">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span>CLINICAL REASONING ONLINE</span>
        </div>
      </div>

      {/* Chat Container */}
      <div className="rounded-3xl bg-[#080e1c] border border-white/10 shadow-2xl overflow-hidden flex flex-col h-[560px]">
        {/* Messages Feed */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          {messages.map((m) => (
            <div
              key={m.id}
              className={`flex items-start gap-3 ${
                m.role === 'user' ? 'flex-row-reverse' : ''
              }`}
            >
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 shadow-md ${
                  m.role === 'user'
                    ? 'bg-gradient-to-tr from-[#4f8cff] to-cyan-400 text-black font-bold text-xs'
                    : 'bg-gradient-to-tr from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs'
                }`}
              >
                {m.role === 'user' ? user.avatar || 'U' : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`max-w-[85%] sm:max-w-[75%] p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                  m.role === 'user'
                    ? 'bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-medium rounded-tr-none'
                    : 'bg-[#0b1425] border border-white/5 text-slate-200 rounded-tl-none'
                }`}
              >
                <div dangerouslySetInnerHTML={{ __html: m.content }} />
                <div
                  className={`text-[9px] font-mono mt-1 ${
                    m.role === 'user' ? 'text-black/60 text-right' : 'text-slate-500'
                  }`}
                >
                  {m.timestamp}
                </div>
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#00d4b4] to-[#4f8cff] text-black flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4 animate-spin" />
              </div>
              <div className="p-3 rounded-2xl bg-[#0b1425] border border-white/5 text-xs text-slate-400 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#00d4b4] animate-pulse" />
                <span>Ayuva AI is synthesizing your health records &amp; vitals…</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Prompt Suggestions */}
        <div className="p-2 sm:px-4 border-t border-white/5 bg-black/20 flex gap-2 overflow-x-auto no-scrollbar">
          {quickPrompts.map((p, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(p)}
              className="text-[11px] px-3 py-1 rounded-full bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 text-slate-300 whitespace-nowrap transition-colors"
            >
              {p}
            </button>
          ))}
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-3 sm:p-4 border-t border-white/10 bg-[#080e1c] flex items-center gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about your vitals, symptoms, diet, or medications…"
            className="flex-1 bg-[#0b1425] border border-white/10 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-[#00d4b4]"
          />
          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="p-2.5 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold disabled:opacity-40 transition-opacity"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>

      <div className="p-3 rounded-xl bg-white/[0.02] border border-white/5 text-[11px] text-slate-400 flex items-center gap-2">
        <AlertCircle className="w-4 h-4 text-slate-500 shrink-0" />
        <span>
          Ayuva AI provides clinical informational support based on your continuous biomarker stream. Never adjust prescription medications without physician confirmation.
        </span>
      </div>
    </div>
  );
};
