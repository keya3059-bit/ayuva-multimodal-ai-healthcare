import React, { useState, useEffect, useRef } from 'react';
import { LineChart as ChartIcon, TrendingUp, Calendar, Zap, ArrowUpRight, ArrowDownRight } from 'lucide-react';

interface MetricConfig {
  id: string;
  name: string;
  color: string;
  unit: string;
  min: number;
  max: number;
  data: number[];
}

export const HealthTrends: React.FC = () => {
  const [activeMetric, setActiveMetric] = useState<string>('glucose');
  const [timeRange, setTimeRange] = useState<'7D' | '30D' | '90D'>('30D');

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const metrics: Record<string, MetricConfig> = {
    glucose: {
      id: 'glucose',
      name: 'Fasting Blood Glucose',
      color: '#00d4b4',
      unit: 'mg/dL',
      min: 70,
      max: 180,
      data: [128, 122, 118, 124, 119, 115, 110, 114, 112, 108, 106, 112, 114, 110, 109, 105, 108, 112, 115, 110, 107, 104, 108, 110, 109, 106, 104, 105, 108, 106],
    },
    heartRate: {
      id: 'heartRate',
      name: 'Resting Heart Rate',
      color: '#ff6b9d',
      unit: 'BPM',
      min: 50,
      max: 110,
      data: [78, 76, 75, 74, 76, 75, 73, 72, 70, 71, 72, 74, 73, 72, 71, 70, 69, 71, 72, 70, 69, 71, 70, 72, 71, 70, 68, 69, 70, 68],
    },
    bloodPressure: {
      id: 'bloodPressure',
      name: 'Systolic Blood Pressure',
      color: '#4f8cff',
      unit: 'mmHg',
      min: 90,
      max: 160,
      data: [136, 134, 132, 130, 131, 128, 126, 125, 124, 125, 123, 124, 122, 121, 120, 122, 121, 120, 119, 121, 120, 118, 120, 121, 119, 118, 117, 118, 119, 118],
    },
    spo2: {
      id: 'spo2',
      name: 'Blood Oxygen (SpO₂)',
      color: '#34d399',
      unit: '%',
      min: 92,
      max: 100,
      data: [97, 98, 97, 98, 99, 98, 98, 97, 98, 99, 98, 98, 97, 98, 99, 98, 99, 98, 97, 98, 98, 99, 98, 98, 99, 98, 99, 98, 98, 99],
    },
  };

  const cur = metrics[activeMetric];

  // Draw Line Chart on Canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    const padL = 40;
    const padR = 20;
    const padT = 20;
    const padB = 30;

    ctx.clearRect(0, 0, W, H);

    const data = cur.data;
    const minVal = cur.min;
    const maxVal = cur.max;

    // Grid lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1;
    const gridSteps = 4;
    for (let i = 0; i <= gridSteps; i++) {
      const y = padT + (H - padT - padB) * (i / gridSteps);
      ctx.beginPath();
      ctx.moveTo(padL, y);
      ctx.lineTo(W - padR, y);
      ctx.stroke();

      const val = Math.round(maxVal - (maxVal - minVal) * (i / gridSteps));
      ctx.fillStyle = 'rgba(232, 240, 254, 0.4)';
      ctx.font = '10px JetBrains Mono, monospace';
      ctx.textAlign = 'right';
      ctx.fillText(String(val), padL - 8, y + 3);
    }

    // Plot line
    const points = data.map((v, i) => {
      const x = padL + ((W - padL - padR) / (data.length - 1)) * i;
      const y = padT + (H - padT - padB) * (1 - (v - minVal) / (maxVal - minVal));
      return { x, y };
    });

    // Fill gradient
    const grad = ctx.createLinearGradient(0, padT, 0, H - padB);
    grad.addColorStop(0, `${cur.color}33`);
    grad.addColorStop(1, `${cur.color}00`);

    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    for (let i = 1; i < points.length; i++) {
      ctx.lineTo(points[i].x, points[i].y);
    }
    ctx.lineTo(points[points.length - 1].x, H - padB);
    ctx.lineTo(points[0].x, H - padB);
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.fill();

    // Line stroke
    ctx.beginPath();
    ctx.moveTo(points[0].x, points[0].y);
    for (let i = 1; i < points.length; i++) {
      ctx.lineTo(points[i].x, points[i].y);
    }
    ctx.strokeStyle = cur.color;
    ctx.lineWidth = 2.5;
    ctx.shadowColor = cur.color;
    ctx.shadowBlur = 8;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Dots
    points.forEach((p, idx) => {
      if (idx % 3 === 0 || idx === points.length - 1) {
        ctx.beginPath();
        ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
        ctx.fillStyle = '#080e1c';
        ctx.fill();
        ctx.strokeStyle = cur.color;
        ctx.lineWidth = 2;
        ctx.stroke();
      }
    });
  }, [activeMetric, cur]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            Biomarker <span>Trends &amp; Forecasts</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // CONTINUOUS PHYSIOLOGICAL REPOSITORY · 30-DAY WINDOW
          </div>
        </div>

        <div className="flex rounded-xl bg-white/[0.04] p-1 border border-white/5 self-start sm:self-auto">
          {(['7D', '30D', '90D'] as const).map((r) => (
            <button
              key={r}
              onClick={() => setTimeRange(r)}
              className={`px-3 py-1 rounded-lg text-xs font-semibold transition-all ${
                timeRange === r
                  ? 'bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      {/* Metric Selector Tabs */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {Object.values(metrics).map((m) => {
          const isSel = activeMetric === m.id;
          const latestVal = m.data[m.data.length - 1];
          const firstVal = m.data[0];
          const delta = latestVal - firstVal;
          return (
            <div
              key={m.id}
              onClick={() => setActiveMetric(m.id)}
              className={`p-3.5 rounded-2xl cursor-pointer transition-all border ${
                isSel
                  ? 'bg-[#0b1425] border-[#00d4b4] shadow-lg shadow-[#00d4b4]/10'
                  : 'bg-[#080e1c] border-white/5 hover:border-white/15'
              }`}
            >
              <div className="text-xs text-slate-400 truncate">{m.name}</div>
              <div className="text-xl font-mono font-bold text-slate-100 mt-1">
                {latestVal} <span className="text-xs font-normal text-slate-400">{m.unit}</span>
              </div>
              <div
                className={`text-[10px] font-mono mt-1 flex items-center gap-1 ${
                  delta <= 0 ? 'text-emerald-400' : 'text-amber-400'
                }`}
              >
                {delta <= 0 ? <ArrowDownRight className="w-3 h-3" /> : <ArrowUpRight className="w-3 h-3" />}
                <span>{Math.abs(delta)} {m.unit} vs Day 1</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Chart Canvas Card */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <ChartIcon className="w-4 h-4 text-[#00d4b4]" />
            <h3 className="font-bold text-sm text-slate-100">{cur.name} Trajectory</h3>
          </div>
          <span className="text-[10px] font-mono text-slate-400">
            INTERVAL: 24H AVERAGE
          </span>
        </div>

        <div className="w-full overflow-x-auto">
          <canvas
            ref={canvasRef}
            width={720}
            height={260}
            className="w-full min-w-[500px]"
          />
        </div>
      </div>

      {/* 30-Day Health Index Heatmap */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
            <Calendar className="w-4 h-4 text-[#4f8cff]" />
            <span>30-Day Physiological Stability Heatmap</span>
          </h3>
          <span className="text-[10px] font-mono text-emerald-400">93.4% COMPLIANCE</span>
        </div>

        <div className="grid grid-cols-10 sm:grid-cols-15 gap-1.5 pt-2">
          {Array.from({ length: 30 }).map((_, i) => {
            const score = 84 + ((i * 7) % 15);
            return (
              <div
                key={i}
                title={`Day ${i + 1}: Stability Score ${score}%`}
                className={`h-8 rounded-lg flex items-center justify-center font-mono text-[10px] cursor-pointer transition-transform hover:scale-110 ${
                  score > 92
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : score > 85
                    ? 'bg-[#00d4b4]/20 text-[#00d4b4] border border-[#00d4b4]/30'
                    : 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                }`}
              >
                {i + 1}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
