import React from 'react';
import {
  Heart,
  Activity,
  Thermometer,
  Droplet,
  Calendar,
  Pill,
  Radio,
  ArrowUpRight,
  Stethoscope,
  Bot,
  Truck,
  FlaskConical,
  LineChart,
  UserCheck,
  ShieldCheck,
  AlertTriangle
} from 'lucide-react';
import { VitalsState, UserProfile, AppSection } from '../../types';

interface PatientDashboardProps {
  user?: UserProfile;
  vitals: VitalsState;
  onNavigate: (sec: AppSection) => void;
  onSyncVitals?: () => void;
  onTriggerSOS?: () => void;
}

export const PatientDashboard: React.FC<PatientDashboardProps> = ({
  user,
  vitals,
  onNavigate,
  onSyncVitals,
  onTriggerSOS,
}) => {
  const firstName = user?.name ? user.name.split(' ')[0] : 'Alex';

  return (
    <div className="space-y-6">
      {/* Welcome & Subtitle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-100">
            Welcome back, <span className="bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] bg-clip-text text-transparent">{firstName}</span> 👋
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-1 flex items-center gap-2">
            <span>// PATIENT DASHBOARD</span>
            <span>•</span>
            <span className="text-[#00d4b4]">HEALTH INDEX: 91.4</span>
            <span>•</span>
            <span className="text-emerald-400 flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> LIVE SYNC
            </span>
          </div>
        </div>
        <button
          onClick={onSyncVitals}
          className="self-start sm:self-auto flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-xs font-semibold text-slate-300 transition-colors"
        >
          <Radio className="w-3.5 h-3.5 text-[#00d4b4]" />
          <span>Sync IoT Vitals</span>
        </button>
      </div>

      {/* Top Stat Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-lg relative overflow-hidden">
          <div className="text-xl mb-1">⭐</div>
          <div className="text-2xl sm:text-3xl font-extrabold font-mono text-[#00d4b4]">
            91.4
          </div>
          <div className="text-[11px] font-mono uppercase text-slate-400 mt-0.5">
            AI Health Score
          </div>
          <div className="text-[11px] text-emerald-400 flex items-center gap-1 mt-2">
            <ArrowUpRight className="w-3.5 h-3.5" /> +2.1 this week
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-lg relative overflow-hidden">
          <div className="text-xl mb-1">📅</div>
          <div className="text-xl sm:text-2xl font-extrabold font-mono text-[#4f8cff]">
            Apr 18
          </div>
          <div className="text-[11px] font-mono uppercase text-slate-400 mt-0.5">
            Next Appointment
          </div>
          <div className="text-[11px] text-slate-400 mt-2 truncate">
            Dr. Rajesh Kumar · Cardio
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-lg relative overflow-hidden">
          <div className="text-xl mb-1">💊</div>
          <div className="text-2xl sm:text-3xl font-extrabold font-mono text-amber-400">
            3
          </div>
          <div className="text-[11px] font-mono uppercase text-slate-400 mt-0.5">
            Active Medications
          </div>
          <div className="text-[11px] text-slate-400 mt-2">
            100% adherence streak
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-[#080e1c] border border-white/10 shadow-lg relative overflow-hidden">
          <div className="text-xl mb-1">📡</div>
          <div className="text-2xl sm:text-3xl font-extrabold font-mono text-emerald-400">
            4 / 4
          </div>
          <div className="text-[11px] font-mono uppercase text-slate-400 mt-0.5">
            Wearables Online
          </div>
          <div className="text-[11px] text-emerald-400 mt-2">
            All telemetry active
          </div>
        </div>
      </div>

      {/* Live IoT Vitals Display */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Heart className="w-4 h-4 text-rose-400" />
            <h3 className="font-bold text-sm text-slate-100">Live IoT Vitals Telemetry</h3>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#00d4b4]/10 text-[#00d4b4] border border-[#00d4b4]/30">
              REAL-TIME
            </span>
          </div>
          <button
            onClick={() => onNavigate('wearables')}
            className="text-xs text-[#00d4b4] hover:underline flex items-center gap-1 font-semibold"
          >
            Manage Sensors →
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
          {/* Heart Rate */}
          <div className="p-4 rounded-xl bg-[#0b1425] border border-white/5 text-center relative overflow-hidden group hover:border-[#00d4b4]/40 transition-all">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse absolute top-3 right-3" />
            <div className="w-14 h-14 rounded-full mx-auto mb-2 flex items-center justify-center bg-gradient-to-tr from-rose-500/20 to-[#00d4b4]/20 border border-[#00d4b4]/30 shadow-inner">
              <span className="font-mono text-lg font-bold text-slate-100">{vitals.heartRate}</span>
            </div>
            <div className="text-xs font-semibold text-slate-200">Heart Rate</div>
            <div className="text-[10px] text-slate-400 font-mono mt-0.5">BPM · Resting Normal</div>
          </div>

          {/* SpO2 */}
          <div className="p-4 rounded-xl bg-[#0b1425] border border-white/5 text-center relative overflow-hidden group hover:border-[#4f8cff]/40 transition-all">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse absolute top-3 right-3" />
            <div className="w-14 h-14 rounded-full mx-auto mb-2 flex items-center justify-center bg-gradient-to-tr from-[#4f8cff]/20 to-cyan-500/20 border border-[#4f8cff]/30 shadow-inner">
              <span className="font-mono text-lg font-bold text-slate-100">{vitals.spo2}%</span>
            </div>
            <div className="text-xs font-semibold text-slate-200">Blood Oxygen</div>
            <div className="text-[10px] text-emerald-400 font-mono mt-0.5">Optimal Saturation</div>
          </div>

          {/* Temperature */}
          <div className="p-4 rounded-xl bg-[#0b1425] border border-white/5 text-center relative overflow-hidden group hover:border-emerald-500/40 transition-all">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse absolute top-3 right-3" />
            <div className="w-14 h-14 rounded-full mx-auto mb-2 flex items-center justify-center bg-gradient-to-tr from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 shadow-inner">
              <span className="font-mono text-lg font-bold text-slate-100">{vitals.temperature}</span>
            </div>
            <div className="text-xs font-semibold text-slate-200">Core Temp</div>
            <div className="text-[10px] text-slate-400 font-mono mt-0.5">°C · Euthermic</div>
          </div>

          {/* Blood Glucose */}
          <div className="p-4 rounded-xl bg-[#0b1425] border border-white/5 text-center relative overflow-hidden group hover:border-amber-500/40 transition-all">
            <div className="w-2 h-2 rounded-full bg-amber-400 animate-pulse absolute top-3 right-3" />
            <div className="w-14 h-14 rounded-full mx-auto mb-2 flex items-center justify-center bg-gradient-to-tr from-amber-500/20 to-orange-500/20 border border-amber-500/30 shadow-inner">
              <span className="font-mono text-lg font-bold text-amber-300">{vitals.bloodGlucose}</span>
            </div>
            <div className="text-xs font-semibold text-slate-200">Blood Glucose</div>
            <div className="text-[10px] text-amber-400 font-mono mt-0.5">mg/dL · Mildly Elevated</div>
          </div>
        </div>
      </div>

      {/* Quick Launchpad to Primary Features */}
      <div>
        <div className="text-xs font-mono uppercase tracking-wider text-slate-400 font-semibold mb-3">
          // AI PLATFORM QUICK ACCESS
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5">
          <div
            onClick={() => onNavigate('ai-diagnosis')}
            className="p-4 rounded-2xl bg-gradient-to-br from-[#00d4b4]/10 via-[#080e1c] to-transparent border border-[#00d4b4]/20 hover:border-[#00d4b4]/60 cursor-pointer transition-all hover:-translate-y-0.5 shadow-lg group"
          >
            <div className="w-10 h-10 rounded-xl bg-[#00d4b4]/15 flex items-center justify-center text-[#00d4b4] mb-3 group-hover:scale-110 transition-transform">
              <Stethoscope className="w-5 h-5" />
            </div>
            <div className="text-sm font-bold text-slate-100 mb-1">Ensemble Symptom Checker</div>
            <div className="text-xs text-slate-400 leading-relaxed">
              Analyze symptoms with multi-model classification (RandomForest + SVM).
            </div>
          </div>

          <div
            onClick={() => onNavigate('rf-predictor')}
            className="p-4 rounded-2xl bg-gradient-to-br from-amber-500/10 via-[#080e1c] to-transparent border border-amber-500/20 hover:border-amber-500/60 cursor-pointer transition-all hover:-translate-y-0.5 shadow-lg group"
          >
            <div className="w-10 h-10 rounded-xl bg-amber-500/15 flex items-center justify-center text-amber-400 mb-3 group-hover:scale-110 transition-transform">
              <Activity className="w-5 h-5" />
            </div>
            <div className="text-sm font-bold text-slate-100 mb-1">100-Tree Risk Predictor</div>
            <div className="text-xs text-slate-400 leading-relaxed">
              Interactive Gini-impurity Random Forest simulating 100 decision trees.
            </div>
          </div>

          <div
            onClick={() => onNavigate('ai-chat')}
            className="p-4 rounded-2xl bg-gradient-to-br from-[#4f8cff]/10 via-[#080e1c] to-transparent border border-[#4f8cff]/20 hover:border-[#4f8cff]/60 cursor-pointer transition-all hover:-translate-y-0.5 shadow-lg group"
          >
            <div className="w-10 h-10 rounded-xl bg-[#4f8cff]/15 flex items-center justify-center text-[#4f8cff] mb-3 group-hover:scale-110 transition-transform">
              <Bot className="w-5 h-5" />
            </div>
            <div className="text-sm font-bold text-slate-100 mb-1">Ayuva AI Assistant</div>
            <div className="text-xs text-slate-400 leading-relaxed">
              Natural conversation powered by Gemini 3.8 Flash personalized to your vitals.
            </div>
          </div>

          <div
            onClick={() => onNavigate('delivery')}
            className="p-4 rounded-2xl bg-gradient-to-br from-emerald-500/10 via-[#080e1c] to-transparent border border-emerald-500/20 hover:border-emerald-500/60 cursor-pointer transition-all hover:-translate-y-0.5 shadow-lg group"
          >
            <div className="w-10 h-10 rounded-xl bg-emerald-500/15 flex items-center justify-center text-emerald-400 mb-3 group-hover:scale-110 transition-transform">
              <Truck className="w-5 h-5" />
            </div>
            <div className="text-sm font-bold text-slate-100 mb-1">Live Medicine Delivery</div>
            <div className="text-xs text-slate-400 leading-relaxed">
              Track your autonomous van on the animated map with live ETA and temperature log.
            </div>
          </div>

          <div
            onClick={() => onNavigate('digital-twin')}
            className="p-4 rounded-2xl bg-gradient-to-br from-indigo-500/10 via-[#080e1c] to-transparent border border-indigo-500/20 hover:border-indigo-500/60 cursor-pointer transition-all hover:-translate-y-0.5 shadow-lg group"
          >
            <div className="w-10 h-10 rounded-xl bg-indigo-500/15 flex items-center justify-center text-indigo-400 mb-3 group-hover:scale-110 transition-transform">
              <UserCheck className="w-5 h-5" />
            </div>
            <div className="text-sm font-bold text-slate-100 mb-1">Physiological Digital Twin</div>
            <div className="text-xs text-slate-400 leading-relaxed">
              Interactive 2D anatomical map showing organ risk scores derived from IoT streams.
            </div>
          </div>

          <div
            onClick={() => onNavigate('emergency-sos')}
            className="p-4 rounded-2xl bg-gradient-to-br from-rose-500/10 via-[#080e1c] to-transparent border border-rose-500/20 hover:border-rose-500/60 cursor-pointer transition-all hover:-translate-y-0.5 shadow-lg group"
          >
            <div className="w-10 h-10 rounded-xl bg-rose-500/15 flex items-center justify-center text-rose-400 mb-3 group-hover:scale-110 transition-transform">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div className="text-sm font-bold text-slate-100 mb-1">One-Touch Emergency SOS</div>
            <div className="text-xs text-slate-400 leading-relaxed">
              Instant 108 dispatch, GPS coordinate broadcast, and nearest trauma bay routing.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
