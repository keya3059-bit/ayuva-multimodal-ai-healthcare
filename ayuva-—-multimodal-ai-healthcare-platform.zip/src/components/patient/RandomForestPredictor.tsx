import React, { useState, useEffect, useRef } from 'react';
import { TreeDeciduous, RotateCcw, AlertTriangle, Lightbulb, Play, Layers } from 'lucide-react';

interface PatientParams {
  age: number;
  bmi: number;
  glucose: number;
  bp: number;
  chol: number;
  hba1c: number;
  hr: number;
  smoking: boolean;
  family: boolean;
  exercise: boolean;
  alcohol: boolean;
}

export const RandomForestPredictor: React.FC = () => {
  const [params, setParams] = useState<PatientParams>({
    age: 45,
    bmi: 26.5,
    glucose: 112,
    bp: 124,
    chol: 195,
    hba1c: 5.8,
    hr: 72,
    smoking: false,
    family: true,
    exercise: true,
    alcohol: false,
  });

  const [isRunning, setIsRunning] = useState(false);
  const [votes, setVotes] = useState<{ low: number; mid: number; high: number }>({
    low: 52,
    mid: 34,
    high: 14,
  });

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Compute clinically weighted overall risk
  const computeScore = () => {
    let risk = 0;
    risk += ((params.age - 18) / 72) * 0.18;

    if (params.bmi < 18.5) risk += 0.04;
    else if (params.bmi < 25) risk += 0.0;
    else if (params.bmi < 30) risk += 0.08;
    else if (params.bmi < 35) risk += 0.15;
    else risk += 0.22;

    if (params.glucose > 125) risk += 0.20;
    else if (params.glucose > 99) risk += 0.10;

    if (params.bp > 140) risk += 0.18;
    else if (params.bp > 120) risk += 0.08;

    if (params.chol > 240) risk += 0.16;
    else if (params.chol > 200) risk += 0.07;

    if (params.hba1c > 6.5) risk += 0.22;
    else if (params.hba1c > 5.7) risk += 0.11;

    if (params.hr > 100 || params.hr < 50) risk += 0.05;

    if (params.smoking) risk += 0.14;
    if (params.family) risk += 0.10;
    if (params.exercise) risk -= 0.12;
    if (params.alcohol) risk += 0.06;

    return Math.max(0.05, Math.min(0.95, risk));
  };

  const currentScore = computeScore();

  const getDiseaseRisks = () => [
    { name: 'Type 2 Diabetes', val: Math.min(97, Math.round(currentScore * 115)), color: '#00d4b4' },
    { name: 'Cardiovascular Disease (CAD)', val: Math.min(95, Math.round(currentScore * 105)), color: '#4f8cff' },
    { name: 'Primary Hypertension', val: Math.min(96, Math.round(currentScore * 95)), color: '#a78bfa' },
    { name: 'Metabolic Syndrome', val: Math.min(98, Math.round(currentScore * 108)), color: '#fbbf24' },
    { name: 'Cerebrovascular / Stroke Risk', val: Math.min(90, Math.round(currentScore * 90)), color: '#f87171' },
  ];

  const getFeatureImportance = () => [
    { name: 'Blood Glucose / HbA1c', pct: 28 },
    { name: 'Systolic Blood Pressure', pct: 22 },
    { name: 'BMI / Adiposity', pct: 16 },
    { name: 'Total Cholesterol', pct: 14 },
    { name: 'Age / Chronological Decay', pct: 11 },
    { name: 'Lifestyle / Smoking / Exercise', pct: 9 },
  ];

  // Draw 100-Tree Decision Forest Grid on Canvas
  const drawForest = (low: number, mid: number, high: number, progress = 1) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const W = canvas.width;
    const H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    const cols = 20;
    const rows = 5;
    const padX = 16;
    const padY = 16;
    const cellW = (W - padX * 2) / (cols - 1);
    const cellH = (H - padY * 2) / (rows - 1);

    const totalDots = 100;
    const visibleDots = Math.floor(totalDots * progress);

    for (let i = 0; i < totalDots; i++) {
      const col = i % cols;
      const row = Math.floor(i / cols);
      const x = padX + col * cellW;
      const y = padY + row * cellH;

      ctx.beginPath();
      ctx.arc(x, y, 4.5, 0, Math.PI * 2);

      if (i >= visibleDots) {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
        ctx.fill();
        continue;
      }

      let color = '#34d399'; // Low
      if (i >= low && i < low + mid) {
        color = '#fbbf24'; // Mid
      } else if (i >= low + mid) {
        color = '#f87171'; // High
      }

      ctx.fillStyle = color;
      ctx.shadowColor = color;
      ctx.shadowBlur = 6;
      ctx.fill();
      ctx.shadowBlur = 0;
    }
  };

  useEffect(() => {
    drawForest(votes.low, votes.mid, votes.high, 1);
  }, [votes]);

  const handleRunSimulation = () => {
    setIsRunning(true);
    const low = Math.max(10, Math.round((1 - currentScore) * 80 + Math.random() * 8));
    const high = Math.min(80, Math.round(currentScore * 80 + Math.random() * 8));
    const mid = Math.max(5, 100 - low - high);

    let step = 0;
    const totalSteps = 20;
    const interval = setInterval(() => {
      step++;
      drawForest(low, mid, high, step / totalSteps);
      if (step >= totalSteps) {
        clearInterval(interval);
        setVotes({ low, mid, high });
        setIsRunning(false);
      }
    }, 40);
  };

  const handleReset = () => {
    setParams({
      age: 45,
      bmi: 26,
      glucose: 110,
      bp: 120,
      chol: 190,
      hba1c: 5.6,
      hr: 72,
      smoking: false,
      family: false,
      exercise: true,
      alcohol: false,
    });
    setVotes({ low: 65, mid: 25, high: 10 });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            Random Forest <span>Risk Predictor</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // 100 DECISION TREES · GINI IMPURITY MINIMIZATION · BAGGING ENSEMBLE · 94.3% ACCURACY
          </div>
        </div>
        <button
          onClick={handleReset}
          className="self-start sm:self-auto flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/[0.04] hover:bg-white/[0.08] border border-white/10 text-xs font-semibold text-slate-300 transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" /> Reset Parameters
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        {/* Sliders and Toggles Panel */}
        <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <TreeDeciduous className="w-4 h-4 text-[#00d4b4]" />
              <span>Input Physiological Features</span>
            </h3>
            <span className="text-[10px] font-mono text-slate-400">11 BIOMARKERS</span>
          </div>

          <div className="space-y-3.5">
            {/* Age Slider */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-400">Age</span>
                <span className="font-mono text-[#00d4b4] font-bold">{params.age} yrs</span>
              </div>
              <input
                type="range"
                min="18"
                max="90"
                value={params.age}
                onChange={(e) => setParams({ ...params, age: Number(e.target.value) })}
                className="w-full accent-[#00d4b4] cursor-pointer"
              />
            </div>

            {/* BMI Slider */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-400">Body Mass Index (BMI)</span>
                <span className="font-mono text-[#00d4b4] font-bold">{params.bmi}</span>
              </div>
              <input
                type="range"
                min="16"
                max="45"
                step="0.5"
                value={params.bmi}
                onChange={(e) => setParams({ ...params, bmi: Number(e.target.value) })}
                className="w-full accent-[#00d4b4] cursor-pointer"
              />
            </div>

            {/* Fasting Glucose Slider */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-400">Fasting Blood Glucose</span>
                <span className="font-mono text-[#00d4b4] font-bold">{params.glucose} mg/dL</span>
              </div>
              <input
                type="range"
                min="70"
                max="260"
                value={params.glucose}
                onChange={(e) => setParams({ ...params, glucose: Number(e.target.value) })}
                className="w-full accent-[#00d4b4] cursor-pointer"
              />
            </div>

            {/* Systolic BP Slider */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-400">Systolic Blood Pressure</span>
                <span className="font-mono text-[#00d4b4] font-bold">{params.bp} mmHg</span>
              </div>
              <input
                type="range"
                min="80"
                max="200"
                value={params.bp}
                onChange={(e) => setParams({ ...params, bp: Number(e.target.value) })}
                className="w-full accent-[#00d4b4] cursor-pointer"
              />
            </div>

            {/* Total Cholesterol */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-400">Total Serum Cholesterol</span>
                <span className="font-mono text-[#00d4b4] font-bold">{params.chol} mg/dL</span>
              </div>
              <input
                type="range"
                min="100"
                max="350"
                value={params.chol}
                onChange={(e) => setParams({ ...params, chol: Number(e.target.value) })}
                className="w-full accent-[#00d4b4] cursor-pointer"
              />
            </div>

            {/* HbA1c */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-400">Glycated Hemoglobin (HbA1c)</span>
                <span className="font-mono text-[#00d4b4] font-bold">{params.hba1c}%</span>
              </div>
              <input
                type="range"
                min="4.0"
                max="12.0"
                step="0.1"
                value={params.hba1c}
                onChange={(e) => setParams({ ...params, hba1c: Number(e.target.value) })}
                className="w-full accent-[#00d4b4] cursor-pointer"
              />
            </div>

            {/* Resting Heart Rate */}
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-400">Resting Heart Rate</span>
                <span className="font-mono text-[#00d4b4] font-bold">{params.hr} BPM</span>
              </div>
              <input
                type="range"
                min="45"
                max="130"
                value={params.hr}
                onChange={(e) => setParams({ ...params, hr: Number(e.target.value) })}
                className="w-full accent-[#00d4b4] cursor-pointer"
              />
            </div>

            {/* Lifestyle binary toggles */}
            <div className="grid grid-cols-2 gap-2 pt-2 border-t border-white/10">
              <button
                type="button"
                onClick={() => setParams({ ...params, smoking: !params.smoking })}
                className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-between transition-all ${
                  params.smoking
                    ? 'bg-rose-500/20 border-rose-500 text-rose-300'
                    : 'bg-[#0b1425] border-white/10 text-slate-400'
                }`}
              >
                <span>🚬 Active Smoker</span>
                <span className="text-[10px] font-mono">{params.smoking ? 'YES' : 'NO'}</span>
              </button>

              <button
                type="button"
                onClick={() => setParams({ ...params, family: !params.family })}
                className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-between transition-all ${
                  params.family
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                    : 'bg-[#0b1425] border-white/10 text-slate-400'
                }`}
              >
                <span>🧬 Family History</span>
                <span className="text-[10px] font-mono">{params.family ? 'YES' : 'NO'}</span>
              </button>

              <button
                type="button"
                onClick={() => setParams({ ...params, exercise: !params.exercise })}
                className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-between transition-all ${
                  params.exercise
                    ? 'bg-emerald-500/20 border-emerald-500 text-emerald-300'
                    : 'bg-[#0b1425] border-white/10 text-slate-400'
                }`}
              >
                <span>🏃 Regular Exercise</span>
                <span className="text-[10px] font-mono">{params.exercise ? 'YES' : 'NO'}</span>
              </button>

              <button
                type="button"
                onClick={() => setParams({ ...params, alcohol: !params.alcohol })}
                className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center justify-between transition-all ${
                  params.alcohol
                    ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                    : 'bg-[#0b1425] border-white/10 text-slate-400'
                }`}
              >
                <span>🍺 Alcohol Use</span>
                <span className="text-[10px] font-mono">{params.alcohol ? 'YES' : 'NO'}</span>
              </button>
            </div>
          </div>

          <button
            onClick={handleRunSimulation}
            disabled={isRunning}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#00d4b4] via-[#4f8cff] to-cyan-300 text-black font-bold text-xs hover:opacity-95 transition-opacity shadow-lg shadow-[#00d4b4]/20 flex items-center justify-center gap-2 mt-3"
          >
            <Play className="w-3.5 h-3.5 fill-black" />
            <span>{isRunning ? 'Traversing 100 Decision Trees…' : 'Execute 100-Tree Random Forest'}</span>
          </button>
        </div>

        {/* 100-Tree Canvas Voting & Risk Output */}
        <div className="space-y-6">
          {/* Forest Canvas Grid */}
          <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
                <Layers className="w-4 h-4 text-[#4f8cff]" />
                <span>Ensemble Voting (100 Trees)</span>
              </h3>
              <span className="text-[10px] font-mono text-slate-400">GINI IMPURITY SPLIT</span>
            </div>

            <div className="rounded-xl bg-[#0b1425] p-2 border border-white/5 flex items-center justify-center">
              <canvas
                ref={canvasRef}
                width={480}
                height={120}
                className="w-full max-w-full"
              />
            </div>

            <div className="flex items-center justify-between text-xs font-mono pt-1">
              <span className="text-emerald-400">● Low Risk: {votes.low} trees</span>
              <span className="text-amber-400">● Moderate: {votes.mid} trees</span>
              <span className="text-rose-400">● High Risk: {votes.high} trees</span>
            </div>
          </div>

          {/* Disease Risk Bars */}
          <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-white/10">
              <h3 className="font-bold text-sm text-slate-100">Stratified Disease Vulnerability</h3>
              <span
                className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                  currentScore > 0.6
                    ? 'bg-rose-500/20 text-rose-400 border-rose-500/30'
                    : currentScore > 0.35
                    ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                    : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                }`}
              >
                OVERALL: {currentScore > 0.6 ? 'HIGH RISK' : currentScore > 0.35 ? 'MODERATE RISK' : 'LOW RISK'}
              </span>
            </div>

            <div className="space-y-2.5">
              {getDiseaseRisks().map((d, i) => (
                <div key={i} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-300 font-medium">{d.name}</span>
                    <span className="font-mono font-bold" style={{ color: d.color }}>
                      {d.val}%
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-black/40 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{ width: `${d.val}%`, backgroundColor: d.color }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Feature Importance & Recommendations */}
          <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-3">
            <h3 className="font-bold text-xs text-slate-300 uppercase tracking-wider font-mono">
              // FEATURE IMPORTANCE (MEAN DECREASE GINI)
            </h3>
            <div className="space-y-1.5">
              {getFeatureImportance().map((f, idx) => (
                <div key={idx} className="flex items-center gap-2 text-xs">
                  <span className="w-48 text-slate-400 truncate text-[11px]">{f.name}</span>
                  <div className="flex-1 h-1.5 bg-black/40 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] rounded-full"
                      style={{ width: `${f.pct * 3}%` }}
                    />
                  </div>
                  <span className="font-mono text-[#00d4b4] text-[10px] w-8 text-right font-bold">
                    {f.pct}%
                  </span>
                </div>
              ))}
            </div>

            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-slate-300 leading-relaxed mt-3 flex items-start gap-2">
              <Lightbulb className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <strong className="text-amber-300">Preventative Prescription:</strong> Maintaining 150 min/wk aerobic exercise and shifting to a low-GI diet could reduce your 5-year Type 2 Diabetes probability by approximately 34%.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
