import React, { useState, useEffect, useRef } from 'react';
import { Smile, Frown, Meh, HeartHandshake, Wind, Sparkles, AlertCircle, Play, Pause } from 'lucide-react';

export const MentalHealth: React.FC = () => {
  const [mood, setMood] = useState<'great' | 'good' | 'neutral' | 'anxious' | 'down'>('good');
  const [breathingActive, setBreathingActive] = useState(false);
  const [breathPhase, setBreathPhase] = useState<'Inhale (4s)' | 'Hold (7s)' | 'Exhale (8s)'>('Inhale (4s)');
  const [timerCount, setTimerCount] = useState(4);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // 4-7-8 Guided Breathing Loop
  useEffect(() => {
    let interval: any;
    if (breathingActive) {
      let sec = 0;
      interval = setInterval(() => {
        sec++;
        const cycle = sec % 19; // 4 + 7 + 8 = 19
        if (cycle < 4) {
          setBreathPhase('Inhale (4s)');
          setTimerCount(4 - cycle);
        } else if (cycle < 11) {
          setBreathPhase('Hold (7s)');
          setTimerCount(11 - cycle);
        } else {
          setBreathPhase('Exhale (8s)');
          setTimerCount(19 - cycle);
        }
      }, 1000);
    } else {
      setBreathPhase('Inhale (4s)');
      setTimerCount(4);
    }
    return () => clearInterval(interval);
  }, [breathingActive]);

  // Canvas Breathing Ring Animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let frame = 0;
    let animId: number;

    const render = () => {
      frame++;
      const W = canvas.width;
      const H = canvas.height;
      const cx = W / 2;
      const cy = H / 2;

      ctx.clearRect(0, 0, W, H);

      let scale = 1;
      let strokeColor = '#00d4b4';

      if (breathingActive) {
        if (breathPhase.startsWith('Inhale')) {
          scale = 1 + ((4 - timerCount) / 4) * 0.45;
          strokeColor = '#00d4b4';
        } else if (breathPhase.startsWith('Hold')) {
          scale = 1.45;
          strokeColor = '#4f8cff';
        } else {
          scale = 1.45 - ((8 - timerCount) / 8) * 0.45;
          strokeColor = '#a78bfa';
        }
      }

      const r = 50 * scale;

      // Outer glow
      ctx.beginPath();
      ctx.arc(cx, cy, r + 10, 0, Math.PI * 2);
      ctx.strokeStyle = strokeColor + '33';
      ctx.lineWidth = 14;
      ctx.stroke();

      // Main circle
      ctx.beginPath();
      ctx.arc(cx, cy, r, 0, Math.PI * 2);
      ctx.fillStyle = strokeColor + '22';
      ctx.fill();
      ctx.strokeStyle = strokeColor;
      ctx.lineWidth = 3;
      ctx.stroke();

      // Phase Text
      ctx.fillStyle = '#f8fafc';
      ctx.font = 'bold 13px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(breathingActive ? breathPhase : 'Ready', cx, cy - 6);

      ctx.fillStyle = strokeColor;
      ctx.font = 'bold 16px monospace';
      ctx.fillText(breathingActive ? String(timerCount) : '▶', cx, cy + 14);

      animId = requestAnimationFrame(render);
    };

    render();
    return () => cancelAnimationFrame(animId);
  }, [breathingActive, breathPhase, timerCount]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            Mental Health &amp; <span>Cognitive Resilience</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // AUTONOMIC HRV BIOFEEDBACK · 4-7-8 DIAPHRAGMATIC PACER · MINDFULNESS
          </div>
        </div>
      </div>

      {/* Mood Logger */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
        <h3 className="font-bold text-sm text-slate-100">How are you feeling right now?</h3>

        <div className="grid grid-cols-5 gap-2 sm:gap-3">
          {[
            { id: 'great', label: 'Energized', icon: '😄', color: 'border-emerald-500' },
            { id: 'good', label: 'Calm', icon: '🙂', color: 'border-[#00d4b4]' },
            { id: 'neutral', label: 'Neutral', icon: '😐', color: 'border-slate-500' },
            { id: 'anxious', label: 'Anxious', icon: '😰', color: 'border-amber-500' },
            { id: 'down', label: 'Fatigued', icon: '😔', color: 'border-rose-500' },
          ].map((m) => (
            <button
              key={m.id}
              onClick={() => setMood(m.id as any)}
              className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-center gap-1 ${
                mood === m.id
                  ? `bg-[#0b1425] ${m.color} shadow-lg shadow-white/5`
                  : 'bg-[#0b1425]/40 border-white/5 hover:border-white/15'
              }`}
            >
              <span className="text-2xl">{m.icon}</span>
              <span className="text-xs font-medium text-slate-300">{m.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* 4-7-8 Breathing Circle */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl flex flex-col items-center justify-center space-y-4 text-center">
          <div className="flex items-center gap-2">
            <Wind className="w-4 h-4 text-[#00d4b4]" />
            <h3 className="font-bold text-sm text-slate-100">4-7-8 Parasympathetic Reset</h3>
          </div>

          <canvas ref={canvasRef} width={240} height={240} className="max-w-full" />

          <button
            onClick={() => setBreathingActive(!breathingActive)}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs shadow-md flex items-center gap-2"
          >
            {breathingActive ? <Pause className="w-3.5 h-3.5 fill-black" /> : <Play className="w-3.5 h-3.5 fill-black" />}
            <span>{breathingActive ? 'Pause Session' : 'Start 2-Minute Breathing'}</span>
          </button>
        </div>

        {/* Cognitive & Autonomic Stress Markers */}
        <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
          <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2 pb-2 border-b border-white/10">
            <Sparkles className="w-4 h-4 text-[#4f8cff]" />
            <span>Biometric Stress Indicators</span>
          </h3>

          <div className="space-y-3">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Autonomic HRV Recovery</span>
                <span className="font-mono text-emerald-400 font-bold">54 ms (Optimal)</span>
              </div>
              <div className="h-1.5 w-full bg-black/40 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-400 rounded-full" style={{ width: '74%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Cumulative Allostatic Load</span>
                <span className="font-mono text-[#00d4b4] font-bold">Low (28%)</span>
              </div>
              <div className="h-1.5 w-full bg-black/40 rounded-full overflow-hidden">
                <div className="h-full bg-[#00d4b4] rounded-full" style={{ width: '28%' }} />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-300">Sleep Architecture Restoration</span>
                <span className="font-mono text-[#4f8cff] font-bold">88 / 100</span>
              </div>
              <div className="h-1.5 w-full bg-black/40 rounded-full overflow-hidden">
                <div className="h-full bg-[#4f8cff] rounded-full" style={{ width: '88%' }} />
              </div>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-slate-300 flex items-start gap-2 mt-4">
            <HeartHandshake className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <span>
              Your daytime sympathetic tone is well-regulated. A 10-minute evening breathing cycle promotes deep restorative slow-wave sleep.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
