import React, { useState, useEffect, useRef } from 'react';
import {
  Truck,
  Upload,
  FileCheck2,
  CheckCircle2,
  Phone,
  RefreshCw,
  Ambulance,
  ThermometerSnowflake,
  Clock,
  ShieldCheck,
  MapPin,
  X
} from 'lucide-react';
import { FLEET_UNITS } from '../../data/mockData';

interface ExtractedMedicine {
  name: string;
  qty: string;
  type: string;
  price: number;
}

export const MedicineDelivery: React.FC = () => {
  const [prescriptionFile, setPrescriptionFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [scanning, setScanning] = useState(false);
  const [extractedMeds, setExtractedMeds] = useState<ExtractedMedicine[] | null>([
    { name: 'Metformin 500mg', qty: '× 30 tabs', type: 'Antidiabetic / Biguanide', price: 120 },
    { name: 'Atorvastatin 10mg', qty: '× 30 tabs', type: 'Lipid Lowering / Statin', price: 85 },
    { name: 'Telmisartan 40mg', qty: '× 15 tabs', type: 'Antihypertensive / ARB', price: 65 },
  ]);

  const [truckProgress, setTruckProgress] = useState(0.42); // 0 to 1
  const [etaMins, setEtaMins] = useState(43);
  const [distanceKm, setDistanceKm] = useState(3.2);
  const [speedKmh, setSpeedKmh] = useState(28);
  const [orderConfirmed, setOrderConfirmed] = useState(true);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Handle Prescription Upload
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setPrescriptionFile(file);
    if (file.type.startsWith('image/')) {
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    }
    setScanning(true);
    setTimeout(() => {
      setScanning(false);
      setExtractedMeds([
        { name: 'Metformin 500mg Extended Release', qty: '× 60 tabs', type: 'Antidiabetic', price: 210 },
        { name: 'Atorvastatin 10mg', qty: '× 30 tabs', type: 'Cardiovascular', price: 85 },
        { name: 'Multivitamin B-Complex', qty: '× 30 caps', type: 'Nutritional', price: 95 },
      ]);
    }, 1800);
  };

  const handleClearRx = () => {
    setPrescriptionFile(null);
    setPreviewUrl(null);
    setExtractedMeds(null);
  };

  // Live Canvas Delivery Map
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let t = truckProgress;

    const renderMap = () => {
      const W = canvas.width;
      const H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      // Background grid
      ctx.strokeStyle = 'rgba(0, 212, 180, 0.05)';
      ctx.lineWidth = 1;
      for (let x = 0; x < W; x += 40) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, H);
        ctx.stroke();
      }
      for (let y = 0; y < H; y += 40) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(W, y);
        ctx.stroke();
      }

      // City blocks (dark rectangles)
      const blocks = [
        { x: 40, y: 30, w: 70, h: 50 },
        { x: 140, y: 30, w: 90, h: 50 },
        { x: 260, y: 30, w: 80, h: 50 },
        { x: 370, y: 30, w: 70, h: 50 },
        { x: 40, y: 120, w: 80, h: 60 },
        { x: 150, y: 120, w: 70, h: 60 },
        { x: 250, y: 120, w: 90, h: 60 },
        { x: 370, y: 120, w: 80, h: 60 },
      ];

      blocks.forEach((b) => {
        ctx.fillStyle = '#0b1425';
        ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.roundRect(b.x, b.y, b.w, b.h, 6);
        ctx.fill();
        ctx.stroke();
      });

      // Waypoints route: Pharmacy -> Home
      const waypoints = [
        { x: W * 0.12, y: H * 0.35 },
        { x: W * 0.30, y: H * 0.35 },
        { x: W * 0.30, y: H * 0.75 },
        { x: W * 0.65, y: H * 0.75 },
        { x: W * 0.65, y: H * 0.40 },
        { x: W * 0.88, y: H * 0.40 },
      ];

      // Road background line
      ctx.beginPath();
      ctx.moveTo(waypoints[0].x, waypoints[0].y);
      for (let i = 1; i < waypoints.length; i++) {
        ctx.lineTo(waypoints[i].x, waypoints[i].y);
      }
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.1)';
      ctx.lineWidth = 8;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.stroke();

      // Road active progress line (Teal glow)
      const totalSegs = waypoints.length - 1;
      const segFloat = t * totalSegs;
      const curSeg = Math.min(Math.floor(segFloat), totalSegs - 1);
      const segT = segFloat - curSeg;

      ctx.beginPath();
      ctx.moveTo(waypoints[0].x, waypoints[0].y);
      for (let i = 1; i <= curSeg; i++) {
        ctx.lineTo(waypoints[i].x, waypoints[i].y);
      }
      const curX = waypoints[curSeg].x + (waypoints[curSeg + 1].x - waypoints[curSeg].x) * segT;
      const curY = waypoints[curSeg].y + (waypoints[curSeg + 1].y - waypoints[curSeg].y) * segT;
      ctx.lineTo(curX, curY);

      ctx.strokeStyle = '#00d4b4';
      ctx.lineWidth = 4;
      ctx.shadowColor = '#00d4b4';
      ctx.shadowBlur = 10;
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Pharmacy Marker
      const pStart = waypoints[0];
      ctx.beginPath();
      ctx.arc(pStart.x, pStart.y, 14, 0, Math.PI * 2);
      ctx.fillStyle = '#0b1425';
      ctx.fill();
      ctx.strokeStyle = '#34d399';
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.fillStyle = '#34d399';
      ctx.font = '10px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('🏥', pStart.x, pStart.y);

      // Home Marker
      const pEnd = waypoints[waypoints.length - 1];
      ctx.beginPath();
      ctx.arc(pEnd.x, pEnd.y, 14, 0, Math.PI * 2);
      ctx.fillStyle = '#0b1425';
      ctx.fill();
      ctx.strokeStyle = '#4f8cff';
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.fillStyle = '#4f8cff';
      ctx.font = '10px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('🏠', pEnd.x, pEnd.y);

      // Moving Delivery Van
      ctx.beginPath();
      ctx.arc(curX, curY, 15, 0, Math.PI * 2);
      ctx.fillStyle = '#00d4b4';
      ctx.shadowColor = '#00d4b4';
      ctx.shadowBlur = 15;
      ctx.fill();
      ctx.shadowBlur = 0;

      ctx.fillStyle = '#000';
      ctx.font = 'bold 11px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('🚚', curX, curY);

      // Pulse truck movement slightly
      t = (t + 0.0006) % 1;
      setTruckProgress(t);
      setDistanceKm(Math.max(0.3, +((1 - t) * 5.2).toFixed(1)));
      setEtaMins(Math.max(3, Math.round((1 - t) * 45)));

      animId = requestAnimationFrame(renderMap);
    };

    renderMap();
    return () => cancelAnimationFrame(animId);
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            Medicine <span>Delivery &amp; Fleet</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // AUTONOMOUS ELECTRIC FLEET · TEMPERATURE CONTROLLED (2-8°C) · DRONE BACKUP
          </div>
        </div>
      </div>

      {/* Prescription Uploader Section */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
            <FileCheck2 className="w-4 h-4 text-[#00d4b4]" />
            <span>Upload Doctor Prescription</span>
          </h3>
          <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-[#00d4b4]/10 text-[#00d4b4] border border-[#00d4b4]/30">
            AI OCR VERIFIED
          </span>
        </div>

        {!previewUrl ? (
          <div className="border-2 border-dashed border-white/15 rounded-xl p-8 text-center hover:border-[#00d4b4] transition-colors cursor-pointer relative bg-white/[0.01]">
            <input
              type="file"
              accept="image/*,.pdf"
              onChange={handleFileChange}
              className="absolute inset-0 opacity-0 cursor-pointer"
            />
            <div className="w-12 h-12 rounded-full bg-[#00d4b4]/10 text-[#00d4b4] mx-auto flex items-center justify-center mb-3">
              <Upload className="w-6 h-6" />
            </div>
            <div className="text-xs font-semibold text-slate-200">
              Drop prescription slip here, or click to browse
            </div>
            <div className="text-[11px] text-slate-500 font-mono mt-1">
              Supports JPG, PNG, PDF · Auto-scanned by clinical OCR
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-xl bg-[#0b1425] border border-white/10">
              <div className="flex items-center gap-3">
                <img
                  src={previewUrl}
                  alt="Prescription Preview"
                  className="w-14 h-14 object-cover rounded-lg border border-white/10"
                />
                <div>
                  <div className="text-xs font-bold text-slate-200">{prescriptionFile?.name}</div>
                  <div className="text-[10px] font-mono text-emerald-400 flex items-center gap-1 mt-0.5">
                    <CheckCircle2 className="w-3 h-3" /> Blockchain Hash: 0xf3c1…9a02
                  </div>
                </div>
              </div>
              <button
                onClick={handleClearRx}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}

        {/* Extracted Medicines Card */}
        {extractedMeds && (
          <div className="p-4 rounded-xl bg-[#0b1425] border border-white/5 space-y-3">
            <div className="text-xs font-mono uppercase tracking-wider text-slate-400 font-bold">
              // MEDICINES DETECTED FROM PRESCRIPTION
            </div>
            <div className="space-y-2">
              {extractedMeds.map((m, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-2.5 rounded-lg bg-[#080e1c] border border-white/5 text-xs"
                >
                  <div>
                    <span className="font-bold text-slate-200">{m.name}</span>
                    <span className="text-[11px] text-slate-400 ml-2 font-mono">{m.qty}</span>
                    <div className="text-[10px] text-slate-500">{m.type}</div>
                  </div>
                  <span className="font-mono text-[#00d4b4] font-bold">₹{m.price}</span>
                </div>
              ))}
            </div>

            <div className="pt-2 border-t border-white/10 flex items-center justify-between">
              <div className="text-xs text-slate-400 font-mono">
                Order Total: <span className="font-bold text-[#00d4b4]">₹{extractedMeds.reduce((s, x) => s + x.price, 0)}</span>
              </div>
              <button
                onClick={() => setOrderConfirmed(true)}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs shadow-md"
              >
                {orderConfirmed ? 'Re-Dispatch Autonomous Delivery' : 'Place Order & Track'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Live Map & Tracking Telemetry */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <Truck className="w-4 h-4 text-[#00d4b4]" />
              <span>Autonomous Delivery Live Telemetry</span>
            </h3>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 animate-pulse">
              IN TRANSIT · ORDER #MN-4421
            </span>
          </div>

          <div className="relative rounded-xl overflow-hidden border border-white/10 bg-[#060c18]">
            <canvas ref={canvasRef} width={600} height={260} className="w-full h-auto" />
            <div className="absolute top-3 left-3 px-2.5 py-1 rounded-lg bg-black/80 backdrop-blur-md border border-[#00d4b4]/30 text-[11px] font-mono text-[#00d4b4] flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-[#00d4b4] animate-ping" />
              <span>LIVE GPS TELEMETRY</span>
            </div>
            <div className="absolute top-3 right-3 px-2.5 py-1 rounded-lg bg-black/80 backdrop-blur-md border border-amber-500/30 text-[11px] font-mono text-amber-300 font-bold">
              ETA: {etaMins} MINS
            </div>
          </div>

          {/* Van Telemetry Metrics */}
          <div className="grid grid-cols-4 gap-2 text-center text-xs">
            <div className="p-2.5 rounded-xl bg-[#0b1425] border border-white/5">
              <div className="text-[10px] font-mono text-slate-500">SPEED</div>
              <div className="font-mono font-bold text-slate-200 mt-0.5">{speedKmh} km/h</div>
            </div>
            <div className="p-2.5 rounded-xl bg-[#0b1425] border border-white/5">
              <div className="text-[10px] font-mono text-slate-500">DISTANCE</div>
              <div className="font-mono font-bold text-[#00d4b4] mt-0.5">{distanceKm} km</div>
            </div>
            <div className="p-2.5 rounded-xl bg-[#0b1425] border border-white/5">
              <div className="text-[10px] font-mono text-slate-500">CARGO TEMP</div>
              <div className="font-mono font-bold text-cyan-300 mt-0.5 flex items-center justify-center gap-1">
                <ThermometerSnowflake className="w-3 h-3 text-cyan-400" />
                <span>4.2°C</span>
              </div>
            </div>
            <div className="p-2.5 rounded-xl bg-[#0b1425] border border-white/5">
              <div className="text-[10px] font-mono text-slate-500">PROTOCOL</div>
              <div className="font-mono font-bold text-emerald-400 mt-0.5">Cold Chain ✓</div>
            </div>
          </div>
        </div>

        {/* Fleet & Emergency Standby */}
        <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-white/10">
            <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <Ambulance className="w-4 h-4 text-rose-400" />
              <span>Rapid Emergency Fleet</span>
            </h3>
            <span className="text-[10px] font-mono text-slate-400">108 NETWORK</span>
          </div>

          <div className="space-y-2.5">
            {FLEET_UNITS.map((u) => (
              <div key={u.id} className="p-3 rounded-xl bg-[#0b1425] border border-white/5 space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-200">{u.id} · {u.name}</span>
                  <span
                    className={`text-[9px] font-mono px-1.5 py-0.2 rounded border ${
                      u.status === 'AVAILABLE'
                        ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                        : u.status === 'DEPLOYED'
                        ? 'bg-rose-500/15 text-rose-400 border-rose-500/30'
                        : 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                    }`}
                  >
                    {u.status}
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 truncate">{u.equipment}</div>
                <div className="text-[10px] font-mono text-[#00d4b4]">Average ETA: {u.eta}</div>
              </div>
            ))}
          </div>

          <button
            onClick={() => alert('Emergency dispatch protocol initiated. Dialing 108…')}
            className="w-full py-2.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-300 font-bold text-xs flex items-center justify-center gap-2 transition-colors"
          >
            <Phone className="w-4 h-4" />
            <span>Emergency 108 Dispatch Trigger</span>
          </button>
        </div>
      </div>
    </div>
  );
};
