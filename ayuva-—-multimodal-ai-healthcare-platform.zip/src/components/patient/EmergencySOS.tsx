import React, { useState, useEffect } from 'react';
import { AlertTriangle, Phone, MapPin, Radio, ShieldAlert, CheckCircle2 } from 'lucide-react';
import { HOSPITALS } from '../../data/mockData';

export const EmergencySOS: React.FC = () => {
  const [holding, setHolding] = useState(false);
  const [holdProgress, setHoldProgress] = useState(0);
  const [activated, setActivated] = useState(false);
  const [gpsCoords, setGpsCoords] = useState('13.6288° N, 79.4192° E (Tirupati)');

  useEffect(() => {
    let interval: any;
    if (holding && !activated) {
      interval = setInterval(() => {
        setHoldProgress((p) => {
          if (p >= 100) {
            setActivated(true);
            setHolding(false);
            return 100;
          }
          return p + 10;
        });
      }, 100);
    } else if (!holding && !activated) {
      setHoldProgress(0);
    }
    return () => clearInterval(interval);
  }, [holding, activated]);

  return (
    <div className="space-y-6 max-w-3xl mx-auto">
      <div className="text-center space-y-1">
        <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-slate-100 flex items-center justify-center gap-2">
          <AlertTriangle className="w-7 h-7 text-rose-500 animate-bounce" />
          <span>Emergency Rapid Response (108)</span>
        </h2>
        <div className="text-xs font-mono text-slate-400">
          // INSTANT MULTI-NETWORK CRITICAL TRIAGE · SATELLITE RELAY · 2-MINUTE SLA
        </div>
      </div>

      {/* Big Interactive SOS Button */}
      <div className="p-8 sm:p-12 rounded-3xl bg-gradient-to-b from-rose-950/40 via-[#080e1c] to-[#080e1c] border border-rose-500/30 shadow-2xl flex flex-col items-center text-center space-y-6">
        {!activated ? (
          <>
            <div className="relative">
              {/* Outer pulsating wave */}
              <div className="absolute inset-0 rounded-full bg-rose-500/20 animate-ping" />

              <button
                onMouseDown={() => setHolding(true)}
                onMouseUp={() => setHolding(false)}
                onTouchStart={() => setHolding(true)}
                onTouchEnd={() => setHolding(false)}
                className="relative w-44 h-44 rounded-full bg-gradient-to-tr from-rose-600 via-rose-500 to-red-500 text-white font-black text-2xl tracking-wider shadow-2xl shadow-rose-600/50 flex flex-col items-center justify-center select-none active:scale-95 transition-transform"
              >
                <span>SOS</span>
                <span className="text-[11px] font-mono font-normal uppercase tracking-normal opacity-80 mt-1">
                  Hold 1 Sec
                </span>

                {/* Circular Progress Overlay */}
                {holdProgress > 0 && (
                  <div className="absolute inset-0 rounded-full border-4 border-white animate-pulse" />
                )}
              </button>
            </div>

            <div className="text-xs text-slate-300 font-mono">
              Press &amp; hold to trigger immediate autonomous dispatch, family alerts, and hospital trauma bed hold.
            </div>
          </>
        ) : (
          <div className="p-6 rounded-2xl bg-rose-500/10 border border-rose-500/30 text-rose-300 space-y-3 w-full">
            <div className="flex items-center justify-center gap-2 text-rose-400 font-bold text-base">
              <span className="w-3 h-3 rounded-full bg-rose-500 animate-ping" />
              <span>EMERGENCY DISPATCH PROTOCOL BROADCASTED</span>
            </div>
            <p className="text-xs text-slate-200">
              Ambulance <span className="font-mono font-bold text-white">AMB-108-ALPHA</span> dispatched from SVIMS Hub. ETA: <span className="font-mono text-emerald-400 font-bold">4 Minutes</span>.
            </p>
            <div className="text-[11px] font-mono text-slate-400">
              Broadcasting GPS: {gpsCoords}
            </div>
            <button
              onClick={() => {
                setActivated(false);
                setHoldProgress(0);
              }}
              className="px-4 py-1.5 rounded-xl bg-white/[0.08] hover:bg-white/[0.15] text-xs font-semibold text-slate-300"
            >
              Cancel Alert (Accidental Trigger)
            </button>
          </div>
        )}
      </div>

      {/* Immediate Trauma Centers */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
        <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
          <MapPin className="w-4 h-4 text-rose-400" />
          <span>Nearest Level 1 Trauma Bays (Real-Time Availability)</span>
        </h3>

        <div className="space-y-3">
          {HOSPITALS.slice(0, 3).map((h) => (
            <div
              key={h.id}
              className="p-3.5 rounded-xl bg-[#0b1425] border border-white/5 flex items-center justify-between gap-3 text-xs"
            >
              <div>
                <div className="font-bold text-slate-200">{h.name}</div>
                <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                  {h.address} · {h.distance}
                </div>
              </div>
              <div className="text-right shrink-0">
                <div className="text-emerald-400 font-mono font-bold">{h.waitTime}</div>
                <button
                  onClick={() => alert(`Connecting to Emergency ER line for ${h.name}…`)}
                  className="text-[11px] text-[#00d4b4] hover:underline font-semibold flex items-center gap-1 justify-end mt-1"
                >
                  <Phone className="w-3 h-3" /> Call ER
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
