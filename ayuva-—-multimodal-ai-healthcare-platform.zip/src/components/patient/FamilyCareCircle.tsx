import React, { useState } from 'react';
import { Users, Heart, Phone, Plus, Bell, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { FAMILY_MEMBERS } from '../../data/mockData';
import { FamilyMember } from '../../types';

export const FamilyCareCircle: React.FC = () => {
  const [members, setMembers] = useState<FamilyMember[]>(FAMILY_MEMBERS);
  const [showInvite, setShowInvite] = useState(false);
  const [inviteName, setInviteName] = useState('');
  const [inviteRelation, setInviteRelation] = useState('Parent');
  const [invitePhone, setInvitePhone] = useState('');

  const handleInvite = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteName) return;
    const newM: FamilyMember = {
      id: `fam-${Date.now()}`,
      name: inviteName,
      relation: inviteRelation,
      avatar: inviteName.split(' ').map((w) => w[0]).join('').slice(0, 2).toUpperCase(),
      vitals: {
        hr: 74,
        bp: '122/80',
        sugar: 108,
      },
      status: 'Normal',
      lastUpdate: 'Just now',
    };
    setMembers([...members, newM]);
    setInviteName('');
    setInvitePhone('');
    setShowInvite(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            Family <span>Care Circle</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // SECURE KINSHIP TELEMETRY · SHARED CRITICAL ALERTS · GEOLOCATION WATCH
          </div>
        </div>

        <button
          onClick={() => setShowInvite(true)}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs shadow-md hover:opacity-90 transition-opacity self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Family Member</span>
        </button>
      </div>

      {/* Members Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {members.map((m) => (
          <div
            key={m.id}
            className="p-5 rounded-2xl bg-[#080e1c] border border-white/10 hover:border-white/20 transition-all shadow-xl space-y-4"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#00d4b4] to-[#4f8cff] text-black font-bold flex items-center justify-center text-sm shadow-md">
                  {m.avatar}
                </div>
                <div>
                  <h4 className="font-bold text-sm text-slate-100">{m.name}</h4>
                  <div className="text-xs text-[#00d4b4] font-medium">{m.relation}</div>
                </div>
              </div>

              <span
                className={`text-[10px] font-mono px-2 py-0.5 rounded-full border ${
                  m.status === 'Normal'
                    ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                    : 'bg-amber-500/15 text-amber-400 border-amber-500/30'
                }`}
              >
                {m.status.toUpperCase()}
              </span>
            </div>

            {/* Live Vitals Snapshot */}
            <div className="p-3 rounded-xl bg-[#0b1425] border border-white/5 grid grid-cols-3 gap-2 text-center text-xs">
              <div>
                <div className="text-[10px] font-mono text-slate-500">HEART RATE</div>
                <div className="font-mono font-bold text-slate-200 mt-0.5">{m.vitals.hr} bpm</div>
              </div>
              <div>
                <div className="text-[10px] font-mono text-slate-500">BLOOD PRESS.</div>
                <div className="font-mono font-bold text-[#00d4b4] mt-0.5">{m.vitals.bp}</div>
              </div>
              <div>
                <div className="text-[10px] font-mono text-slate-500">GLUCOSE</div>
                <div className="font-mono font-bold text-amber-400 mt-0.5">{m.vitals.sugar} mg</div>
              </div>
            </div>

            <div className="flex items-center justify-between text-xs pt-1">
              <span className="text-[10px] font-mono text-slate-500">Updated {m.lastUpdate}</span>
              <button
                onClick={() => alert(`Calling emergency contact for ${m.name}…`)}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/[0.04] hover:bg-white/[0.08] text-slate-300 font-semibold"
              >
                <Phone className="w-3.5 h-3.5 text-[#00d4b4]" />
                <span>Call Member</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Shared Alerts Timeline */}
      <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-3">
        <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
          <Bell className="w-4 h-4 text-[#4f8cff]" />
          <span>Shared Family Health Activity Feed</span>
        </h3>

        <div className="space-y-2.5">
          <div className="p-3 rounded-xl bg-[#0b1425] border border-white/5 flex items-start gap-3 text-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-slate-200">Srinivas Rao (Father)</span> took Morning Medication (Telmisartan 40mg).
              <div className="text-[10px] font-mono text-slate-500 mt-0.5">Today at 08:15 AM · Verified via Smart Blister</div>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-[#0b1425] border border-white/5 flex items-start gap-3 text-xs">
            <Heart className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold text-slate-200">Lakshmi Rao (Mother)</span> completed 30-min morning walk (3,420 steps).
              <div className="text-[10px] font-mono text-slate-500 mt-0.5">Today at 07:30 AM · Apple Watch Sync</div>
            </div>
          </div>
        </div>
      </div>

      {/* Invite Modal */}
      {showInvite && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="max-w-md w-full rounded-2xl bg-[#080e1c] border border-white/10 p-6 space-y-4">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-lg font-bold text-slate-100">Add Family Care Member</h3>
                <div className="text-xs text-slate-400 font-mono">Send ABHA Kinship link</div>
              </div>
              <button onClick={() => setShowInvite(false)} className="text-slate-400 hover:text-white">
                ✕
              </button>
            </div>

            <form onSubmit={handleInvite} className="space-y-3">
              <div>
                <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
                  Full Name
                </label>
                <input
                  type="text"
                  required
                  value={inviteName}
                  onChange={(e) => setInviteName(e.target.value)}
                  placeholder="e.g. Ramesh Kumar"
                  className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-[#00d4b4]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
                  Relationship
                </label>
                <select
                  value={inviteRelation}
                  onChange={(e) => setInviteRelation(e.target.value)}
                  className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-[#00d4b4]"
                >
                  <option>Parent</option>
                  <option>Spouse</option>
                  <option>Child</option>
                  <option>Sibling</option>
                  <option>Caregiver</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-mono uppercase text-slate-400 mb-1">
                  Mobile Number / ABHA ID
                </label>
                <input
                  type="tel"
                  value={invitePhone}
                  onChange={(e) => setInvitePhone(e.target.value)}
                  placeholder="+91 98765 43210"
                  className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-[#00d4b4]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowInvite(false)}
                  className="px-4 py-2 rounded-xl bg-white/[0.05] text-xs font-semibold text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs"
                >
                  Connect Telemetry
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
