import React, { useState } from 'react';
import { FlaskConical, Sparkles, Upload, FileText, CheckCircle2, AlertTriangle, ArrowRight } from 'lucide-react';
import { analyzeLabReport } from '../../services/api';

interface Biomarker {
  name: string;
  value: number;
  unit: string;
  normalRange: string;
  status: 'normal' | 'low' | 'high';
}

const SAMPLE_PANELS: Record<string, Biomarker[]> = {
  cbc: [
    { name: 'Hemoglobin', value: 14.2, unit: 'g/dL', normalRange: '13.5 - 17.5', status: 'normal' },
    { name: 'White Blood Cells (WBC)', value: 6800, unit: '/µL', normalRange: '4500 - 11000', status: 'normal' },
    { name: 'Platelets', value: 245000, unit: '/µL', normalRange: '150000 - 450000', status: 'normal' },
    { name: 'Red Blood Cells (RBC)', value: 4.8, unit: 'M/µL', normalRange: '4.3 - 5.9', status: 'normal' },
    { name: 'Hematocrit', value: 43.1, unit: '%', normalRange: '41.0 - 50.0', status: 'normal' },
  ],
  lipid: [
    { name: 'Total Cholesterol', value: 218, unit: 'mg/dL', normalRange: '< 200', status: 'high' },
    { name: 'LDL Direct', value: 138, unit: 'mg/dL', normalRange: '< 100', status: 'high' },
    { name: 'HDL Protective', value: 44, unit: 'mg/dL', normalRange: '> 40', status: 'normal' },
    { name: 'Triglycerides', value: 182, unit: 'mg/dL', normalRange: '< 150', status: 'high' },
    { name: 'Non-HDL Cholesterol', value: 174, unit: 'mg/dL', normalRange: '< 130', status: 'high' },
  ],
  metabolic: [
    { name: 'Fasting Plasma Glucose', value: 114, unit: 'mg/dL', normalRange: '70 - 99', status: 'high' },
    { name: 'Glycated HbA1c', value: 5.9, unit: '%', normalRange: '< 5.7', status: 'high' },
    { name: 'Serum Creatinine', value: 0.95, unit: 'mg/dL', normalRange: '0.7 - 1.3', status: 'normal' },
    { name: 'Blood Urea Nitrogen (BUN)', value: 16, unit: 'mg/dL', normalRange: '7 - 20', status: 'normal' },
    { name: 'eGFR', value: 92, unit: 'mL/min', normalRange: '> 90', status: 'normal' },
  ],
};

export const LabAnalyzer: React.FC = () => {
  const [selectedPanel, setSelectedPanel] = useState<string>('lipid');
  const [panelData, setPanelData] = useState<Biomarker[]>(SAMPLE_PANELS['lipid']);
  const [loading, setLoading] = useState(false);
  const [aiReport, setAiReport] = useState<string | null>(
    `The Lipid Profile demonstrates **mild hypercholesterolemia** (Total Cholesterol 218 mg/dL) with elevated **LDL Direct** (138 mg/dL) and **Triglycerides** (182 mg/dL). HDL is within acceptable baseline (44 mg/dL). 

**Clinical Implications:**
- 10-Year ASCVD Risk: Estimated at 7.2% (Borderline / Intermediate).
- Elevated Non-HDL indicates increased atherogenic particle burden.

**Physician-Guided Action Plan:**
1. **Nutritional Adjustment:** Transition to Mediterranean dietary pattern with reduced saturated fats (<7% total caloric intake) and increased soluble fiber (oats, psyllium).
2. **Physical Activity:** Aim for 150 minutes/week of moderate aerobic exercise (brisk walking/cycling).
3. **Follow-Up:** Repeat fasting lipid panel and ApoB in 90 days. Discuss low-dose statin optimization with Dr. Rajesh Kumar if LDL remains >130 mg/dL.`
  );

  const handleSelectPanel = (key: string) => {
    setSelectedPanel(key);
    setPanelData(SAMPLE_PANELS[key]);
  };

  const handleAnalyze = async () => {
    setLoading(true);
    const summaryStr = panelData.map((b) => `${b.name}: ${b.value} ${b.unit} (Ref: ${b.normalRange})`).join('\n');
    try {
      const res = await analyzeLabReport(summaryStr, selectedPanel.toUpperCase());
      setAiReport(res.analysis);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <h2 className="text-2xl font-extrabold tracking-tight text-slate-100">
            Lab Report <span>AI Analyzer</span>
          </h2>
          <div className="text-xs font-mono text-slate-400 mt-0.5">
            // DEEP BIOMARKER INTERPRETATION · GEMINI 3.8 FLASH · REFERENCE RANGES
          </div>
        </div>
      </div>

      {/* Panel Selection Chips */}
      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => handleSelectPanel('lipid')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all border ${
            selectedPanel === 'lipid'
              ? 'bg-[#00d4b4]/20 border-[#00d4b4] text-[#00d4b4]'
              : 'bg-[#080e1c] border-white/10 text-slate-400 hover:text-white'
          }`}
        >
          🧪 Lipid Panel
        </button>
        <button
          onClick={() => handleSelectPanel('metabolic')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all border ${
            selectedPanel === 'metabolic'
              ? 'bg-[#00d4b4]/20 border-[#00d4b4] text-[#00d4b4]'
              : 'bg-[#080e1c] border-white/10 text-slate-400 hover:text-white'
          }`}
        >
          🩸 Glycemic &amp; Renal Panel
        </button>
        <button
          onClick={() => handleSelectPanel('cbc')}
          className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all border ${
            selectedPanel === 'cbc'
              ? 'bg-[#00d4b4]/20 border-[#00d4b4] text-[#00d4b4]'
              : 'bg-[#080e1c] border-white/10 text-slate-400 hover:text-white'
          }`}
        >
          🔬 Complete Blood Count (CBC)
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Extracted Biomarkers Table */}
        <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <FlaskConical className="w-4 h-4 text-[#00d4b4]" />
              <span>Extracted Biomarkers</span>
            </h3>
            <span className="text-[10px] font-mono text-slate-400">
              {panelData.length} ANALYTES
            </span>
          </div>

          <div className="space-y-2">
            {panelData.map((b, idx) => (
              <div
                key={idx}
                className="p-3 rounded-xl bg-[#0b1425] border border-white/5 flex items-center justify-between text-xs"
              >
                <div>
                  <div className="font-bold text-slate-200">{b.name}</div>
                  <div className="text-[10px] font-mono text-slate-500 mt-0.5">
                    Ref: {b.normalRange} {b.unit}
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-mono font-bold text-slate-100">
                    {b.value} {b.unit}
                  </div>
                  <span
                    className={`text-[9px] font-mono px-1.5 py-0.2 rounded border inline-block mt-0.5 ${
                      b.status === 'normal'
                        ? 'bg-emerald-500/15 text-emerald-400 border-emerald-500/30'
                        : 'bg-rose-500/15 text-rose-400 border-rose-500/30'
                    }`}
                  >
                    {b.status.toUpperCase()}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <button
            onClick={handleAnalyze}
            disabled={loading}
            className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs shadow-lg shadow-[#00d4b4]/20 hover:opacity-90 transition-opacity flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            <span>{loading ? 'Synthesizing Pathological Insights…' : 'Generate AI Clinical Analysis'}</span>
          </button>
        </div>

        {/* AI Interpretation Panel */}
        <div className="p-5 sm:p-6 rounded-2xl bg-[#080e1c] border border-white/10 shadow-xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <h3 className="font-bold text-sm text-slate-100 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>Gemini Clinical Summary</span>
            </h3>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
              PHYSICIAN-GRADE
            </span>
          </div>

          {loading ? (
            <div className="p-8 text-center space-y-3">
              <div className="w-8 h-8 rounded-full border-2 border-[#00d4b4] border-t-transparent animate-spin mx-auto" />
              <div className="text-xs text-slate-400 font-mono">
                Correlating values with age-stratified epidemiological risk…
              </div>
            </div>
          ) : (
            aiReport && (
              <div className="prose prose-invert max-w-none text-xs text-slate-300 leading-relaxed whitespace-pre-wrap">
                {aiReport}
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
};
