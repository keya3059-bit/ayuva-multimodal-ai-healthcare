import React, { useState } from 'react';
import { PortalType, UserProfile } from '../types';
import { ArrowLeft, User, Lock, Mail, Phone, Calendar, ArrowRight } from 'lucide-react';

interface AuthModalProps {
  portal: PortalType;
  onSuccess: (user: UserProfile) => void;
  onBack: () => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({ portal, onSuccess, onBack }) => {
  const [tab, setTab] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [age, setAge] = useState('34');
  const [phone, setPhone] = useState('');

  const getPortalDetails = () => {
    switch (portal) {
      case 'doctor':
        return {
          title: 'Doctor Console',
          defaultName: 'Dr. Rajesh Kumar',
          defaultRole: 'Interventional Cardiologist',
          defaultAv: 'RK',
        };
      case 'admin':
        return {
          title: 'Admin Control Center',
          defaultName: 'System Administrator',
          defaultRole: 'Hospital Chief Administrator',
          defaultAv: 'AD',
        };
      default:
        return {
          title: 'Patient Portal',
          defaultName: 'Arjun Reddy',
          defaultRole: 'Patient',
          defaultAv: 'AR',
        };
    }
  };

  const details = getPortalDetails();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    let name = details.defaultName;
    let av = details.defaultAv;

    if (email && email.includes('@')) {
      const handle = email.split('@')[0].replace(/[._\d]+/g, ' ').trim();
      if (handle) {
        name = handle
          .split(' ')
          .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
          .join(' ');
        av = name
          .split(' ')
          .map((w) => w[0])
          .slice(0, 2)
          .join('')
          .toUpperCase() || 'AU';
      }
    }

    onSuccess({
      id: `usr-${Date.now()}`,
      name,
      role: details.defaultRole,
      avatar: av,
      portal,
      age: parseInt(age, 10) || 34,
      email: email || `${portal}@ayuva.health`,
    });
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    const fullName = firstName ? (lastName ? `${firstName} ${lastName}` : firstName) : details.defaultName;
    const av = (firstName ? firstName[0] + (lastName ? lastName[0] : '') : details.defaultAv).toUpperCase();

    onSuccess({
      id: `usr-${Date.now()}`,
      name: fullName,
      role: details.defaultRole,
      avatar: av,
      portal,
      age: parseInt(age, 10) || 34,
      email: email || `${firstName.toLowerCase()}@ayuva.health`,
      phone,
    });
  };

  const handleDemoLogin = () => {
    onSuccess({
      id: `demo-${portal}`,
      name: details.defaultName,
      role: details.defaultRole,
      avatar: details.defaultAv,
      portal,
      age: 34,
      email: `${portal}.demo@ayuva.health`,
    });
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative">
      <div className="max-w-md w-full rounded-3xl bg-[#080e1c] border border-white/10 shadow-2xl overflow-hidden backdrop-blur-2xl">
        {/* Header */}
        <div className="p-6 text-center border-b border-white/10 bg-gradient-to-br from-[#00d4b4]/10 via-[#4f8cff]/5 to-transparent">
          <button
            onClick={onBack}
            className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors mb-3"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Back to portal select
          </button>
          <div className="text-2xl font-extrabold tracking-tight bg-gradient-to-r from-[#00d4b4] via-[#4f8cff] to-cyan-300 bg-clip-text text-transparent">
            AYUVA
          </div>
          <div className="text-xs font-semibold text-slate-300 mt-0.5">
            {details.title}
          </div>
        </div>

        {/* Tab switch */}
        <div className="p-6">
          <div className="flex rounded-xl bg-white/[0.04] p-1 border border-white/5 mb-5">
            <button
              onClick={() => setTab('login')}
              className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
                tab === 'login'
                  ? 'bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Sign In
            </button>
            <button
              onClick={() => setTab('register')}
              className={`flex-1 py-2 text-xs font-semibold rounded-lg transition-all ${
                tab === 'register'
                  ? 'bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black shadow-md'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Create Account
            </button>
          </div>

          {tab === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-3.5">
              <div>
                <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                  Email Address
                </label>
                <div className="relative flex items-center">
                  <Mail className="w-4 h-4 text-slate-500 absolute left-3" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full bg-[#0b1425] border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-[#00d4b4] transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                  Password
                </label>
                <div className="relative flex items-center">
                  <Lock className="w-4 h-4 text-slate-500 absolute left-3" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-[#0b1425] border border-white/10 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-[#00d4b4] transition-colors"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs hover:opacity-90 transition-opacity shadow-lg shadow-[#00d4b4]/20 flex items-center justify-center gap-2"
              >
                <span>Sign In to {details.title}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

              <div className="pt-2 text-center">
                <button
                  type="button"
                  onClick={handleDemoLogin}
                  className="text-xs text-[#00d4b4] hover:underline font-semibold"
                >
                  ⚡ Or continue with 1-click Demo Account →
                </button>
              </div>
            </form>
          ) : (
            <form onSubmit={handleRegister} className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                    First Name
                  </label>
                  <input
                    type="text"
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    placeholder="Arjun"
                    required
                    className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-[#00d4b4]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                    Last Name
                  </label>
                  <input
                    type="text"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    placeholder="Reddy"
                    className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-[#00d4b4]"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                    Age
                  </label>
                  <input
                    type="number"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    min="1"
                    max="120"
                    className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-[#00d4b4]"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                    Phone
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+91 98765 43210"
                    className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-[#00d4b4]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="arjun@email.com"
                  required
                  className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-[#00d4b4]"
                />
              </div>

              <div>
                <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                  Create Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full bg-[#0b1425] border border-white/10 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-[#00d4b4]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-[#00d4b4] to-[#4f8cff] text-black font-bold text-xs hover:opacity-90 transition-opacity shadow-lg shadow-[#00d4b4]/20 flex items-center justify-center gap-2 mt-2"
              >
                <span>Register &amp; Launch</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
