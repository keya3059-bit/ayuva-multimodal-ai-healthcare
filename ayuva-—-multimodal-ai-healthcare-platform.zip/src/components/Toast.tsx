import React from 'react';
import { CheckCircle, AlertCircle, Info, X } from 'lucide-react';

export interface ToastMessage {
  id: string;
  type: 'ok' | 'err' | 'info';
  message: string;
}

interface ToastProps {
  toasts: ToastMessage[];
  onDismiss: (id: string) => void;
}

export const ToastContainer: React.FC<ToastProps> = ({ toasts, onDismiss }) => {
  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2 pointer-events-none max-w-sm w-full">
      {toasts.map((t) => (
        <div
          key={t.id}
          className={`pointer-events-auto flex items-center gap-3 p-3.5 rounded-xl border backdrop-blur-xl shadow-2xl transition-all animate-in slide-in-from-right-8 duration-300 ${
            t.type === 'ok'
              ? 'bg-[#081c15]/95 border-emerald-500/40 text-emerald-300'
              : t.type === 'err'
              ? 'bg-[#2a0b0e]/95 border-rose-500/40 text-rose-300'
              : 'bg-[#0b1425]/95 border-cyan-500/40 text-cyan-300'
          }`}
        >
          {t.type === 'ok' && <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />}
          {t.type === 'err' && <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />}
          {t.type === 'info' && <Info className="w-4 h-4 text-cyan-400 shrink-0" />}
          <div className="flex-1 text-xs font-medium text-slate-100">{t.message}</div>
          <button
            onClick={() => onDismiss(t.id)}
            className="text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
};
