import React, { useState, useEffect } from 'react';
import {
  Lock,
  Unlock,
  Key,
  FileCode,
  ShieldCheck,
  CheckCircle2,
  Copy,
  Check,
  AlertTriangle,
  FileCheck2,
  RefreshCw
} from 'lucide-react';
import { runPythonFhirCrypto } from '../../services/api';

export const FhirCryptoStudio: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'bundle' | 'crypto' | 'signature'>('crypto');
  const [loading, setLoading] = useState<boolean>(false);
  const [fhirData, setFhirData] = useState<any>(null);
  const [copied, setCopied] = useState<boolean>(false);

  const fetchFhirCrypto = async () => {
    setLoading(true);
    try {
      const data = await runPythonFhirCrypto({
        patient: {
          id: 'patient_ayu_7842',
          name: 'Alex Morgan',
          gender: 'female',
          birthDate: '1968-04-12',
          troponin: 1.84,
          systolic_bp: 154,
          primary_dx: 'Non-ST-Elevation Myocardial Infarction (NSTEMI)'
        }
      });
      setFhirData(data);
    } catch (err) {
      console.error('FHIR Crypto error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchFhirCrypto();
  }, []);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-blue-900/40 via-indigo-900/30 to-slate-900/50 border border-blue-500/30 backdrop-blur-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-blue-500/20 text-blue-300 border border-blue-500/40">
                HL7 FHIR R4 • AES-256-GCM • RSA-4096 • SHA-256 Attestation
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" /> HIPAA Technical Safeguards Compliant
              </span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              FHIR R4 Interoperability & Cryptography Enclave
            </h2>
            <p className="text-slate-300 text-xs mt-1 max-w-2xl">
              Generates standard HL7 FHIR R4 resource bundles with zero-trust payload encryption (AES-256-GCM) and RSA-4096 non-repudiation cryptographic signatures.
            </p>
          </div>

          <button
            onClick={fetchFhirCrypto}
            disabled={loading}
            className="flex items-center justify-center gap-2 px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-semibold text-xs transition-all shadow-lg shadow-blue-600/25 disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Regenerate Keys & Bundle</span>
          </button>
        </div>

        {/* Tab Controls */}
        <div className="mt-4 pt-4 border-t border-white/10 flex items-center gap-2">
          <button
            onClick={() => setActiveTab('crypto')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'crypto'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <Lock className="w-3.5 h-3.5" />
            <span>AES-256-GCM Encryption</span>
          </button>

          <button
            onClick={() => setActiveTab('bundle')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'bundle'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" />
            <span>HL7 FHIR R4 JSON Bundle</span>
          </button>

          <button
            onClick={() => setActiveTab('signature')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
              activeTab === 'signature'
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
            }`}
          >
            <FileCheck2 className="w-3.5 h-3.5" />
            <span>RSA-4096 Digital Attestation</span>
          </button>
        </div>
      </div>

      {/* Main Content Areas */}
      {activeTab === 'crypto' && fhirData?.encryption && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Encrypted Ciphertext */}
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-slate-300">
              <span className="flex items-center gap-2 font-bold text-rose-400">
                <Lock className="w-4 h-4" />
                AES-256-GCM Ciphertext (At Rest / In Transit)
              </span>
              <button
                onClick={() => copyToClipboard(fhirData.encryption.ciphertext_hex)}
                className="text-[10px] text-slate-400 hover:text-white flex items-center gap-1"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                Copy Hex
              </button>
            </div>

            <div className="space-y-2 text-[11px]">
              <div>
                <span className="text-slate-500">Algorithm:</span>{' '}
                <span className="text-blue-300">{fhirData.encryption.algorithm}</span>
              </div>
              <div>
                <span className="text-slate-500">Initialization Vector (IV):</span>{' '}
                <span className="text-amber-300">{fhirData.encryption.iv_hex}</span>
              </div>
              <div>
                <span className="text-slate-500">Authentication Tag (GCM):</span>{' '}
                <span className="text-emerald-300">{fhirData.encryption.auth_tag_hex}</span>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-rose-300 break-all max-h-48 overflow-y-auto leading-relaxed">
              {fhirData.encryption.ciphertext_hex}
            </div>
          </div>

          {/* Decrypted Payload */}
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800 text-slate-300">
              <span className="flex items-center gap-2 font-bold text-emerald-400">
                <Unlock className="w-4 h-4" />
                Decrypted Clinical Payload (Verified Auth Tag)
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                MAC Verified
              </span>
            </div>

            <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 overflow-x-auto max-h-64 leading-relaxed text-[11px]">
              {fhirData.encryption.decrypted_plaintext}
            </pre>
          </div>
        </div>
      )}

      {activeTab === 'bundle' && fhirData?.fhir_bundle && (
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3 font-mono text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <span className="text-slate-300 font-bold">Standard HL7 FHIR R4 Bundle Resource</span>
            <button
              onClick={() => copyToClipboard(JSON.stringify(fhirData.fhir_bundle, null, 2))}
              className="text-xs text-blue-400 hover:text-blue-300 flex items-center gap-1"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>Copy FHIR JSON</span>
            </button>
          </div>

          <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 overflow-x-auto max-h-96 leading-relaxed text-[11px]">
            {JSON.stringify(fhirData.fhir_bundle, null, 2)}
          </pre>
        </div>
      )}

      {activeTab === 'signature' && fhirData?.digital_signature && (
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4 font-mono text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-slate-800">
            <span className="text-slate-200 font-bold text-sm flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Physician RSA-4096 Non-Repudiation Attestation
            </span>
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              Valid Signature
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-1">
              <div className="text-[10px] text-slate-400">Signatory:</div>
              <div className="text-sm font-bold text-white">{fhirData.digital_signature.signer}</div>
            </div>
            <div className="p-3 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-1">
              <div className="text-[10px] text-slate-400">Timestamp:</div>
              <div className="text-sm font-bold text-white">{fhirData.digital_signature.timestamp}</div>
            </div>
          </div>

          <div>
            <div className="text-[10px] text-slate-400 mb-1">Payload SHA-256 Digest:</div>
            <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-cyan-300">
              {fhirData.digital_signature.payload_hash_sha256}
            </div>
          </div>

          <div>
            <div className="text-[10px] text-slate-400 mb-1">RSA-4096 Signature Hex:</div>
            <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 text-emerald-300 break-all leading-relaxed">
              {fhirData.digital_signature.signature_hex}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
