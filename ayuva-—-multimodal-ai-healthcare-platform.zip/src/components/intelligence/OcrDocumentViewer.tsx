import React, { useState, useEffect } from 'react';
import {
  FileText,
  Scan,
  CheckCircle2,
  AlertCircle,
  FileCheck,
  Search,
  Upload,
  ArrowRight,
  ShieldCheck,
  Download,
  Eye
} from 'lucide-react';
import { runPythonOcrPdf } from '../../services/api';

const SAMPLE_DOCS = [
  {
    id: 'discharge_01',
    name: 'Cardiac Care Unit - Urgent Discharge Summary.pdf',
    type: 'discharge_summary',
    pages: 3,
    size: '1.4 MB'
  },
  {
    id: 'lab_02',
    name: 'Stat Comprehensive Metabolic & Cardiac Biomarker Panel.pdf',
    type: 'lab_report',
    pages: 1,
    size: '420 KB'
  },
  {
    id: 'rad_03',
    name: 'Coronary Computed Tomography Angiography (CCTA).pdf',
    type: 'radiology_report',
    pages: 2,
    size: '890 KB'
  }
];

export const OcrDocumentViewer: React.FC = () => {
  const [selectedDoc, setSelectedDoc] = useState<string>('discharge_01');
  const [loading, setLoading] = useState<boolean>(false);
  const [ocrData, setOcrData] = useState<any>(null);

  const fetchOcrData = async (docId: string) => {
    setLoading(true);
    try {
      const data = await runPythonOcrPdf({
        document_id: docId,
        ocr_engine: 'PyMuPDF_fitz_v1.24_and_Tesseract',
        extract_geometry: true
      });
      setOcrData(data);
    } catch (err) {
      console.error('OCR parsing error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOcrData(selectedDoc);
  }, [selectedDoc]);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-amber-900/40 via-orange-900/30 to-slate-900/50 border border-amber-500/30 backdrop-blur-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-amber-500/20 text-amber-300 border border-amber-500/40">
                OCR • PyMuPDF (fitz) • LayoutLMv3 • Named Entity Recognition
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" /> HIPAA Redacted
              </span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Clinical Document OCR & PyMuPDF (fitz) Entity Extractor
            </h2>
            <p className="text-slate-300 text-xs mt-1 max-w-2xl">
              Parses scanned unstructured medical reports, laboratory PDFs, and handwritten dictations with layout bounding-box geometry and regex/NLP entity mapping.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => fetchOcrData(selectedDoc)}
              disabled={loading}
              className="px-4 py-2 rounded-xl bg-amber-600 hover:bg-amber-500 text-white font-semibold text-xs transition-all flex items-center gap-1.5 shadow-lg shadow-amber-600/25"
            >
              <Scan className="w-4 h-4" />
              <span>{loading ? 'Ingesting PDF...' : 'Re-scan Document'}</span>
            </button>
          </div>
        </div>

        {/* Document Selector Pills */}
        <div className="mt-4 pt-4 border-t border-white/10 flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-400 font-mono">Sample Documents:</span>
          {SAMPLE_DOCS.map((doc) => (
            <button
              key={doc.id}
              onClick={() => setSelectedDoc(doc.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition-all flex items-center gap-2 ${
                selectedDoc === doc.id
                  ? 'bg-amber-500/20 border-amber-400 text-amber-200 shadow-md'
                  : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:bg-slate-700'
              }`}
            >
              <FileText className="w-3.5 h-3.5 text-amber-400" />
              <span>{doc.name}</span>
              <span className="text-[10px] font-mono opacity-70">({doc.size})</span>
            </button>
          ))}
        </div>
      </div>

      {/* Main OCR Viewport & Extracted Entities */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Simulated PDF View with Bounding Boxes */}
        <div className="lg:col-span-6 p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Eye className="w-4 h-4 text-amber-400" />
              Document Layout & Bounding Boxes
            </h3>
            <span className="text-[10px] font-mono text-amber-400">fitz Page 1 of 3</span>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs leading-relaxed space-y-3 relative overflow-hidden">
            {ocrData ? (
              <>
                <div className="p-3 bg-amber-500/10 border border-amber-500/40 rounded-lg">
                  <div className="text-[10px] text-amber-400 font-bold uppercase mb-1">
                    [PyMuPDF BBox Extracted Text Segment]
                  </div>
                  <div className="text-slate-200 whitespace-pre-wrap">
                    {ocrData.raw_extracted_text}
                  </div>
                </div>

                <div className="pt-2">
                  <div className="text-xs font-bold text-slate-400 mb-2">Spatial Bounding Coordinates (x0, y0, x1, y1):</div>
                  <div className="space-y-1 text-[10px] text-slate-400 font-mono">
                    {ocrData.bounding_boxes?.map((box: any, i: number) => (
                      <div key={i} className="flex justify-between p-1.5 rounded bg-slate-900 border border-slate-800">
                        <span className="text-amber-300 font-bold">{box.entity}</span>
                        <span className="text-slate-400">[{box.coords.join(', ')}] ({box.confidence} conf)</span>
                      </div>
                    ))}
                  </div>
                </div>
              </>
            ) : (
              <div className="py-12 text-center text-slate-500">Processing PDF via PyMuPDF...</div>
            )}
          </div>
        </div>

        {/* Right Column: Structured Clinical Entities */}
        <div className="lg:col-span-6 space-y-4">
          <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <FileCheck className="w-4 h-4 text-emerald-400" />
                Structured Biomarkers & Clinical Entities
              </h3>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                100% Parsed
              </span>
            </div>

            {/* Extracted Labs */}
            {ocrData?.extracted_entities?.biomarkers && (
              <div className="space-y-2">
                <div className="text-xs font-bold text-slate-300">Extracted Laboratory Values</div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {ocrData.extracted_entities.biomarkers.map((bio: any, idx: number) => (
                    <div key={idx} className="p-3 rounded-xl bg-slate-800/70 border border-slate-700/80 space-y-1">
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-slate-300 font-medium">{bio.test}</span>
                        <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold font-mono ${
                          bio.flag === 'CRITICAL_HIGH' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/40' : 'bg-emerald-500/20 text-emerald-300'
                        }`}>
                          {bio.flag}
                        </span>
                      </div>
                      <div className="text-lg font-bold text-white font-mono">
                        {bio.value} <span className="text-xs text-slate-400 font-normal">{bio.units}</span>
                      </div>
                      <div className="text-[10px] font-mono text-slate-500">Ref: {bio.reference}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Extracted Diagnoses & Meds */}
            {ocrData?.extracted_entities?.medications && (
              <div className="pt-2 border-t border-slate-800 space-y-2">
                <div className="text-xs font-bold text-slate-300">Identified Prescriptions & Dosing</div>
                <div className="space-y-1.5 font-mono text-xs">
                  {ocrData.extracted_entities.medications.map((med: any, idx: number) => (
                    <div key={idx} className="p-2 rounded-lg bg-slate-800/50 border border-slate-700/50 flex items-center justify-between text-slate-200">
                      <span>{med.name}</span>
                      <span className="text-amber-400 text-[11px]">{med.dosage} • {med.frequency}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Ingestion CTA */}
            <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
              <span className="text-xs text-slate-400 font-mono">Ready to inject into Patient Record</span>
              <button className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-all">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>Append to Active Encounter</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
