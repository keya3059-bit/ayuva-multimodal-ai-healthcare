import React, { useState } from 'react';
import {
  Brain,
  TrendingUp,
  Eye,
  GitBranch,
  FileText,
  Lock,
  Server,
  Sparkles,
  ShieldCheck,
  Layers,
  Cpu,
  Workflow
} from 'lucide-react';
import { XGBoostShapStudio } from './XGBoostShapStudio';
import { MonaiOpenCVViewer } from './MonaiOpenCVViewer';
import { LangGraphAgentViewer } from './LangGraphAgentViewer';
import { OcrDocumentViewer } from './OcrDocumentViewer';
import { FhirCryptoStudio } from './FhirCryptoStudio';
import { DockerMicroservicesCockpit } from './DockerMicroservicesCockpit';

export const AyuvaIntelligenceStackHub: React.FC = () => {
  const [activeTab, setActiveTab] = useState<
    'xgboost_shap' | 'monai_cv' | 'langgraph_rag' | 'ocr_pymupdf' | 'fhir_crypto' | 'docker_django'
  >('xgboost_shap');

  const tabs = [
    {
      id: 'xgboost_shap',
      name: 'XGBoost & SHAP',
      subtitle: 'Ensemble Trees & Explainability',
      icon: TrendingUp,
      badge: 'ML/XAI',
      badgeColor: 'bg-purple-500/20 text-purple-300 border-purple-500/30'
    },
    {
      id: 'monai_cv',
      name: 'MONAI & OpenCV',
      subtitle: '3D UNet Vision & HU Windowing',
      icon: Eye,
      badge: 'Vision',
      badgeColor: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30'
    },
    {
      id: 'langgraph_rag',
      name: 'LangGraph & pgvector',
      subtitle: 'Cyclical Agent & Guidelines RAG',
      icon: GitBranch,
      badge: 'Agents',
      badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
    },
    {
      id: 'ocr_pymupdf',
      name: 'OCR & PyMuPDF',
      subtitle: 'fitz Document BBox Extraction',
      icon: FileText,
      badge: 'NLP/OCR',
      badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30'
    },
    {
      id: 'fhir_crypto',
      name: 'FHIR R4 & Crypto',
      subtitle: 'AES-256-GCM & RSA-4096 Attestation',
      icon: Lock,
      badge: 'Security',
      badgeColor: 'bg-blue-500/20 text-blue-300 border-blue-500/30'
    },
    {
      id: 'docker_django',
      name: 'Docker & Django/DRF',
      subtitle: 'Microservices, Celery & MLflow',
      icon: Server,
      badge: 'DevOps',
      badgeColor: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30'
    }
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-purple-950/40 to-slate-900 border border-purple-500/30 shadow-2xl relative overflow-hidden">
        <div className="absolute -right-12 -bottom-12 w-64 h-64 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono uppercase bg-purple-500/20 text-purple-300 border border-purple-500/40 flex items-center gap-1.5">
                <Sparkles className="w-3 h-3 text-purple-400" />
                AYUVA Core Healthcare Intelligence Stack
              </span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" /> All 15 Production Engines Loaded
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Ayuva AI, Medical Vision, NLP & Interoperability Studio
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm mt-1 max-w-3xl leading-relaxed">
              Unified runtime executing <strong>Django/DRF</strong>, <strong>PostgreSQL + pgvector</strong>, <strong>Pydantic</strong>, <strong>Scikit-Learn</strong>, <strong>XGBoost</strong>, <strong>LightGBM</strong>, <strong>PyTorch</strong>, <strong>MONAI</strong>, <strong>OpenCV</strong>, <strong>OCR/PyMuPDF</strong>, <strong>LangChain/LangGraph</strong>, <strong>SHAP</strong>, <strong>FastAPI</strong>, <strong>Celery/Redis</strong>, <strong>MLflow & ONNX Runtime</strong>, <strong>HL7 FHIR</strong>, and <strong>Cryptography</strong>.
            </p>
          </div>
        </div>

        {/* Navigation Selector Tabs */}
        <div className="mt-6 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 pt-4 border-t border-slate-800">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isSelected = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`p-3 rounded-xl text-left border transition-all relative flex flex-col justify-between ${
                  isSelected
                    ? 'bg-purple-900/40 border-purple-400 text-white shadow-lg shadow-purple-900/30'
                    : 'bg-slate-800/60 border-slate-700/60 text-slate-300 hover:bg-slate-800 hover:border-slate-600'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <Icon className={`w-4 h-4 ${isSelected ? 'text-purple-300' : 'text-slate-400'}`} />
                    <span className={`px-1.5 py-0.2 rounded text-[9px] font-mono border ${tab.badgeColor}`}>
                      {tab.badge}
                    </span>
                  </div>
                  <div className="text-xs font-bold leading-tight">{tab.name}</div>
                </div>
                <div className="text-[10px] text-slate-400 mt-1 line-clamp-1">{tab.subtitle}</div>
                {isSelected && (
                  <div className="absolute bottom-0 left-3 right-3 h-0.5 bg-gradient-to-r from-purple-400 to-indigo-400 rounded-full" />
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Dynamic Tab Body */}
      <div>
        {activeTab === 'xgboost_shap' && <XGBoostShapStudio />}
        {activeTab === 'monai_cv' && <MonaiOpenCVViewer />}
        {activeTab === 'langgraph_rag' && <LangGraphAgentViewer />}
        {activeTab === 'ocr_pymupdf' && <OcrDocumentViewer />}
        {activeTab === 'fhir_crypto' && <FhirCryptoStudio />}
        {activeTab === 'docker_django' && <DockerMicroservicesCockpit />}
      </div>
    </div>
  );
};
