import React, { useState, useEffect } from 'react';
import {
  Zap,
  Play,
  RotateCcw,
  Sparkles,
  TrendingUp,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Layers,
  BarChart3,
  GitPullRequest,
  Activity,
  Cpu,
  Info
} from 'lucide-react';
import { runPythonXGBoost, runPythonShap } from '../../services/api';

const PRESETS = [
  {
    name: 'Acute NSTEMI with Severe Stenosis',
    badge: 'Critical Emergency',
    badgeColor: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
    data: { age: 58, sys_bp: 158, dia_bp: 94, glucose: 178, troponin: 0.88, lvef: 44, stenosis: 85, smoking: true, prior_cad: true }
  },
  {
    name: 'Diabetic Microvascular Strain (Intermediate)',
    badge: 'Moderate Risk',
    badgeColor: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
    data: { age: 62, sys_bp: 142, dia_bp: 88, glucose: 165, troponin: 0.03, lvef: 52, stenosis: 55, smoking: false, prior_cad: false }
  },
  {
    name: 'Controlled Normotensive (Preventative)',
    badge: 'Low Baseline',
    badgeColor: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    data: { age: 44, sys_bp: 118, dia_bp: 76, glucose: 94, troponin: 0.01, lvef: 62, stenosis: 15, smoking: false, prior_cad: false }
  }
];

export const XGBoostShapStudio: React.FC = () => {
  const [patient, setPatient] = useState({
    age: 58,
    sys_bp: 154,
    dia_bp: 92,
    glucose: 168,
    troponin: 0.42,
    lvef: 48,
    stenosis: 75,
    smoking: true,
    prior_cad: true
  });

  const [loading, setLoading] = useState<boolean>(false);
  const [xgbResult, setXgbResult] = useState<any>(null);
  const [shapResult, setShapResult] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'shap_waterfall' | 'model_comparison' | 'tree_splits'>('shap_waterfall');

  const executeModels = async () => {
    setLoading(true);
    try {
      const [xgbData, shapData] = await Promise.all([
        runPythonXGBoost(patient),
        runPythonShap(patient)
      ]);
      setXgbResult(xgbData);
      setShapResult(shapData);
    } catch (err) {
      console.error('Inference error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    executeModels();
  }, []);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-purple-900/40 via-indigo-900/30 to-slate-900/50 border border-purple-500/30 backdrop-blur-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-purple-500/20 text-purple-300 border border-purple-500/40">
                XGBoost 2.0 • LightGBM 4.1 • Scikit-Learn • TreeSHAP
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" /> Pydantic v2 Validated
              </span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Gradient Boosted Disease Prediction & Explainable AI (SHAP)
            </h2>
            <p className="text-slate-300 text-xs mt-1 max-w-2xl">
              Simulates pure-Python gradient boosting decision trees with exact Shapley additive attributions, quantifying feature risk contributions against population baseline expectations.
            </p>
          </div>

          <button
            onClick={executeModels}
            disabled={loading}
            className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-xs transition-all shadow-lg shadow-purple-600/25 disabled:opacity-50"
          >
            {loading ? (
              <>
                <RotateCcw className="w-4 h-4 animate-spin" />
                <span>Computing Trees & SHAP...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>Run Ensemble & SHAP</span>
              </>
            )}
          </button>
        </div>

        {/* Presets */}
        <div className="mt-4 pt-4 border-t border-white/10 flex flex-wrap items-center gap-2">
          <span className="text-xs text-slate-400 font-mono">Clinical Scenarios:</span>
          {PRESETS.map((p, idx) => (
            <button
              key={idx}
              onClick={() => {
                setPatient(p.data);
                setTimeout(executeModels, 50);
              }}
              className="px-3 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700/80 border border-slate-700 text-xs text-slate-200 transition-all flex items-center gap-2"
            >
              <span>{p.name}</span>
              <span className={`px-1.5 py-0.2 rounded text-[9px] font-mono border ${p.badgeColor}`}>
                {p.badge}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Inputs vs Explanations */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Feature Controls (Pydantic Schema Form) */}
        <div className="lg:col-span-4 p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Activity className="w-4 h-4 text-purple-400" />
              Patient Biomarkers & Features
            </h3>
            <span className="text-[10px] font-mono text-purple-400">Pydantic Model</span>
          </div>

          <div className="space-y-3 text-xs">
            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Patient Age:</span>
                <span className="font-mono text-purple-300 font-bold">{patient.age} yrs</span>
              </div>
              <input
                type="range"
                min="25"
                max="90"
                value={patient.age}
                onChange={(e) => setPatient({ ...patient, age: Number(e.target.value) })}
                className="w-full accent-purple-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Cardiac Troponin I (ng/mL):</span>
                <span className={`font-mono font-bold ${patient.troponin > 0.04 ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {patient.troponin.toFixed(2)} ng/mL
                </span>
              </div>
              <input
                type="range"
                min="0.01"
                max="2.5"
                step="0.01"
                value={patient.troponin}
                onChange={(e) => setPatient({ ...patient, troponin: Number(e.target.value) })}
                className="w-full accent-purple-500 cursor-pointer"
              />
              <div className="text-[10px] text-slate-500 font-mono">Reference URL: &lt; 0.04 ng/mL (Myocardial Necrosis Threshold)</div>
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Coronary Stenosis (%):</span>
                <span className={`font-mono font-bold ${patient.stenosis >= 70 ? 'text-rose-400' : patient.stenosis >= 50 ? 'text-amber-400' : 'text-emerald-400'}`}>
                  {patient.stenosis}%
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="99"
                value={patient.stenosis}
                onChange={(e) => setPatient({ ...patient, stenosis: Number(e.target.value) })}
                className="w-full accent-purple-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Systolic Blood Pressure:</span>
                <span className="font-mono text-purple-300 font-bold">{patient.sys_bp} mmHg</span>
              </div>
              <input
                type="range"
                min="90"
                max="200"
                value={patient.sys_bp}
                onChange={(e) => setPatient({ ...patient, sys_bp: Number(e.target.value) })}
                className="w-full accent-purple-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Left Ventricular EF (%):</span>
                <span className={`font-mono font-bold ${patient.lvef < 45 ? 'text-rose-400' : patient.lvef < 50 ? 'text-amber-400' : 'text-emerald-400'}`}>
                  {patient.lvef}%
                </span>
              </div>
              <input
                type="range"
                min="20"
                max="75"
                value={patient.lvef}
                onChange={(e) => setPatient({ ...patient, lvef: Number(e.target.value) })}
                className="w-full accent-purple-500 cursor-pointer"
              />
            </div>

            <div>
              <div className="flex justify-between text-slate-300 mb-1">
                <span>Fasting Glucose (mg/dL):</span>
                <span className="font-mono text-purple-300 font-bold">{patient.glucose} mg/dL</span>
              </div>
              <input
                type="range"
                min="70"
                max="300"
                value={patient.glucose}
                onChange={(e) => setPatient({ ...patient, glucose: Number(e.target.value) })}
                className="w-full accent-purple-500 cursor-pointer"
              />
            </div>

            <div className="pt-2 flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                <input
                  type="checkbox"
                  checked={patient.smoking}
                  onChange={(e) => setPatient({ ...patient, smoking: e.target.checked })}
                  className="rounded accent-purple-500"
                />
                Active Smoker
              </label>
              <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                <input
                  type="checkbox"
                  checked={patient.prior_cad}
                  onChange={(e) => setPatient({ ...patient, prior_cad: e.target.checked })}
                  className="rounded accent-purple-500"
                />
                Prior CAD
              </label>
            </div>
          </div>

          {/* Quick Summary Card */}
          {xgbResult && (
            <div className="mt-4 p-4 rounded-xl bg-slate-800/80 border border-slate-700/80 space-y-2">
              <div className="text-[11px] font-mono text-slate-400">Ensemble Consensus Risk</div>
              <div className="flex items-baseline justify-between">
                <span className="text-2xl font-black text-white">{xgbResult.ensemble_probability}%</span>
                <span className="px-2 py-0.5 rounded text-[10px] font-bold font-mono bg-rose-500/20 text-rose-300 border border-rose-500/40">
                  {xgbResult.risk_tier}
                </span>
              </div>
              <div className="text-[11px] text-slate-300 leading-relaxed border-t border-slate-700/60 pt-2">
                {xgbResult.clinical_action}
              </div>
            </div>
          )}
        </div>

        {/* Right Column: SHAP Waterfall, Model Comparisons, Trees */}
        <div className="lg:col-span-8 space-y-4">
          {/* Sub-tabs */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('shap_waterfall')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  activeTab === 'shap_waterfall'
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'bg-slate-800/50 text-slate-400 hover:text-white'
                }`}
              >
                <TrendingUp className="w-3.5 h-3.5" />
                <span>SHAP Waterfall Plot</span>
              </button>

              <button
                onClick={() => setActiveTab('model_comparison')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  activeTab === 'model_comparison'
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'bg-slate-800/50 text-slate-400 hover:text-white'
                }`}
              >
                <BarChart3 className="w-3.5 h-3.5" />
                <span>Model Benchmark (XGB/LGB/RF)</span>
              </button>

              <button
                onClick={() => setActiveTab('tree_splits')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all flex items-center gap-1.5 ${
                  activeTab === 'tree_splits'
                    ? 'bg-purple-600 text-white shadow-md'
                    : 'bg-slate-800/50 text-slate-400 hover:text-white'
                }`}
              >
                <GitPullRequest className="w-3.5 h-3.5" />
                <span>Tree Split Path</span>
              </button>
            </div>

            <span className="text-[10px] font-mono text-slate-400 hidden sm:inline">
              Exact TreeSHAP Kernel (Lundberg et al.)
            </span>
          </div>

          {/* TAB 1: SHAP WATERFALL */}
          {activeTab === 'shap_waterfall' && (
            <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <h4 className="text-sm font-bold text-white flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-purple-400" />
                    Shapley Additive Attribution Waterfall
                  </h4>
                  <p className="text-xs text-slate-400">
                    Visualizes how each clinical biomarker shifts the patient's risk from population baseline E[f(x)] to final prediction f(x).
                  </p>
                </div>
                {shapResult && (
                  <div className="text-right font-mono text-xs">
                    <div className="text-slate-400 text-[10px]">Baseline E[f(x)]: <span className="text-white font-bold">{shapResult.base_value_prob}%</span></div>
                    <div className="text-purple-300 text-[11px]">Final f(x): <span className="text-white font-bold">{shapResult.final_prediction_prob}%</span></div>
                  </div>
                )}
              </div>

              {shapResult ? (
                <div className="space-y-3 pt-2">
                  {shapResult.waterfall_steps.map((step: any, idx: number) => {
                    const isBase = step.type === 'base';
                    const isFinal = step.type === 'final';
                    const isPositive = step.delta > 0;

                    return (
                      <div
                        key={idx}
                        className={`p-3 rounded-xl border transition-all ${
                          isFinal
                            ? 'bg-purple-950/40 border-purple-500/50'
                            : isBase
                            ? 'bg-slate-800/60 border-slate-700/60'
                            : 'bg-slate-900/80 border-slate-800/80'
                        }`}
                      >
                        <div className="flex items-center justify-between text-xs mb-1">
                          <div className="flex items-center gap-2 font-medium">
                            <span
                              className={`w-2 h-2 rounded-full ${
                                isFinal
                                  ? 'bg-purple-400'
                                  : isBase
                                  ? 'bg-slate-400'
                                  : isPositive
                                  ? 'bg-rose-500'
                                  : 'bg-cyan-400'
                              }`}
                            />
                            <span className={isFinal ? 'font-bold text-white text-sm' : 'text-slate-200'}>
                              {step.step}
                            </span>
                          </div>

                          <div className="flex items-center gap-3 font-mono">
                            {!isBase && !isFinal && (
                              <span
                                className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                  isPositive ? 'bg-rose-500/20 text-rose-300' : 'bg-cyan-500/20 text-cyan-300'
                                }`}
                              >
                                {isPositive ? `+${step.delta.toFixed(2)}` : step.delta.toFixed(2)} log-odds
                              </span>
                            )}
                            <span className="font-bold text-white">{step.probability}%</span>
                          </div>
                        </div>

                        {/* Visual Progress / Contribution Bar */}
                        <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden relative">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${
                              isFinal
                                ? 'bg-gradient-to-r from-purple-500 to-indigo-400'
                                : isBase
                                ? 'bg-slate-500'
                                : isPositive
                                ? 'bg-rose-500'
                                : 'bg-cyan-400'
                            }`}
                            style={{ width: `${Math.max(4, Math.min(100, step.probability))}%` }}
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="py-12 text-center text-slate-500 font-mono text-xs">
                  Loading SHAP waterfall attributions...
                </div>
              )}
            </div>
          )}

          {/* TAB 2: MODEL BENCHMARK */}
          {activeTab === 'model_comparison' && (
            <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <Cpu className="w-4 h-4 text-indigo-400" />
                Algorithm Performance Comparison (XGBoost vs LightGBM vs Scikit-Learn)
              </h4>

              {xgbResult?.models && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {Object.entries(xgbResult.models).map(([key, model]: [string, any]) => (
                    <div key={key} className="p-4 rounded-xl bg-slate-800/70 border border-slate-700/80 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-white">{model.name}</span>
                        <span className="px-1.5 py-0.5 rounded text-[9px] font-mono bg-purple-500/20 text-purple-300">
                          {model.latency_ms} ms
                        </span>
                      </div>
                      <div className="text-2xl font-black text-purple-300">{model.probability}%</div>
                      <div className="space-y-1 text-[11px] font-mono text-slate-400 pt-2 border-t border-slate-700/50">
                        <div className="flex justify-between">
                          <span>ROC-AUC:</span>
                          <span className="text-emerald-400 font-bold">{model.roc_auc}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>PR-AUC:</span>
                          <span className="text-emerald-400 font-bold">{model.pr_auc}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Estimators / Trees:</span>
                          <span className="text-white">{model.trees}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Feature Importance Table */}
              {xgbResult?.feature_importances && (
                <div className="pt-4 border-t border-slate-800">
                  <div className="text-xs font-bold text-white mb-2">Global Feature Importance (Gini Gain)</div>
                  <div className="space-y-2">
                    {xgbResult.feature_importances.map((item: any, idx: number) => (
                      <div key={idx} className="flex items-center gap-3 text-xs">
                        <span className="w-36 text-slate-300 truncate">{item.feature}</span>
                        <div className="flex-1 h-2 rounded-full bg-slate-800 overflow-hidden">
                          <div
                            className="h-full bg-indigo-500 rounded-full"
                            style={{ width: `${item.importance * 100 * 2.5}%` }}
                          />
                        </div>
                        <span className="w-12 text-right font-mono text-slate-400">
                          {(item.importance * 100).toFixed(0)}%
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: TREE SPLITS */}
          {activeTab === 'tree_splits' && (
            <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
              <h4 className="text-sm font-bold text-white flex items-center gap-2">
                <GitPullRequest className="w-4 h-4 text-emerald-400" />
                Sample Tree Splitting Rules (Exact Greedy Branching)
              </h4>
              <p className="text-xs text-slate-400">
                Traces the exact conditional decision nodes traversed by the gradient boosted ensemble for this specific patient.
              </p>

              <div className="space-y-2 font-mono text-xs">
                {xgbResult?.sample_tree_splits?.map((split: string, idx: number) => (
                  <div key={idx} className="p-3 rounded-lg bg-slate-800/70 border border-slate-700/60 flex items-center gap-3 text-slate-200">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                    <span>{split}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
