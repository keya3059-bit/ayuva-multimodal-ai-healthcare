import React, { useState, useEffect } from 'react';
import {
  GitBranch,
  Play,
  CheckCircle2,
  AlertTriangle,
  Database,
  Search,
  ShieldCheck,
  RotateCcw,
  Sparkles,
  Layers,
  ArrowRight,
  Workflow
} from 'lucide-react';
import { runPythonLangGraph, runPythonVectorRag } from '../../services/api';

export const LangGraphAgentViewer: React.FC = () => {
  const [running, setRunning] = useState<boolean>(false);
  const [graphResult, setGraphResult] = useState<any>(null);
  const [selectedNode, setSelectedNode] = useState<string>('triage_classification_node');
  const [vectorQuery, setVectorQuery] = useState<string>('coronary stenosis elevated troponin nstemi');
  const [vectorResults, setVectorResults] = useState<any>(null);
  const [vectorLoading, setVectorLoading] = useState<boolean>(false);

  const executeLangGraph = async () => {
    setRunning(true);
    try {
      const data = await runPythonLangGraph({
        patient: {
          name: 'Alex Morgan',
          age: 58,
          symptoms: 'Retrosternal crushing chest tightness radiating to left shoulder with diaphoresis.',
          troponin: 1.84,
          vitals: { bp: '154/92', hr: 94, spo2: 95, glucose: 172 },
          current_medications: ['Metformin 1000mg BID', 'Lisinopril 20mg daily', 'Atorvastatin 40mg daily']
        }
      });
      setGraphResult(data);
    } catch (err) {
      console.error('LangGraph error:', err);
    } finally {
      setRunning(false);
    }
  };

  const executeVectorSearch = async () => {
    setVectorLoading(true);
    try {
      const data = await runPythonVectorRag({
        query: vectorQuery,
        top_k: 3,
        engine: 'pgvector_hnsw'
      });
      setVectorResults(data);
    } catch (err) {
      console.error('Vector search error:', err);
    } finally {
      setVectorLoading(false);
    }
  };

  useEffect(() => {
    executeLangGraph();
    executeVectorSearch();
  }, []);

  const activeNodeData = graphResult?.execution_trace?.find((n: any) => n.node === selectedNode);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-900/40 via-teal-900/30 to-slate-900/50 border border-emerald-500/30 backdrop-blur-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                LangChain • LangGraph StateGraph • pgvector • Qdrant
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 flex items-center gap-1">
                <Workflow className="w-3 h-3" /> Cyclical State Machine
              </span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Multi-Agent Clinical Reasoning & Vector Guideline RAG
            </h2>
            <p className="text-slate-300 text-xs mt-1 max-w-2xl">
              Executes cyclical LangGraph agents coordinating clinical triage, dense vector guideline retrieval (HNSW cosine search), diagnostic synthesis, and pharmacological safety review.
            </p>
          </div>

          <button
            onClick={executeLangGraph}
            disabled={running}
            className="flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-semibold text-xs transition-all shadow-lg shadow-emerald-600/25 disabled:opacity-50"
          >
            {running ? (
              <>
                <RotateCcw className="w-4 h-4 animate-spin" />
                <span>Stepping Graph Nodes...</span>
              </>
            ) : (
              <>
                <Play className="w-4 h-4 fill-current" />
                <span>Execute Agent Graph</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Interactive Graph Node Pipeline */}
      <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
        <div className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
          <GitBranch className="w-4 h-4 text-emerald-400" />
          LangGraph Agent Nodes Execution Pipeline
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {[
            { id: 'triage_classification_node', name: '1. Triage Router', icon: '🚨', type: 'Classifier' },
            { id: 'vector_guideline_rag_node', name: '2. Vector RAG', icon: '🧠', type: 'pgvector / Qdrant' },
            { id: 'diagnostic_reasoning_node', name: '3. Reasoner', icon: '🔬', type: 'Med-PaLM Chain' },
            { id: 'safety_critic_node', name: '4. Safety Critic', icon: '🛡️', type: 'Feedback Guard' },
            { id: 'fhir_hl7_serializer_node', name: '5. FHIR Serializer', icon: '📄', type: 'HL7 Interop' }
          ].map((node) => {
            const isSelected = selectedNode === node.id;
            return (
              <button
                key={node.id}
                onClick={() => setSelectedNode(node.id)}
                className={`p-3.5 rounded-xl text-left border transition-all relative ${
                  isSelected
                    ? 'bg-emerald-950/60 border-emerald-400 text-white shadow-lg'
                    : 'bg-slate-800/60 border-slate-700/60 text-slate-300 hover:bg-slate-800 hover:border-slate-600'
                }`}
              >
                <div className="text-xl mb-1">{node.icon}</div>
                <div className="text-xs font-bold">{node.name}</div>
                <div className="text-[10px] font-mono text-emerald-400 opacity-80">{node.type}</div>
                {isSelected && (
                  <div className="absolute top-2 right-2 w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                )}
              </button>
            );
          })}
        </div>

        {/* Selected Node State Inspector */}
        {activeNodeData && (
          <div className="mt-4 p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between text-slate-400 border-b border-slate-800 pb-2">
              <span className="text-emerald-400 font-bold">Node State: {activeNodeData.node}</span>
              <span className="text-[10px]">Agent: {activeNodeData.agent}</span>
            </div>
            <pre className="text-slate-200 overflow-x-auto whitespace-pre-wrap leading-relaxed text-[11px] bg-slate-900/60 p-3 rounded-lg border border-slate-800">
              {JSON.stringify(activeNodeData.output, null, 2)}
            </pre>
          </div>
        )}
      </div>

      {/* Vector Database RAG Explorer (pgvector & Qdrant) */}
      <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Database className="w-4 h-4 text-cyan-400" />
              pgvector & Qdrant Clinical Knowledge Retrieval (HNSW Cosine Index)
            </h3>
            <p className="text-xs text-slate-400">
              Performs real-time cosine distance vector search over peer-reviewed ACC/AHA, ADA, and KDIGO guidelines.
            </p>
          </div>
        </div>

        {/* Search Bar */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-500" />
            <input
              type="text"
              value={vectorQuery}
              onChange={(e) => setVectorQuery(e.target.value)}
              placeholder="Query clinical guidelines (e.g., troponin nstemi, stroke alteplase, sglt2 diabetes)..."
              className="w-full bg-slate-950/80 border border-slate-800 rounded-xl pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>
          <button
            onClick={executeVectorSearch}
            disabled={vectorLoading}
            className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs flex items-center gap-1.5 transition-all"
          >
            {vectorLoading ? <RotateCcw className="w-3.5 h-3.5 animate-spin" /> : <Search className="w-3.5 h-3.5" />}
            <span>Search Vectors</span>
          </button>
        </div>

        {/* Vector Results */}
        <div className="space-y-3 pt-2">
          {vectorResults?.matched_guidelines?.map((item: any, idx: number) => (
            <div key={idx} className="p-4 rounded-xl bg-slate-800/70 border border-slate-700/80 space-y-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs">
                <span className="font-bold text-white flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-cyan-400" />
                  {item.title}
                </span>
                <div className="flex items-center gap-2 font-mono text-[11px]">
                  <span className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                    Similarity: {(item.cosine_similarity * 100).toFixed(1)}%
                  </span>
                  <span className="text-slate-400">Distance: {item.distance_metric}</span>
                </div>
              </div>

              <div className="text-xs text-slate-300 leading-relaxed pl-4 border-l-2 border-cyan-500/40">
                {item.summary}
              </div>

              <div className="flex items-center justify-between pt-2 text-[10px] font-mono text-slate-400 border-t border-slate-700/50">
                <span>Body: {item.guideline_body}</span>
                <span>Index: {item.index_type}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
