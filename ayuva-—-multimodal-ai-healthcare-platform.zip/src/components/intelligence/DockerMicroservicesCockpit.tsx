import React, { useState, useEffect } from 'react';
import {
  Server,
  Box,
  Database,
  Cpu,
  Activity,
  Layers,
  CheckCircle2,
  Copy,
  Check,
  Download,
  Terminal,
  Zap,
  Clock,
  TrendingUp,
  ShieldCheck
} from 'lucide-react';
import { getDockerArchitectureSpec, runPythonMlflowOnnx } from '../../services/api';

export const DockerMicroservicesCockpit: React.FC = () => {
  const [archData, setArchData] = useState<any>(null);
  const [mlflowData, setMlflowData] = useState<any>(null);
  const [activeCodeTab, setActiveCodeTab] = useState<'docker_compose' | 'django_drf' | 'fastapi' | 'dockerfile'>('docker_compose');
  const [copied, setCopied] = useState<boolean>(false);

  useEffect(() => {
    getDockerArchitectureSpec().then(setArchData).catch(console.error);
    runPythonMlflowOnnx().then(setMlflowData).catch(console.error);
  }, []);

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const getActiveCode = () => {
    if (!archData) return '';
    switch (activeCodeTab) {
      case 'docker_compose':
        return archData.docker_compose_yml;
      case 'django_drf':
        return archData.django_drf_code;
      case 'fastapi':
        return archData.fastapi_code;
      case 'dockerfile':
        return archData.dockerfile_django;
      default:
        return '';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-indigo-950/50 to-slate-900 border border-indigo-500/30 backdrop-blur-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                Docker Compose • Django/DRF • FastAPI • Celery • Redis • MLflow • ONNX
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" /> Microservices Production Ready
              </span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Ayuva Microservices Architecture, Django/DRF & MLflow Cockpit
            </h2>
            <p className="text-slate-300 text-xs mt-1 max-w-2xl">
              Complete production enterprise orchestration combining Django REST Framework (Core EHR), FastAPI (Sub-5ms Inference), PostgreSQL pgvector, and Celery distributed workers.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => copyCode(getActiveCode())}
              className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs transition-all flex items-center gap-1.5 shadow-lg shadow-indigo-600/25"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-300" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'Copied Code!' : 'Copy Active Blueprint'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Microservice Topology Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {archData?.stack_components?.map((svc: any, idx: number) => (
          <div key={idx} className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2 hover:border-slate-700 transition-all">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-2">
                <Box className="w-3.5 h-3.5 text-indigo-400" />
                {svc.name}
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                Port {svc.port}
              </span>
            </div>
            <p className="text-[11px] text-slate-300 leading-relaxed">{svc.purpose}</p>
          </div>
        ))}
      </div>

      {/* MLflow & ONNX Runtime Benchmark Matrix */}
      {mlflowData && (
        <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-400" />
                ONNX Runtime Hardware Acceleration vs Native PyTorch
              </h3>
              <p className="text-xs text-slate-400">
                Measures graph optimization, constant folding, and INT8/FP16 quantization speedups.
              </p>
            </div>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20">
              {mlflowData.onnx_runtime.version}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {mlflowData.onnx_runtime.benchmarks.map((bench: any, idx: number) => (
              <div key={idx} className="p-4 rounded-xl bg-slate-800/60 border border-slate-700/60 space-y-3">
                <div className="text-xs font-bold text-white">{bench.model_name}</div>
                <div className="text-xs font-mono text-emerald-400 font-bold bg-emerald-500/10 p-2 rounded border border-emerald-500/20">
                  {bench.speedup}
                </div>
                <div className="space-y-1 text-[11px] font-mono text-slate-300 pt-1">
                  <div className="flex justify-between">
                    <span>PyTorch FP32 Latency:</span>
                    <span className="text-slate-400">{bench.pytorch_latency_ms} ms</span>
                  </div>
                  <div className="flex justify-between">
                    <span>ONNX INT8 Latency:</span>
                    <span className="text-cyan-400 font-bold">{bench.onnx_int8_quantized_ms} ms</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Throughput:</span>
                    <span className="text-white">{bench.throughput_req_per_sec} req/sec</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Memory:</span>
                    <span className="text-slate-400">{bench.memory_footprint_mb}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Code Blueprint Inspector */}
      <div className="p-5 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            {[
              { key: 'docker_compose', label: 'docker-compose.yml' },
              { key: 'django_drf', label: 'drf_views.py (Django REST)' },
              { key: 'fastapi', label: 'fastapi_main.py (Inference API)' },
              { key: 'dockerfile', label: 'Dockerfile.django' }
            ].map((tab) => (
              <button
                key={tab.key}
                onClick={() => setActiveCodeTab(tab.key as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-medium transition-all ${
                  activeCodeTab === tab.key
                    ? 'bg-indigo-600 text-white shadow-md'
                    : 'bg-slate-800 text-slate-400 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <span className="text-[10px] font-mono text-slate-400">Ready for Cloud Run / Kubernetes</span>
        </div>

        <div className="relative">
          <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 text-slate-200 overflow-x-auto max-h-[480px] font-mono text-xs leading-relaxed">
            {getActiveCode()}
          </pre>
        </div>
      </div>
    </div>
  );
};
