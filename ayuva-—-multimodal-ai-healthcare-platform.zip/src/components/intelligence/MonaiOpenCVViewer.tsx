import React, { useState, useEffect } from 'react';
import {
  Layers,
  Eye,
  Sliders,
  Sparkles,
  Camera,
  Activity,
  CheckCircle2,
  Box,
  Maximize2,
  ShieldCheck,
  RefreshCw,
  Crosshair
} from 'lucide-react';
import { runPythonMonaiCV } from '../../services/api';

export const MonaiOpenCVViewer: React.FC = () => {
  const [organ, setOrgan] = useState<'heart' | 'brain'>('heart');
  const [activeWindow, setActiveWindow] = useState<string>('angio');
  const [activeFilter, setActiveFilter] = useState<'monai_unet' | 'sobel' | 'canny' | 'otsu' | 'raw'>('monai_unet');
  const [loading, setLoading] = useState<boolean>(false);
  const [visionData, setVisionData] = useState<any>(null);
  const [probeHu, setProbeHu] = useState<{ x: number; y: number; hu: number; label: string } | null>(null);

  const fetchVisionMetrics = async () => {
    setLoading(true);
    try {
      const data = await runPythonMonaiCV({
        organ,
        window: activeWindow,
        filter: activeFilter
      });
      setVisionData(data);
    } catch (err) {
      console.error('Vision analysis error:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    setActiveWindow(organ === 'heart' ? 'angio' : 'brain');
  }, [organ]);

  useEffect(() => {
    fetchVisionMetrics();
  }, [organ, activeWindow, activeFilter]);

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = Math.round(((e.clientX - rect.left) / rect.width) * 100);
    const y = Math.round(((e.clientY - rect.top) / rect.height) * 100);

    let hu = 35;
    let label = 'Soft Tissue';
    if (organ === 'heart') {
      if (x > 40 && x < 65 && y > 30 && y < 55) {
        hu = 420;
        label = 'Calcified Coronary Plaque (LAD)';
      } else if (x > 30 && x < 70 && y > 20 && y < 75) {
        hu = 280;
        label = 'Iodinated Contrast in Lumen';
      } else {
        hu = 45;
        label = 'Myocardium';
      }
    } else {
      if (x > 50 && x < 75 && y > 35 && y < 65) {
        hu = 21;
        label = 'Cytotoxic Edema / Acute Ischemia';
      } else if (x > 42 && x < 52 && y > 45 && y < 55) {
        hu = 74;
        label = 'Dense MCA Thrombus Sign';
      } else {
        hu = 36;
        label = 'Normal Cerebral Cortex';
      }
    }

    setProbeHu({ x, y, hu, label });
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="p-5 rounded-2xl bg-gradient-to-r from-cyan-900/40 via-blue-900/30 to-slate-900/50 border border-cyan-500/30 backdrop-blur-md">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono uppercase bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                MONAI 3D SegResNet • OpenCV 4.9 • PyTorch TorchVision
              </span>
              <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                <ShieldCheck className="w-3 h-3" /> DICOM Calibrated
              </span>
            </div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Medical Vision & Image Intelligence Studio
            </h2>
            <p className="text-slate-300 text-xs mt-1 max-w-2xl">
              Combines OpenCV morphological edge transforms and Hounsfield Unit (HU) window leveling with MONAI UNet neural segmentation for automated lesion localization.
            </p>
          </div>

          {/* Organ Selector */}
          <div className="flex items-center gap-2 bg-slate-800/80 p-1.5 rounded-xl border border-slate-700">
            <button
              onClick={() => setOrgan('heart')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                organ === 'heart' ? 'bg-cyan-500 text-black shadow-md' : 'text-slate-300 hover:text-white'
              }`}
            >
              Coronary CTA (Heart)
            </button>
            <button
              onClick={() => setOrgan('brain')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                organ === 'brain' ? 'bg-cyan-500 text-black shadow-md' : 'text-slate-300 hover:text-white'
              }`}
            >
              Stroke CT/MRI (Brain)
            </button>
          </div>
        </div>
      </div>

      {/* Main Vision Canvas & Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Imaging Viewport */}
        <div className="lg:col-span-7 space-y-3">
          <div
            onMouseMove={handleCanvasMouseMove}
            onMouseLeave={() => setProbeHu(null)}
            className="relative w-full aspect-[4/3] rounded-2xl bg-black border border-slate-800 overflow-hidden group cursor-crosshair select-none shadow-2xl flex items-center justify-center"
          >
            {/* Simulated Medical Scan Background */}
            <div className="absolute inset-0 bg-radial from-slate-900 via-slate-950 to-black opacity-90" />

            {/* Scan Simulation Graphic */}
            <div className="relative z-10 w-4/5 h-4/5 rounded-full border border-slate-700/50 flex items-center justify-center p-6 bg-slate-950/60">
              {organ === 'heart' ? (
                <div className="relative w-full h-full flex items-center justify-center">
                  {/* Heart Outline */}
                  <div className="w-48 h-56 rounded-t-full rounded-b-3xl border-2 border-red-500/40 bg-red-950/20 relative">
                    {/* Coronary Artery LAD branch */}
                    <div className="absolute top-6 left-12 w-24 h-36 border-l-4 border-t-2 border-cyan-400 rounded-tl-3xl">
                      {/* Stenosis Lesion Contour */}
                      {activeFilter === 'monai_unet' && (
                        <div className="absolute top-12 -left-3 w-8 h-8 rounded-full border-2 border-dashed border-rose-500 bg-rose-500/30 animate-pulse flex items-center justify-center">
                          <span className="text-[9px] font-mono text-white font-bold">78%</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ) : (
                <div className="relative w-full h-full flex items-center justify-center">
                  {/* Brain Hemisphere Outline */}
                  <div className="w-56 h-56 rounded-full border-2 border-slate-600 bg-slate-900/40 relative">
                    <div className="absolute inset-x-1/2 top-2 bottom-2 w-0.5 bg-slate-700" />
                    {/* Infarct Penumbra Contour */}
                    {activeFilter === 'monai_unet' && (
                      <div className="absolute top-16 right-8 w-20 h-20 rounded-2xl border-2 border-dashed border-amber-400 bg-amber-500/25 animate-pulse flex items-center justify-center">
                        <span className="text-[9px] font-mono text-amber-200 font-bold">Penumbra</span>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Filter Overlay Text */}
            <div className="absolute top-3 left-3 z-20 font-mono text-[10px] text-cyan-400 bg-black/70 px-2 py-1 rounded border border-cyan-500/30 backdrop-blur-sm">
              MODE: {activeFilter.toUpperCase()} | WL: {visionData?.active_window?.center || 40} WW: {visionData?.active_window?.width || 80}
            </div>

            {/* Realtime Hounsfield Unit Probe Tooltip */}
            {probeHu && (
              <div
                className="absolute z-30 pointer-events-none transform -translate-x-1/2 -translate-y-12 bg-slate-900/90 border border-cyan-400/60 text-white font-mono text-[10px] px-2 py-1 rounded shadow-lg backdrop-blur-md"
                style={{ left: `${probeHu.x}%`, top: `${probeHu.y}%` }}
              >
                <div className="text-cyan-300 font-bold">{probeHu.hu} HU</div>
                <div className="text-slate-300 text-[9px]">{probeHu.label}</div>
              </div>
            )}

            {/* Crosshair indicator */}
            {probeHu && (
              <div
                className="absolute z-20 pointer-events-none w-4 h-4 -ml-2 -mt-2 border border-cyan-400/70 rounded-full flex items-center justify-center"
                style={{ left: `${probeHu.x}%`, top: `${probeHu.y}%` }}
              >
                <div className="w-1 h-1 bg-cyan-400 rounded-full" />
              </div>
            )}
          </div>

          {/* Filter Bar */}
          <div className="flex flex-wrap items-center gap-2 pt-2">
            <span className="text-xs font-mono text-slate-400">Transform Engine:</span>
            {[
              { key: 'monai_unet', label: 'MONAI 3D UNet (Segmentation)' },
              { key: 'sobel', label: 'OpenCV Sobel (Gradients)' },
              { key: 'canny', label: 'OpenCV Canny (Borders)' },
              { key: 'otsu', label: 'Otsu Adaptive Threshold' },
              { key: 'raw', label: 'Native DICOM HU' }
            ].map((f) => (
              <button
                key={f.key}
                onClick={() => setActiveFilter(f.key as any)}
                className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                  activeFilter === f.key
                    ? 'bg-cyan-500 text-black font-bold shadow-md'
                    : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>

        {/* Right: DICOM Windows & MONAI Findings */}
        <div className="lg:col-span-5 space-y-4">
          {/* Window Preset Selector */}
          <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Sliders className="w-3.5 h-3.5 text-cyan-400" />
              Radiological Window Leveling (HU)
            </h4>
            <div className="grid grid-cols-2 gap-2">
              {visionData?.available_windows &&
                Object.entries(visionData.available_windows).map(([k, win]: [string, any]) => (
                  <button
                    key={k}
                    onClick={() => setActiveWindow(k)}
                    className={`p-2 rounded-xl text-left border transition-all ${
                      activeWindow === k
                        ? 'bg-cyan-950/40 border-cyan-500/60 text-cyan-200'
                        : 'bg-slate-800/40 border-slate-700/50 text-slate-400 hover:text-white'
                    }`}
                  >
                    <div className="text-xs font-semibold">{win.name}</div>
                    <div className="text-[10px] font-mono opacity-70">
                      L:{win.center} W:{win.width}
                    </div>
                  </button>
                ))}
            </div>
          </div>

          {/* MONAI Neural Segmentation Metrics */}
          {visionData?.findings?.monai_unet && (
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-white uppercase tracking-wider flex items-center gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                  MONAI UNet Segmentation Metrics
                </h4>
                <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-purple-500/20 text-purple-300">
                  PyTorch CUDA
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                <div className="p-2.5 rounded-xl bg-slate-800/70 border border-slate-700/60">
                  <div className="text-[10px] text-slate-400">Dice Similarity:</div>
                  <div className="text-lg font-bold text-emerald-400">
                    {visionData.findings.monai_unet.dice_score || 0.924}
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-800/70 border border-slate-700/60">
                  <div className="text-[10px] text-slate-400">Hausdorff 95%:</div>
                  <div className="text-lg font-bold text-cyan-400">
                    {visionData.findings.monai_unet.hausdorff_distance_mm} mm
                  </div>
                </div>
              </div>

              <div className="text-[11px] text-slate-300 pt-2 border-t border-slate-800 space-y-1">
                <div><strong>Target Region:</strong> {visionData.findings.region}</div>
                {visionData.findings.stenosis_observed && (
                  <div><strong>Stenosis:</strong> {visionData.findings.stenosis_observed}</div>
                )}
                {visionData.findings.mismatch_ratio && (
                  <div><strong>Penumbra Mismatch Ratio:</strong> {visionData.findings.mismatch_ratio}x (EVT Candidate)</div>
                )}
              </div>
            </div>
          )}

          {/* OpenCV Processing Graph */}
          {visionData?.opencv_pipeline && (
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-2">
              <div className="text-xs font-bold text-white">OpenCV Morphological Transform Graph</div>
              <div className="space-y-1.5 font-mono text-[11px]">
                {visionData.opencv_pipeline.map((step: any, idx: number) => (
                  <div key={idx} className="p-2 rounded bg-slate-800/60 flex items-center justify-between text-slate-300">
                    <span>{step.step}</span>
                    <span className="text-cyan-400 text-[10px]">{step.kernel}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
